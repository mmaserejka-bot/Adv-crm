package ru.advokat.crm

import android.Manifest
import android.app.*
import android.content.*
import android.net.Uri
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.*
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.IconButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import androidx.work.*
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

private val Forest=Color(0xFF0E3327); private val Green=Color(0xFF2F6B4F); private val Gold=Color(0xFFC7A45B); private val Cream=Color(0xFFF5F1E8); private val Ink=Color(0xFF1E2923); private val White=Color(0xFFFFFEFB)

data class Case(val id:String=UUID.randomUUID().toString(),var no:String="",var client:String="",var clientId:String="",var court:String="",var category:String="",var parties:String="",var status:String="В работе",var processStatus:String="",var date:String="",var notes:String="",var description:String="",var updated:Long=System.currentTimeMillis(),var history:MutableList<String> = mutableListOf())
data class Client(val id:String=UUID.randomUUID().toString(),var name:String="",var phone:String="",var email:String="",var details:String="",var notes:String="",var fee:String="0",var paid:String="0",var installmentEnabled:Boolean=false,var installmentAmount:String="0",var installmentDate:String="",var updated:Long=System.currentTimeMillis(),var history:MutableList<String> = mutableListOf())
data class Task(val id:String=UUID.randomUUID().toString(),var title:String="",var caseNo:String="",var caseId:String="",var deadline:String="",var priority:String="Средний",var status:String="В работе",var description:String="")
data class DocFolder(val id:String=UUID.randomUUID().toString(),var name:String="Новая папка",var parentId:String="")
data class Doc(val id:String=UUID.randomUUID().toString(),var name:String="",var caseNo:String="",var caseId:String="",var type:String="Документ",var path:String="",var folderId:String="",var added:Long=System.currentTimeMillis())
data class TrashItem(val id:String=UUID.randomUUID().toString(),var type:String="",var title:String="",var payload:String="",var deleted:Long=System.currentTimeMillis())
class Store(private val c: Context) {
    fun context(): Context = c
    private val p = c.getSharedPreferences("crm", 0)
    private val g = Gson()

    private inline fun <reified T> get(k: String): MutableList<T> =
        g.fromJson(p.getString(k, "[]"), object : TypeToken<MutableList<T>>() {}.type)
            ?: mutableListOf()

    private fun put(k: String, value: Any) {
        p.edit().putString(k, g.toJson(value)).apply()
    }

    var cases: MutableList<Case>
        get() = get("cases")
        set(value) = put("cases", value)

    var clients: MutableList<Client>
        get() = get("clients")
        set(value) = put("clients", value)

    var tasks: MutableList<Task>
        get() = get("tasks")
        set(value) = put("tasks", value)

    var docs: MutableList<Doc>
        get() = get("docs")
        set(value) = put("docs", value)

    var docFolders: MutableList<DocFolder>
        get() = get("docFolders")
        set(value) = put("docFolders", value)

    var trash: MutableList<TrashItem>
        get() = get("trash")
        set(value) = put("trash", value)
}

class MainActivity:ComponentActivity(){override fun onCreate(s:Bundle?){super.onCreate(s);val store=Store(this);purge(store);createChannel();if(Build.VERSION.SDK_INT>=33)requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),7);WorkManager.getInstance(this).enqueueUniquePeriodicWork("crm-reminders",ExistingPeriodicWorkPolicy.KEEP,PeriodicWorkRequestBuilder<ReminderWorker>(1,TimeUnit.DAYS).build());setContent{CRMApp(store)}}private fun createChannel(){val n=getSystemService(NotificationManager::class.java);if(Build.VERSION.SDK_INT>=26)n.createNotificationChannel(NotificationChannel("events","Судебные события",NotificationManager.IMPORTANCE_HIGH))}private fun purge(s:Store){s.trash=s.trash.filter{System.currentTimeMillis()-it.deleted<30L*24*60*60*1000}.toMutableList()}}
class ReminderWorker(c:Context,p:WorkerParameters):Worker(c,p){override fun doWork():Result{val s=Store(applicationContext);val fmt=SimpleDateFormat("dd.MM.yyyy",Locale.US);val now=Calendar.getInstance();val n=applicationContext.getSystemService(NotificationManager::class.java);s.cases.forEach{if(it.date.isBlank())return@forEach;runCatching{val d=Calendar.getInstance().apply{time=fmt.parse(it.date.substringBefore(" "))!!;set(Calendar.HOUR_OF_DAY,9);set(Calendar.MINUTE,0)};val days=((d.timeInMillis-now.timeInMillis)/86400000.0).toInt();if(days==3||days==1){val x=Notification.Builder(applicationContext,"events").setSmallIcon(R.drawable.ic_legal_mark).setContentTitle("Напоминание: заседание").setContentText("${it.date} • дело ${it.no}").setAutoCancel(true).build();n.notify((it.id.hashCode()+days),x)}}};s.clients.forEach{c->if(!c.installmentEnabled||c.installmentDate.isBlank())return@forEach;runCatching{val d=Calendar.getInstance().apply{time=fmt.parse(c.installmentDate)!!;set(Calendar.HOUR_OF_DAY,9);set(Calendar.MINUTE,0)};val days=((d.timeInMillis-now.timeInMillis)/86400000.0).toInt();if((days==3||days==1)&&((c.fee.toDoubleOrNull()?:0.0)-(c.paid.toDoubleOrNull()?:0.0))>0){val x=Notification.Builder(applicationContext,"events").setSmallIcon(R.drawable.ic_legal_mark).setContentTitle("Напоминание: платёж по рассрочке").setContentText("${c.name} • ${c.installmentAmount} ₽ • ${c.installmentDate}").setAutoCancel(true).build();n.notify((c.id.hashCode()+1000+days),x)}}};return Result.success()}}

@Composable
fun CRMApp(store: Store) {
    val settings=androidx.compose.ui.platform.LocalContext.current.getSharedPreferences("crm_settings",0)
    var night by remember{mutableStateOf(settings.getBoolean("night",false))}
    val scheme=if(night) darkColorScheme(primary=Color(0xFF9AD8B6),onPrimary=Color(0xFF062016),secondary=Color(0xFFE0C27A),onSecondary=Color(0xFF241B08),background=Color(0xFF0B120E),surface=Color(0xFF152019),surfaceVariant=Color(0xFF203027),onSurface=Color(0xFFEAF3EC),onBackground=Color(0xFFEAF3EC),outline=Color(0xFF6C7F73),error=Color(0xFFFFB4AB),onError=Color(0xFF690005)) else lightColorScheme(primary=Forest,secondary=Gold,background=Cream,surface=White,onSurface=Ink)
    MaterialTheme(colorScheme = scheme) {
        val nav = rememberNavController()
        var tick by remember { mutableIntStateOf(0) }
        val refresh:()->Unit={tick++}
        Scaffold(bottomBar = { BottomBar(nav) }) { pad ->
            Box(Modifier.fillMaxSize().padding(pad)) {
                key(tick) {
                    NavHost(navController = nav, startDestination = "home") {
                        composable("home") { Home(store, { nav.navigate("menu") }, refresh, nav) }
                        composable("menu") { MenuPage(nav) }
                        composable("calendar") { CalendarScreen(store, refresh, { nav.navigate("menu") }) }
                        composable("clients") { Clients(store, refresh, { nav.navigate("menu") }) }
                        composable("cases") { Cases(store, refresh, { nav.navigate("menu") }) }
                        composable("archive") { Archive(store, refresh, { nav.navigate("menu") }) }
                        composable("tasks") { Tasks(store, refresh, { nav.navigate("menu") }) }
                        composable("docs") { Documents(store, refresh, { nav.navigate("menu") }) }
                        composable("search") { Search(store, { nav.navigate("menu") }) }
                        composable("trash") { Trash(store, refresh, { nav.navigate("menu") }) }
                        composable("settings") { SettingsPage(store, { nav.popBackStack() }, { night=it }) }
                    }
                }
            }
        }
    }
}
@Composable fun Header(onMenu:()->Unit,title:String="Advokat CRM"){Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.CenterVertically){IconButton(onClick = onMenu){Icon(Icons.Default.Menu,"Меню",tint=MaterialTheme.colorScheme.primary)};Surface(Modifier.size(44.dp),CircleShape,color=MaterialTheme.colorScheme.primary){Icon(painterResource(R.drawable.ic_legal_mark),null,Modifier.padding(5.dp))};Spacer(Modifier.width(12.dp));Column{Text(title,fontSize=20.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary);Text("Юридическая практика",fontSize=11.sp,color=Gold)}}}
@Composable fun Home(s:Store,onMenu:()->Unit,refresh:()->Unit,nav:NavHostController){
    val showClient=remember{mutableStateOf(false)}; val showCase=remember{mutableStateOf(false)}; val cases=s.cases; val tasks=s.tasks; val now=System.currentTimeMillis()
    val upcoming=cases.filter{it.date.isNotBlank()&&!it.status.equals("Исполнено",true)}.mapNotNull{c->parseDateTime(c.date)?.let{d->if(d>=now)c to d else null}}.sortedBy{it.second}.take(3).map{it.first}
    val overdue=tasks.filter{!it.status.equals("Исполнено",true)&&!it.status.equals("Готово",true)&&parseDateTime(it.deadline)?.let{d->d<now}==true}.sortedBy{parseDateTime(it.deadline)?:Long.MAX_VALUE}.take(2)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())){
        Header(onMenu); Text("Добро пожаловать",Modifier.padding(horizontal=18.dp),fontSize=13.sp,color=Gold); Text("Ваша практика под контролем",Modifier.padding(horizontal=18.dp),fontSize=27.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary); Text(SimpleDateFormat("EEEE, d MMMM yyyy",Locale("ru")).format(Date()).replaceFirstChar{it.uppercase()},Modifier.padding(18.dp,3.dp),color=MaterialTheme.colorScheme.secondary)
        Row(Modifier.padding(horizontal=18.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)){Stat(Icons.Default.Gavel,"Дела",cases.size.toString(),Modifier.weight(1f)){nav.navigate("cases")};Stat(Icons.Default.Event,"Заседания",cases.count{it.date.isNotBlank()}.toString(),Modifier.weight(1f)){nav.navigate("calendar")};Stat(Icons.Default.TaskAlt,"Задачи",tasks.count{!it.status.equals("Исполнено",true)&&!it.status.equals("Готово",true)}.toString(),Modifier.weight(1f)){nav.navigate("tasks")}}
        Section("Ближайшие заседания"); if(upcoming.isEmpty()) Text("Ближайших заседаний нет",Modifier.padding(horizontal=18.dp),color=MaterialTheme.colorScheme.secondary) else upcoming.forEach{EventCard(it)}
        Section("Просроченные задачи"); if(overdue.isEmpty()) Text("Просроченных задач нет",Modifier.padding(horizontal=18.dp),color=MaterialTheme.colorScheme.secondary) else overdue.forEach{TaskCard(it)}
        Section("Быстрые действия"); Row(Modifier.padding(18.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)){QuickButton(Icons.Default.PersonAdd,"Новый клиент"){showClient.value=true};QuickButton(Icons.Default.AddTask,"Новое дело"){showCase.value=true}}; Spacer(Modifier.height(20.dp)); if(showClient.value){ClientDialog(s,refresh,close={showClient.value=false})}; if(showCase.value){CaseDialog(s,refresh,close={showCase.value=false})}
    }
}
@Composable fun Stat(icon:androidx.compose.ui.graphics.vector.ImageVector,label:String,value:String,modifier:Modifier=Modifier,click:()->Unit={})=Card(modifier.clickable(onClick=click),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Column(Modifier.padding(13.dp)){Icon(icon,null,tint=Gold,modifier=Modifier.size(22.dp));Text(value,fontSize=24.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary);Text(label,fontSize=12.sp,color=MaterialTheme.colorScheme.secondary)}}
@Composable fun Section(t:String){Text(t,Modifier.padding(18.dp,12.dp,18.dp,6.dp),fontSize=18.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)}
@Composable fun EventCard(c:Case)=Card(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=5.dp),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Gavel,null,tint=Gold,modifier=Modifier.size(28.dp));Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(c.date,fontWeight=FontWeight.Bold,color=Gold);Text(c.client.ifBlank{"Без клиента"},fontWeight=FontWeight.Bold);Text("${c.court} • ${c.no}",fontSize=12.sp,color=MaterialTheme.colorScheme.secondary)}}}
@Composable fun TaskCard(t:Task)=Card(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=4.dp),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Row(Modifier.padding(13.dp)){Icon(Icons.Default.TaskAlt,null,tint=Gold);Spacer(Modifier.width(10.dp));Column{Text(t.title,fontWeight=FontWeight.Bold);Text("${t.caseNo} • ${t.deadline} • ${t.priority}",fontSize=12.sp,color=MaterialTheme.colorScheme.secondary)}}}
@Composable fun QuickButton(i:androidx.compose.ui.graphics.vector.ImageVector,t:String,click:()->Unit)=Button(click,shape=RoundedCornerShape(15.dp),colors=ButtonDefaults.buttonColors(containerColor=Forest)){Icon(i,null);Spacer(Modifier.width(6.dp));Text(t,fontSize=12.sp)}

val mainItems=listOf("home" to "Главная","calendar" to "Календарь","clients" to "Клиенты","cases" to "Дела")
@Composable fun BottomBar(nav:NavHostController){
    val current=nav.currentBackStackEntryAsState().value?.destination?.route
    var moreOpen by remember{mutableStateOf(false)}
    NavigationBar(containerColor=MaterialTheme.colorScheme.surface){
        mainItems.forEach{(r,l)->NavigationBarItem(selected=current==r,onClick={moreOpen=false;nav.navigate(r){launchSingleTop=true;restoreState=true}},icon={Icon(navIcon(r),null)},label={Text(l,fontSize=9.sp)})}
        NavigationBarItem(
            selected=moreOpen,
            onClick={moreOpen=!moreOpen},
            icon={
                Box {
                    Icon(Icons.Default.MoreHoriz,null)
                    DropdownMenu(expanded=moreOpen,onDismissRequest={moreOpen=false},modifier=Modifier.width(230.dp)){
                        listOf("tasks" to ("Задачи" to Icons.Default.TaskAlt),"docs" to ("Документы" to Icons.Default.Description),"search" to ("Поиск" to Icons.Default.Search),"archive" to ("Архив" to Icons.Default.Inventory2),"trash" to ("Корзина" to Icons.Default.DeleteSweep)).forEach{(route,item)->
                            DropdownMenuItem(text={Text(item.first)},leadingIcon={Icon(item.second,null,tint=MaterialTheme.colorScheme.primary)},onClick={moreOpen=false;nav.navigate(route){launchSingleTop=true}})
                        }
                        HorizontalDivider()
                        DropdownMenuItem(text={Text("Настройки")},leadingIcon={Icon(Icons.Default.Settings,null,tint=MaterialTheme.colorScheme.primary)},onClick={moreOpen=false;nav.navigate("settings")})
                    }
                }
            },
            label={Text("Ещё",fontSize=9.sp)}
        )
    }
}
@Composable fun navIcon(r:String)=when(r){"home"->Icons.Default.Dashboard;"calendar"->Icons.Default.CalendarMonth;"clients"->Icons.Default.PeopleAlt;else->Icons.Default.Gavel}
@Composable
fun MenuPage(nav: NavHostController) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, "Назад", tint = MaterialTheme.colorScheme.primary) }
            Surface(Modifier.size(46.dp), CircleShape, color = MaterialTheme.colorScheme.primary) { Icon(painterResource(R.drawable.ic_legal_mark), null, Modifier.padding(5.dp)) }
            Spacer(Modifier.width(12.dp))
            Column { Text("Меню", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary); Text("ADVОKAT CRM", fontSize = 11.sp, color = Gold) }
        }
        HorizontalDivider(color = Gold.copy(alpha=.3f))
        listOf(
            "home" to ("Главная" to Icons.Default.Dashboard), "calendar" to ("Календарь" to Icons.Default.CalendarMonth),
            "clients" to ("Клиенты" to Icons.Default.PeopleAlt), "cases" to ("Дела" to Icons.Default.Gavel),
            "tasks" to ("Задачи" to Icons.Default.TaskAlt), "docs" to ("Документы" to Icons.Default.Description),
            "search" to ("Поиск" to Icons.Default.Search), "archive" to ("Архив" to Icons.Default.Inventory2), "trash" to ("Корзина" to Icons.Default.DeleteSweep), "settings" to ("Настройки" to Icons.Default.Settings)
        ).forEach { (route, item) ->
            NavigationDrawerItem(
                label = { Text(item.first, fontSize = 16.sp) }, selected = false,
                onClick = { nav.navigate(route) { launchSingleTop = true } },
                icon = { Icon(item.second, null, tint = if (route == "trash") Color(0xFF8A4A3A) else MaterialTheme.colorScheme.primary) },
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp)
            )
        }
    }
}

@Composable
fun CalendarScreen(s: Store, refresh: () -> Unit, onMenu: () -> Unit) {
    var deleting by remember { mutableStateOf<Case?>(null) }
    var monthOffset by remember { mutableIntStateOf(0) }
    var selectedDay by remember { mutableStateOf<String?>(null) }
    val cal = remember(monthOffset) { Calendar.getInstance().apply { add(Calendar.MONTH, monthOffset); set(Calendar.DAY_OF_MONTH, 1) } }
    val monthName = SimpleDateFormat("LLLL yyyy", Locale("ru")).format(cal.time).replaceFirstChar { it.uppercase() }
    val firstDow = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7
    val days = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    val cases = s.cases.filter { it.date.isNotBlank() }
    val byDate = cases.groupBy { it.date.substringBefore(" ") }
    Column(Modifier.fillMaxSize()) {
        Header(onMenu, "Календарь")
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { monthOffset-- }) { Icon(Icons.Default.ChevronLeft, "Предыдущий месяц", tint = MaterialTheme.colorScheme.primary) }
            Text(monthName, Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            IconButton(onClick = { monthOffset++ }) { Icon(Icons.Default.ChevronRight, "Следующий месяц", tint = MaterialTheme.colorScheme.primary) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            listOf("Пн","Вт","Ср","Чт","Пт","Сб","Вс").forEach { Text(it, Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary) }
        }
        Column(Modifier.padding(horizontal = 10.dp)) {
            val total = ((firstDow + days + 6) / 7) * 7
            for (row in 0 until total step 7) {
                Row(Modifier.fillMaxWidth()) {
                    for (col in 0..6) {
                        val n = row + col - firstDow + 1
                        if (n in 1..days) {
                            val date = String.format(Locale.US, "%02d.%02d.%04d", n, cal.get(Calendar.MONTH) + 1, cal.get(Calendar.YEAR))
                            val hasEvent = byDate.containsKey(date)
                            val selected = selectedDay == date
                            Box(Modifier.weight(1f).padding(2.dp).aspectRatio(1f).clickable { selectedDay = date }) {
                                Surface(Modifier.fillMaxSize(), RoundedCornerShape(12.dp), color = if (selected) Forest else if (hasEvent) Gold.copy(alpha = .18f) else White) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                        Text(n.toString(), color = if (selected) White else MaterialTheme.colorScheme.primary, fontWeight = if (hasEvent) FontWeight.Bold else FontWeight.Normal)
                                        if (hasEvent) Icon(Icons.Default.Event, null, Modifier.size(12.dp), tint = if (selected) White else Gold)
                                    }
                                }
                            }
                        } else { Spacer(Modifier.weight(1f).padding(2.dp).aspectRatio(1f)) }
                    }
                }
            }
        }
        HorizontalDivider(Modifier.padding(vertical = 8.dp), color = Gold.copy(alpha = .25f))
        val shown = selectedDay?.let { byDate[it].orEmpty() } ?: cases.filter { it.date.substringBefore(" ") == SimpleDateFormat("dd.MM.yyyy", Locale.US).format(Date()) }
        Text(if (selectedDay == null) "Сегодня" else "Заседания ${selectedDay}", Modifier.padding(horizontal = 18.dp, vertical = 8.dp), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        if (shown.isEmpty()) Text("На выбранную дату заседаний нет", Modifier.padding(18.dp), color = MaterialTheme.colorScheme.secondary)
        else LazyColumn {
            items(shown, key = { it.id }) { c ->
                Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = White)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(c.date, fontWeight = FontWeight.Bold, color = Gold)
                            Text(c.no.ifBlank { "Без номера дела" }, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Text(c.client.ifBlank { "Без клиента" }, color = Ink)
                            Text(c.court.ifBlank { "Суд не указан" }, color = MaterialTheme.colorScheme.secondary)
                            Text("Вид: ${c.category.ifBlank { "Судебное заседание" }}", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                        }
                        androidx.compose.material3.IconButton(onClick = { deleting = c }) {
                            Icon(Icons.Default.DeleteOutline, "Удалить дело", tint = Color(0xFF8A4A3A))
                        }
                    }
                }
            }
        }
        deleting?.let { c -> ConfirmDeleteDialog("дело", c.no.ifBlank { "без номера" }, { deleting = null }) { softDeleteCase(s, c, refresh); deleting = null } }
    }
}
@Composable
fun Clients(s: Store, refresh: () -> Unit, onMenu: () -> Unit) {
    var editing by remember { mutableStateOf<Client?>(null) }
    var adding by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<Client?>(null) }
    var viewing by remember { mutableStateOf<Client?>(null) }
    Column(Modifier.fillMaxSize()) {
        Header(onMenu)
        ScreenTitle("Клиенты", Icons.Default.PeopleAlt) { adding = true }
        LazyColumn {
            items(s.clients, key = { it.id }) { c ->
                val balance = money(c.fee.toDoubleOrNull(), c.paid.toDoubleOrNull())
                val installment = if (c.installmentEnabled) "Рассрочка: ${c.installmentAmount} ₽ • следующий платёж ${c.installmentDate.ifBlank { "не задан" }}" else "Рассрочка: нет"
                EntityCard(Icons.Default.Person, c.name.ifBlank { "Без имени" }, "${c.phone} • ${c.email}\nОстаток: $balance\n$installment\nДела: ${s.cases.filter { it.clientId == c.id }.joinToString { it.no.ifBlank { "без номера" } }.ifBlank { "нет" }}", onDelete = { deleting = c }, onEdit = { editing = c }, onView = { viewing = c })
            }
        }
        if (adding) ClientDialog(s, refresh, { adding = false })
        editing?.let { c -> ClientDialog(s, refresh, { editing = null }, c) }
        deleting?.let { c -> ConfirmDeleteDialog("клиента", c.name, { deleting = null }) { softDeleteClient(s, c, refresh); deleting = null } }
        viewing?.let { c -> ClientViewDialog(c) { viewing = null } }
    }
}

@Composable
fun Cases(s: Store, refresh: () -> Unit, onMenu: () -> Unit) {
    var editing by remember { mutableStateOf<Case?>(null) }
    var adding by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<Case?>(null) }
    var viewing by remember { mutableStateOf<Case?>(null) }
    val active = s.cases.filter { it.status != "Исполнено" }
    Column(Modifier.fillMaxSize()) {
        Header(onMenu)
        ScreenTitle("Дела", Icons.Default.Gavel) { adding = true }
        if (active.isEmpty()) Text("Активных дел нет", Modifier.padding(20.dp), color = MaterialTheme.colorScheme.secondary)
        else LazyColumn { items(active, key = { it.id }) { c -> EntityCard(Icons.Default.Gavel, "${c.no} • ${c.client}", "${c.court}\n${c.category} • ${c.status}\nРассмотрение: ${c.date}\n${c.description.ifBlank { c.notes }.ifBlank { "Описание дела не задано" }}", onDelete = { deleting = c }, onEdit = { editing = c }, onView = { viewing = c }) } }
        if (adding) CaseDialog(s, refresh, { adding = false })
        editing?.let { c -> CaseDialog(s, refresh, { editing = null }, c) }
        deleting?.let { c -> ConfirmDeleteDialog("дело", c.no.ifBlank { "без номера" }, { deleting = null }) { softDeleteCase(s, c, refresh); deleting = null } }
        viewing?.let { c -> CaseViewDialog(s, c) { viewing = null } }
    }
}

@Composable
fun Archive(s: Store, refresh: () -> Unit, onMenu: () -> Unit) {
    var editing by remember { mutableStateOf<Case?>(null) }
    var deleting by remember { mutableStateOf<Case?>(null) }
    val archived = s.cases.filter { it.status == "Исполнено" }
    Column(Modifier.fillMaxSize()) {
        Header(onMenu)
        Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Inventory2, null, tint = Gold); Spacer(Modifier.width(10.dp)); Text("Архив", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary) }
        if (archived.isEmpty()) Text("Исполненных дел пока нет", Modifier.padding(20.dp), color = MaterialTheme.colorScheme.secondary)
        else LazyColumn { items(archived, key = { it.id }) { c -> EntityCard(Icons.Default.Inventory2, "${c.no} • ${c.client}", "${c.court}\n${c.category} • Исполнено\nРассмотрение: ${c.date}\n${c.description.ifBlank { c.notes }}", onDelete = { deleting = c }, onEdit = { editing = c }) } }
        editing?.let { c -> CaseDialog(s, refresh, { editing = null }, c) }
        deleting?.let { c -> ConfirmDeleteDialog("дело", c.no.ifBlank { "без номера" }, { deleting = null }) { softDeleteCase(s, c, refresh); deleting = null } }
    }
}

@Composable
fun Tasks(s: Store, refresh: () -> Unit, onMenu: () -> Unit) {
    var editing by remember { mutableStateOf<Task?>(null) }
    var adding by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<Task?>(null) }
    Column(Modifier.fillMaxSize()) {
        Header(onMenu)
        ScreenTitle("Задачи", Icons.Default.TaskAlt) { adding = true }
        LazyColumn { items(s.tasks, key = { it.id }) { t -> EntityCard(Icons.Default.TaskAlt, t.title, "${t.caseNo}\nСрок исполнения: ${t.deadline}\n${t.priority} • ${if (t.status == "Открыта") "В работе" else t.status}\n${t.description}", onDelete = { deleting = t }, onEdit = { editing = t }) } }
        if (adding) TaskDialog(s, refresh, { adding = false })
        editing?.let { t -> TaskDialog(s, refresh, { editing = null }, t) }
        deleting?.let { t -> ConfirmDeleteDialog("задачу", t.title, { deleting = null }) { softDeleteTask(s, t, refresh); deleting = null } }
    }
}

@Composable
fun Documents(s: Store, refresh: () -> Unit, onMenu: () -> Unit) {
    var folder by remember { mutableStateOf("") }
    var addingFolder by remember { mutableStateOf(false) }
    var addingDoc by remember { mutableStateOf(false) }
    var folderName by remember { mutableStateOf("") }
    var deleteDoc by remember { mutableStateOf<Doc?>(null) }
    var deleteFolder by remember { mutableStateOf<DocFolder?>(null) }
    val folders = s.docFolders
    val currentDocs = s.docs.filter { it.folderId == folder }
    Column(Modifier.fillMaxSize()) {
        Header(onMenu, "Документы")
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Folder, null, tint = Gold); Spacer(Modifier.width(10.dp)); Text(if (folder.isBlank()) "Все документы" else folders.firstOrNull { it.id == folder }?.name ?: "Папка", Modifier.weight(1f), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            IconButton(onClick = { addingFolder = true }) { Icon(Icons.Default.CreateNewFolder, "Новая папка", tint = MaterialTheme.colorScheme.primary) }
            IconButton(onClick = { addingDoc = true }) { Icon(Icons.Default.UploadFile, "Загрузить", tint = MaterialTheme.colorScheme.primary) }
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = folder.isBlank(), onClick = { folder = "" }, label = { Text("Все") })
            folders.forEach { f ->
                Row(Modifier.clickable { folder = f.id }, verticalAlignment = Alignment.CenterVertically) {
                    FilterChip(selected = folder == f.id, onClick = { folder = f.id }, label = { Text(f.name) }, leadingIcon = { Icon(Icons.Default.Folder, null) })
                    IconButton(onClick = { deleteFolder = f }) { Icon(Icons.Default.DeleteOutline, "Удалить папку", tint = Color(0xFF8A4A3A)) }
                }
            }
        }
        if (currentDocs.isEmpty()) Text("Документов в этой папке пока нет", Modifier.padding(20.dp), color = MaterialTheme.colorScheme.secondary)
        else LazyColumn { items(currentDocs, key = { it.id }) { d -> EntityCard(Icons.Default.Description, d.name, "${d.type} • ${d.caseNo.ifBlank { "Без привязки к делу" }}", onDelete = { deleteDoc = d }, onEdit = { openDocumentFile(s, d) }) } }
        if (addingFolder) AlertDialog(onDismissRequest = { addingFolder = false }, title = { Text("Новая папка") }, text = { Field(folderName, { folderName = it }, "Название папки") }, confirmButton = { Button({ if (folderName.isNotBlank()) { s.docFolders = (s.docFolders + DocFolder(name = capitalizeInput(folderName.trim()))).toMutableList(); folderName = ""; addingFolder = false; refresh() } }) { Text("Создать") } }, dismissButton = { TextButton({ addingFolder = false }) { Text("Отмена") } })
        if (addingDoc) DocDialog(s, refresh, { addingDoc = false }, folder)
        deleteDoc?.let { d -> ConfirmDeleteDialog("документ", d.name, { deleteDoc = null }) { softDeleteDoc(s, d, refresh); deleteDoc = null } }
        deleteFolder?.let { f -> ConfirmDeleteDialog("папку", f.name, { deleteFolder = null }) { s.docFolders = s.docFolders.filter { it.id != f.id }.toMutableList(); s.docs = s.docs.map { if (it.folderId == f.id) it.copy(folderId = "") else it }.toMutableList(); if (folder == f.id) folder = ""; deleteFolder = null; refresh() } }
    }
}

fun openDocumentFile(s: Store, d: Doc) {
    val ctx = s.context(); val file = File(d.path)
    if (!file.exists()) { android.widget.Toast.makeText(ctx, "Файл не найден", android.widget.Toast.LENGTH_LONG).show(); return }
    val uri = androidx.core.content.FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", file)
    val mime = when (file.extension.lowercase(Locale.US)) { "pdf" -> "application/pdf"; "doc" -> "application/msword"; "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"; "txt" -> "text/plain"; "jpg", "jpeg" -> "image/jpeg"; "png" -> "image/png"; else -> "*/*" }
    val intent = Intent(Intent.ACTION_VIEW).apply { setDataAndType(uri, mime); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK) }
    try {
        val chooser = Intent.createChooser(intent, if (mime == "application/pdf") "Открыть PDF" else "Открыть документ").apply { addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK) }
        ctx.startActivity(chooser)
    } catch (_: Exception) {
        android.widget.Toast.makeText(ctx, if (mime == "application/pdf") "Установите приложение для чтения PDF (например, Adobe Acrobat или другое PDF-приложение)" else "Нет приложения для открытия этого формата", android.widget.Toast.LENGTH_LONG).show()
    }
}

@Composable
fun Search(s: Store, onMenu: () -> Unit) { var q by remember { mutableStateOf("") }; Column { Header(onMenu); Text("Поиск", Modifier.padding(horizontal = 18.dp), fontSize = 27.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary); OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(18.dp), placeholder = { Text("Клиент, номер дела, суд, телефон, документ") }, leadingIcon = { Icon(Icons.Default.Search, null) }, shape = RoundedCornerShape(16.dp)); val qq = q.trim().lowercase(); LazyColumn { items(s.cases.filter { listOf(it.no, it.client, it.court).any { v -> v.lowercase().contains(qq) } }) { Text("Дело: ${it.no} — ${it.court}", Modifier.padding(12.dp), color = MaterialTheme.colorScheme.primary) }; items(s.clients.filter { listOf(it.name, it.phone, it.email).any { v -> v.lowercase().contains(qq) } }) { Text("Клиент: ${it.name} — ${it.phone}", Modifier.padding(12.dp), color = MaterialTheme.colorScheme.primary) }; items(s.docs.filter { listOf(it.name, it.caseNo, it.type).any { v -> v.lowercase().contains(qq) } }) { Text("Документ: ${it.name} — ${it.caseNo}", Modifier.padding(12.dp), color = MaterialTheme.colorScheme.primary) } } } }

fun restoreTrashItem(s: Store, t: TrashItem) {
    val gson = Gson()
    var restored = false
    when (t.type) {
        "client" -> runCatching { gson.fromJson(t.payload, Client::class.java) }.getOrNull()?.let { item -> s.clients = (s.clients.filter { it.id != item.id } + item).toMutableList(); restored = true }
        "case" -> runCatching { gson.fromJson(t.payload, Case::class.java) }.getOrNull()?.let { item -> s.cases = (s.cases.filter { it.id != item.id } + item).toMutableList(); restored = true }
        "task" -> runCatching { gson.fromJson(t.payload, Task::class.java) }.getOrNull()?.let { item -> s.tasks = (s.tasks.filter { it.id != item.id } + item).toMutableList(); restored = true }
        "doc" -> runCatching { gson.fromJson(t.payload, Doc::class.java) }.getOrNull()?.let { item -> s.docs = (s.docs.filter { it.id != item.id } + item).toMutableList(); restored = true }
    }
    if (restored) s.trash = s.trash.filter { it.id != t.id }.toMutableList()
}
@Composable
fun Trash(s: Store, refresh: () -> Unit, onMenu: () -> Unit) { Column(Modifier.fillMaxSize()) { Header(onMenu); Text("Корзина", Modifier.padding(18.dp), fontSize = 27.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary); LazyColumn { items(s.trash, key = { it.id }) { t -> Card(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 5.dp), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.DeleteSweep, null, tint = Gold); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(t.title, fontWeight = FontWeight.Bold); Text(t.type, fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary) }; IconButton(onClick = { restoreTrashItem(s, t); refresh() }) { Icon(Icons.Default.Restore, "Восстановить") }; IconButton(onClick = { s.trash = s.trash.filter { it.id != t.id }.toMutableList(); refresh() }) { Icon(Icons.Default.DeleteForever, "Удалить навсегда", tint = Color(0xFF8A4A3A)) } } } } } }}

@Composable
fun ConfirmDeleteDialog(type: String, title: String, cancel: () -> Unit, confirm: () -> Unit) { AlertDialog(onDismissRequest = cancel, title = { Text("Удалить $type?") }, text = { Text("Вы хотите удалить $type «$title»?") }, confirmButton = { Button(onClick = confirm) { Text("Да") } }, dismissButton = { TextButton(onClick = cancel) { Text("Нет") } }) }

fun softDeleteTask(s: Store, t: Task, r: () -> Unit) { s.trash = (s.trash + TrashItem(type = "task", title = t.title, payload = Gson().toJson(t))).toMutableList(); s.tasks = s.tasks.filter { it.id != t.id }.toMutableList(); r() }
fun softDeleteDoc(s: Store, d: Doc, r: () -> Unit) { s.trash = (s.trash + TrashItem(type = "doc", title = d.name, payload = Gson().toJson(d))).toMutableList(); s.docs = s.docs.filter { it.id != d.id }.toMutableList(); r() }

@Composable fun ScreenTitle(t: String, i: androidx.compose.ui.graphics.vector.ImageVector, add: () -> Unit) { Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Icon(i, null, tint = Gold); Spacer(Modifier.width(10.dp)); Text(t, Modifier.weight(1f), fontSize = 27.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary); FloatingActionButton(add, containerColor = Forest, contentColor = MaterialTheme.colorScheme.onPrimary) { Icon(Icons.Default.Add, null) } } }
@Composable fun EntityCard(i: androidx.compose.ui.graphics.vector.ImageVector, title: String, sub: String, onDelete: () -> Unit, onEdit: () -> Unit, onView: () -> Unit = onEdit) = Card(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 5.dp), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(i, null, tint = Gold, modifier = Modifier.size(28.dp).clickable(onClick = onView)); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f).clickable(onClick = onView)) { Text(title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary); Text(sub, color = MaterialTheme.colorScheme.secondary, fontSize = 12.sp) }; IconButton(onClick = onEdit) { Icon(Icons.Default.Edit, "Редактировать", tint = MaterialTheme.colorScheme.primary) }; IconButton(onClick = onDelete) { Icon(Icons.Default.DeleteOutline, "Удалить", tint = Color(0xFF8A4A3A)) } } }
fun money(a: Double?, b: Double?): String = "%.0f ₽".format((a ?: 0.0) - (b ?: 0.0))
fun softDeleteCase(s: Store, c: Case, r: () -> Unit) { s.trash = (s.trash + TrashItem(type = "case", title = c.no, payload = Gson().toJson(c))).toMutableList(); s.cases = s.cases.filter { it.id != c.id }.toMutableList(); r() }
fun softDeleteClient(s: Store, c: Client, r: () -> Unit) { s.trash = (s.trash + TrashItem(type = "client", title = c.name, payload = Gson().toJson(c))).toMutableList(); s.clients = s.clients.filter { it.id != c.id }.toMutableList(); r() }

fun capitalizeInput(value: String): String = value.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale("ru")) else it.toString() }
fun digitsInput(value: String, allowDecimal: Boolean = false, allowPlus: Boolean = false): String {
    val allowed = if (allowDecimal) "0123456789.," else "0123456789"
    return value.filter { it in allowed || (allowPlus && it == '+' && value.indexOf(it) == 0) }
}

@Composable fun Field(v: String, on: (String) -> Unit, label: String, numeric: Boolean = false, decimal: Boolean = false, phone: Boolean = false) = OutlinedTextField(
    v, { value -> on(if (numeric) digitsInput(value, decimal, phone) else if (label.equals("Email", true)) value else capitalizeInput(value)) },
    Modifier.fillMaxWidth().padding(vertical = 4.dp), label = { Text(label) }, singleLine = true, shape = RoundedCornerShape(12.dp)
)

fun parseDateTime(value: String): Long? {
    val v = value.trim()
    if (v.isBlank()) return null
    val formats = listOf("dd.MM.yyyy HH:mm", "dd.MM.yyyy H:mm", "dd.MM.yyyy")
    for (pattern in formats) runCatching { return SimpleDateFormat(pattern, Locale.US).apply { isLenient = false }.parse(v)?.time }
    return null
}

@Composable fun ClientViewDialog(c: Client, close: () -> Unit) { val balance = money(c.fee.toDoubleOrNull(), c.paid.toDoubleOrNull()); AlertDialog(onDismissRequest=close,title={Text("Клиент")},text={Column(Modifier.verticalScroll(rememberScrollState())){Text(c.name.ifBlank{"Без имени"},fontWeight=FontWeight.Bold,fontSize=20.sp,color=MaterialTheme.colorScheme.primary); Spacer(Modifier.height(10.dp)); Text("Телефон: ${c.phone.ifBlank{"—"}}"); Text("Email: ${c.email.ifBlank{"—"}}"); Text("Сумма услуг: ${c.fee} ₽"); Text("Внесено: ${c.paid} ₽"); Text("Остаток: $balance",fontWeight=FontWeight.Bold); Text("Рассрочка: ${if(c.installmentEnabled) "да" else "нет"}"); if(c.installmentEnabled){Text("Следующий платёж: ${c.installmentAmount} ₽ • ${c.installmentDate.ifBlank{"дата не задана"}}")}; Text("Просмотр без редактирования",fontSize=11.sp,color=MaterialTheme.colorScheme.secondary)}},confirmButton={TextButton(close){Text("Закрыть")}}) }

@Composable fun CaseViewDialog(s: Store, c: Case, close: () -> Unit) { val docs = s.docs.filter { it.caseId == c.id }; AlertDialog(onDismissRequest=close,title={Text("Дело")},text={Column(Modifier.verticalScroll(rememberScrollState())){Text(c.no.ifBlank{"Без номера"},fontWeight=FontWeight.Bold,fontSize=20.sp,color=MaterialTheme.colorScheme.primary); Text("Клиент: ${c.client.ifBlank{"—"}}"); Text("Суд / орган: ${c.court.ifBlank{"—"}}"); Text("Категория: ${c.category.ifBlank{"—"}}"); Text("Дата и время: ${c.date.ifBlank{"—"}}"); Text("Статус: ${c.status}"); Text("Описание дела",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=10.dp)); Text(c.description.ifBlank { c.notes }.ifBlank { "—" }); Spacer(Modifier.height(10.dp)); Text("Документы дела",fontWeight=FontWeight.Bold); if(docs.isEmpty()) Text("Привязанных документов нет",color=MaterialTheme.colorScheme.secondary) else docs.forEach { d -> Row(Modifier.fillMaxWidth().padding(vertical=5.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Description,null,tint=Gold); Spacer(Modifier.width(8.dp)); Text(d.name.ifBlank{"Документ"},Modifier.weight(1f)); Text(d.type,fontSize=11.sp,color=MaterialTheme.colorScheme.secondary)}}; if(c.history.isNotEmpty()){Spacer(Modifier.height(8.dp));Text("История",fontWeight=FontWeight.Bold);c.history.forEach{Text("• $it")}}}},confirmButton={TextButton(close){Text("Закрыть")}}) }

@Composable
fun ClientDialog(s: Store, r: () -> Unit, close: () -> Unit, old: Client? = null) {
    var n by remember { mutableStateOf(old?.name ?: "") }; var ph by remember { mutableStateOf(old?.phone ?: "") }; var em by remember { mutableStateOf(old?.email ?: "") }; var fee by remember { mutableStateOf(old?.fee ?: "0") }; var paid by remember { mutableStateOf(old?.paid ?: "0") }; var installment by remember { mutableStateOf(old?.installmentEnabled ?: false) }; var installmentAmount by remember { mutableStateOf(old?.installmentAmount ?: "0") }; var installmentDate by remember { mutableStateOf(old?.installmentDate ?: "") }; val ctx = androidx.compose.ui.platform.LocalContext.current
    fun pickInstallmentDate() { val c = Calendar.getInstance(); DatePickerDialog(ctx, { _, y, m, d -> installmentDate = String.format(Locale.US, "%02d.%02d.%04d", d, m + 1, y) }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show() }
    val balance = (fee.toDoubleOrNull() ?: 0.0) - (paid.toDoubleOrNull() ?: 0.0)
    AlertDialog(onDismissRequest = close, title = { Text(if (old == null) "Новый клиент" else "Редактировать клиента") }, text = { Column(Modifier.verticalScroll(rememberScrollState())) { Field(n, { n = it }, "ФИО"); Field(ph, { ph = it }, "Телефон", numeric = true, phone = true); Field(em, { em = it }, "Email"); Field(fee, { fee = it }, "Сумма услуг", numeric = true, decimal = true); Field(paid, { paid = it }, "Внесено", numeric = true, decimal = true); Text("Остаток: ${"%.2f".format(balance)} ₽", fontWeight = FontWeight.Bold); Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text("Рассрочка платежа", Modifier.weight(1f)); Switch(installment, { installment = it }) }; if (installment) { Field(installmentAmount, { installmentAmount = it }, "Сумма очередного платежа", numeric = true, decimal = true); Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.weight(1f)) { Field(installmentDate, { installmentDate = it }, "Дата следующего платежа") }; IconButton(onClick = { pickInstallmentDate() }) { Icon(Icons.Default.CalendarMonth, "Выбрать дату") } } } } }, confirmButton = { Button(onClick = { val c = old ?: Client(); c.name = capitalizeInput(n); c.phone = digitsInput(ph, false, true); c.email = em.trim(); c.fee = digitsInput(fee, true); c.paid = digitsInput(paid, true); c.installmentEnabled = installment; c.installmentAmount = digitsInput(installmentAmount, true); c.installmentDate = installmentDate; val list = s.clients.toMutableList(); val i = list.indexOfFirst { it.id == c.id }; if (i >= 0) list[i] = c else list.add(c); s.clients = list; r(); close() }) { Text("Сохранить") } }, dismissButton = { TextButton(close) { Text("Отмена") } })
}

@Composable
fun CaseDialog(s: Store, r: () -> Unit, close: () -> Unit, old: Case? = null) {
    var no by remember { mutableStateOf(old?.no ?: "") }; var cl by remember { mutableStateOf(old?.client ?: "") }; var clientId by remember { mutableStateOf(old?.clientId ?: "") }; var clientMenu by remember { mutableStateOf(false) }; var court by remember { mutableStateOf(old?.court ?: "") }; var cat by remember { mutableStateOf(old?.category ?: "") }; var description by remember { mutableStateOf(old?.description ?: old?.notes ?: "") }; var date by remember { mutableStateOf(old?.date?.substringBefore(" ") ?: "") }; var time by remember { mutableStateOf(old?.date?.substringAfter(" ").takeIf { it != old?.date } ?: "") }; var status by remember { mutableStateOf(if (old?.status == "Исполнено") "Исполнено" else "В работе") }; val ctx = androidx.compose.ui.platform.LocalContext.current
    fun pickDate() { val c = Calendar.getInstance(); DatePickerDialog(ctx, { _, y, m, d -> date = String.format(Locale.US, "%02d.%02d.%04d", d, m + 1, y) }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show() }
    fun pickTime() { val c = Calendar.getInstance(); TimePickerDialog(ctx, { _, h, m -> time = String.format(Locale.US, "%02d:%02d", h, m) }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show() }
    AlertDialog(onDismissRequest = close, title = { Text(if (old == null) "Новое дело" else "Редактировать дело") }, text = { Column(Modifier.verticalScroll(rememberScrollState())) { Field(no, { no = it.filter { ch -> ch.isDigit() || ch in "/-." } }, "Номер дела"); Box { OutlinedButton({ clientMenu = true }, Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Text(if (cl.isBlank()) "Выберите клиента" else cl, Modifier.weight(1f)); Icon(Icons.Default.ArrowDropDown, null) }; DropdownMenu(clientMenu, { clientMenu = false }) { DropdownMenuItem({ Text("Без привязки") }, { clientId = ""; cl = ""; clientMenu = false }); s.clients.forEach { c -> DropdownMenuItem({ Text(c.name.ifBlank { "Без имени" }) }, { clientId = c.id; cl = c.name; clientMenu = false }) } } }; Field(court, { court = it }, "Суд / орган"); Field(cat, { cat = it }, "Категория"); OutlinedTextField(description, { description = capitalizeInput(it) }, Modifier.fillMaxWidth().heightIn(min = 100.dp).padding(vertical = 4.dp), label = { Text("Описание дела") }, shape = RoundedCornerShape(12.dp)); Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.weight(1f)) { Field(date, { date = it }, "Дата рассмотрения") }; IconButton(onClick = { pickDate() }) { Icon(Icons.Default.CalendarMonth, "Выбрать дату") } }; Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.weight(1f)) { Field(time, { time = it }, "Время") }; IconButton(onClick = { pickTime() }) { Icon(Icons.Default.Schedule, "Выбрать время") } }; var statusMenu by remember { mutableStateOf(false) }; OutlinedButton({ statusMenu = true }, Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Text(status, Modifier.weight(1f)); Icon(Icons.Default.ArrowDropDown, null) }; DropdownMenu(statusMenu, { statusMenu = false }) { listOf("В работе", "Исполнено").forEach { v -> DropdownMenuItem({ Text(v) }, { status = v; statusMenu = false }) } } } }, confirmButton = { Button(onClick = { val c = old ?: Case(); val linked = s.clients.firstOrNull { it.id == clientId }; c.no = no.filter { ch -> ch.isDigit() || ch in "/-." }; c.client = linked?.name ?: capitalizeInput(cl); c.clientId = linked?.id ?: clientId; c.court = capitalizeInput(court); c.category = capitalizeInput(cat); c.description = capitalizeInput(description); c.notes = c.description; c.date = listOf(date, time).filter { it.isNotBlank() }.joinToString(" "); c.status = status; c.updated = System.currentTimeMillis(); val list = s.cases.toMutableList(); val i = list.indexOfFirst { it.id == c.id }; if (i >= 0) list[i] = c else list.add(c); s.cases = list; r(); close() }) { Text("Сохранить") } }, dismissButton = { TextButton(close) { Text("Отмена") } })
}

@Composable
fun TaskDialog(s: Store, r: () -> Unit, close: () -> Unit, old: Task? = null) {
    var title by remember { mutableStateOf(old?.title ?: "") }; var description by remember { mutableStateOf(old?.description ?: "") }; var caseId by remember { mutableStateOf(old?.caseId ?: "") }; var caseNo by remember { mutableStateOf(old?.caseNo ?: "") }; var caseMenu by remember { mutableStateOf(false) }; var dl by remember { mutableStateOf(old?.deadline ?: "") }; var pr by remember { mutableStateOf(old?.priority ?: "Средний") }; var priorityMenu by remember { mutableStateOf(false) }; var st by remember { mutableStateOf(if (old?.status == "Исполнено") "Исполнено" else "В работе") }; var statusMenu by remember { mutableStateOf(false) }; val ctx = androidx.compose.ui.platform.LocalContext.current
    fun pickDateTime() { val c = Calendar.getInstance(); DatePickerDialog(ctx, { _, y, m, d -> TimePickerDialog(ctx, { _, h, min -> dl = String.format(Locale.US, "%02d.%02d.%04d %02d:%02d", d, m + 1, y, h, min) }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show() }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show() }
    AlertDialog(onDismissRequest = close, title = { Text(if (old == null) "Новая задача" else "Редактировать задачу") }, text = { Column(Modifier.verticalScroll(rememberScrollState())) { Field(title, { title = it }, "Задача"); OutlinedTextField(description, { description = capitalizeInput(it) }, Modifier.fillMaxWidth().heightIn(min = 100.dp).padding(vertical = 4.dp), label = { Text("Описание задачи") }); Box { OutlinedButton({ caseMenu = true }, Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Text(if (caseNo.isBlank()) "Выберите дело" else caseNo, Modifier.weight(1f)); Icon(Icons.Default.ArrowDropDown, null) }; DropdownMenu(caseMenu, { caseMenu = false }) { DropdownMenuItem({ Text("Без привязки") }, { caseId = ""; caseNo = ""; caseMenu = false }); s.cases.forEach { c -> DropdownMenuItem({ Text("${c.no.ifBlank { "Без номера" }} • ${c.client}") }, { caseId = c.id; caseNo = c.no; caseMenu = false }) } } }; Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.weight(1f)) { Field(dl, { dl = it }, "Срок исполнения") }; IconButton(onClick = { pickDateTime() }) { Icon(Icons.Default.Event, "Выбрать дату и время") } }; Box { OutlinedButton({ priorityMenu = true }, Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Text(pr, Modifier.weight(1f)); Icon(Icons.Default.ArrowDropDown, null) }; DropdownMenu(priorityMenu, { priorityMenu = false }) { listOf("Высокий", "Средний", "Низкий").forEach { v -> DropdownMenuItem({ Text(v) }, { pr = v; priorityMenu = false }) } } }; OutlinedButton({ statusMenu = true }, Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Text(st, Modifier.weight(1f)); Icon(Icons.Default.ArrowDropDown, null) }; DropdownMenu(statusMenu, { statusMenu = false }) { listOf("В работе", "Исполнено").forEach { v -> DropdownMenuItem({ Text(v) }, { st = v; statusMenu = false }) } } } }, confirmButton = { Button(onClick = { val t = old ?: Task(); t.title = capitalizeInput(title); t.description = capitalizeInput(description); t.caseId = caseId; t.caseNo = caseNo; t.deadline = dl; t.priority = pr; t.status = st; val list = s.tasks.toMutableList(); val i = list.indexOfFirst { it.id == t.id }; if (i >= 0) list[i] = t else list.add(t); s.tasks = list; r(); close() }) { Text("Сохранить") } }, dismissButton = { TextButton(close) { Text("Отмена") } })
}

@Composable
fun DocDialog(s: Store, r: () -> Unit, close: () -> Unit, initialFolderId: String = "") {
    var name by remember { mutableStateOf("") }; var caseId by remember { mutableStateOf("") }; var type by remember { mutableStateOf("Документ") }; var folderId by remember { mutableStateOf(initialFolderId) }; var caseMenu by remember { mutableStateOf(false) }; var folderMenu by remember { mutableStateOf(false) }; val ctx = androidx.compose.ui.platform.LocalContext.current
    fun save(uri: Uri?) { if (uri == null) return; val dir = File(ctx.filesDir, "documents"); dir.mkdirs(); val sourceName = uri.lastPathSegment?.substringAfterLast('/') ?: "document"; val safe = name.ifBlank { sourceName }.replace("/", "_"); val out = File(dir, "${System.currentTimeMillis()}_$safe"); ctx.contentResolver.openInputStream(uri)?.use { input -> out.outputStream().use { input.copyTo(it) } }; val c = s.cases.firstOrNull { it.id == caseId }; s.docs = (s.docs + Doc(name = capitalizeInput(name.ifBlank { sourceName }), caseNo = c?.no ?: "", caseId = caseId, type = capitalizeInput(type), path = out.absolutePath, folderId = folderId)).toMutableList(); r(); close() }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { save(it) }
    AlertDialog(onDismissRequest = close, title = { Text("Новый документ") }, text = { Column(Modifier.verticalScroll(rememberScrollState())) { Field(name, { name = it }, "Название"); Box { OutlinedButton({ caseMenu = true }, Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Text(if (caseId.isBlank()) "Связать с делом" else s.cases.firstOrNull { it.id == caseId }?.no ?: "Дело", Modifier.weight(1f)); Icon(Icons.Default.ArrowDropDown, null) }; DropdownMenu(caseMenu, { caseMenu = false }) { DropdownMenuItem({ Text("Без привязки") }, { caseId = ""; caseMenu = false }); s.cases.forEach { c -> DropdownMenuItem({ Text("${c.no.ifBlank { "Без номера" }} • ${c.client}") }, { caseId = c.id; caseMenu = false }) } } }; Box { OutlinedButton({ folderMenu = true }, Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Text(s.docFolders.firstOrNull { it.id == folderId }?.name ?: "Без папки", Modifier.weight(1f)); Icon(Icons.Default.ArrowDropDown, null) }; DropdownMenu(folderMenu, { folderMenu = false }) { DropdownMenuItem({ Text("Без папки") }, { folderId = ""; folderMenu = false }); s.docFolders.forEach { f -> DropdownMenuItem({ Text(f.name) }, { folderId = f.id; folderMenu = false }) } } }; Field(type, { type = it }, "Тип"); Button({ picker.launch(arrayOf("application/pdf", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "text/plain", "image/*")) }, Modifier.fillMaxWidth()) { Icon(Icons.Default.UploadFile, null); Spacer(Modifier.width(8.dp)); Text("Выбрать файл") } } }, confirmButton = { TextButton(close) { Text("Отмена") } }, dismissButton = {})
}

@Composable fun SettingsPage(s: Store, onBack: () -> Unit, onNight: (Boolean) -> Unit) {
    val p = androidx.compose.ui.platform.LocalContext.current.getSharedPreferences("crm_settings", 0)
    var night by remember { mutableStateOf(p.getBoolean("night", false)) }
    var high by remember { mutableIntStateOf(p.getInt("notify_high", 3)) }
    var medium by remember { mutableIntStateOf(p.getInt("notify_medium", 1)) }
    var low by remember { mutableIntStateOf(p.getInt("notify_low", 1)) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Surface(color = Forest, modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Назад", tint = White) }
                Column(Modifier.weight(1f)) { Text("Настройки", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold); Text("Параметры приложения", color = Gold, fontSize = 12.sp) }
                Icon(Icons.Default.Settings, null, tint = Gold, modifier = Modifier.size(30.dp))
            }
        }
        Text("Внешний вид", Modifier.padding(18.dp, 20.dp, 18.dp, 8.dp), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
        Card(Modifier.fillMaxWidth().padding(horizontal = 14.dp), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Surface(Modifier.size(44.dp), RoundedCornerShape(14.dp), color = Gold.copy(alpha = .16f)) { Icon(if (night) Icons.Default.DarkMode else Icons.Default.LightMode, null, tint = Gold, modifier = Modifier.padding(10.dp)) }
                Spacer(Modifier.width(14.dp)); Column(Modifier.weight(1f)) { Text("Ночной режим", fontWeight = FontWeight.Bold); Text(if (night) "Тёмное оформление включено" else "Светлое оформление включено", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary) }; Switch(night, { night = it; p.edit().putBoolean("night", it).apply(); onNight(it) })
            }
        }
        Text("Уведомления", Modifier.padding(18.dp, 22.dp, 18.dp, 8.dp), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
        Card(Modifier.fillMaxWidth().padding(horizontal = 14.dp), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(16.dp)) {
                Text("Напоминания о задачах", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text("За сколько дней напоминать о сроке", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(top = 3.dp, bottom = 10.dp))
                SettingRow("Высокий приоритет", high) { high = it; p.edit().putInt("notify_high", it).apply() }
                HorizontalDivider(color = Gold.copy(alpha = .16f))
                SettingRow("Средний приоритет", medium) { medium = it; p.edit().putInt("notify_medium", it).apply() }
                HorizontalDivider(color = Gold.copy(alpha = .16f))
                SettingRow("Низкий приоритет", low) { low = it; p.edit().putInt("notify_low", it).apply() }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable fun SettingRow(label: String, value: Int, set: (Int) -> Unit) { Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) { Text(label, Modifier.weight(1f)); Text(if (value == 0) "Выкл." else "$value дн."); IconButton(onClick = { set(maxOf(0, value - 1)) }) { Icon(Icons.Default.Remove, null) }; IconButton(onClick = { set(minOf(7, value + 1)) }) { Icon(Icons.Default.Add, null) } } }
