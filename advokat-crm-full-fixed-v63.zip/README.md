Advokat CRM v38

Based on v30/v37 UI and functionality.
Fix: replaced the incorrect black-background launcher emblem inside the app with a dedicated emerald-green header emblem; launcher icon remains unchanged.
Header is now a clean premium deep-green background with the gold bull emblem and no photographic legal background.
Trash immediate refresh behavior is preserved.

## ИИ-ассистент
В версии v61 добавлен встроенный ИИ-ассистент:
- текстовый ввод и голосовой ввод;
- создание и изменение клиентов, дел, задач и встреч;
- перенос дел/задач/встреч в архив;
- удаление через подтверждение с перемещением в Корзину;
- поиск актуальной судебной практики и законодательства через web search;
- локальная пользовательская память по команде «Запомни...»;
- доступ из меню отдельным пунктом выше «Задачи» и с главной страницы.

Для работы ИИ необходимо открыть «ИИ-ассистент» → ⚙ и указать API-ключ OpenAI. Ключ хранится локально на устройстве. Для многопользовательской версии рекомендуется вынести API-вызовы на сервер-посредник.
