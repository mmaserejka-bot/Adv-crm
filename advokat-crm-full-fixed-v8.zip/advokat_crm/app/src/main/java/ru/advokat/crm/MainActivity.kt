package ru.advokat.crm

import android.Manifest
import android.app.*
import android.content.*
import android.net.Uri
import android.os.*
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import androidx.work.*
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

private val Forest=Color(0xFF0E3327); private val Green=Color(0xFF2F6B4F); private val Gold=Color(0xFFC7A45B); private val Cream=Color(0xFFF5F1E8); private val Ink=Color(0xFF1E2923); private val White=Color(0xFFFFFEFB)

data class Case(val id:String=UUID.randomUUID().toString(),var no:String="",var client:String="",var clientId:String="",var court:String="",var category:String="",var parties:String="",var status:String="В работе",var processStatus:String="",var date:String="",var notes:String="",var fee:String="0",var paid:String="0",var updated:Long=System.currentTimeMillis(),var history:MutableList<String> = mutableListOf())
data class Client(val id:String=UUID.randomUUID().toString(),var name:String="",var phone:String="",var email:String="",var details:String="",var notes:String="",var fee:String="0",var paid:String="0",var updated:Long=System.currentTimeMillis(),var history:MutableList<String> = mutableListOf())
data class Task(val id:String=UUID.randomUUID().toString(),var title:String="",var caseNo:String="",var deadline:String="",var priority:String="Средний",var status:String="Открыта")
data class Doc(val id:String=UUID.randomUUID().toString(),var name:String="",var caseNo:String="",var type:String="Документ",var path:String="",var added:Long=System.currentTimeMillis())
data class TrashItem(val id:String=UUID.randomUUID().toString(),var type:String="",var title:String="",var payload:String="",var deleted:Long=System.currentTimeMillis())
class Store(private val c: Context) {
    private val p = c.getSharedPreferences("crm", 0)
    private val g = Gson()

    private inline fun <reified T> get(k: String): MutableList<T> =
        g.fromJson(p.getString(k, "[]"), object : TypeToken<MutableList<T>>() {}.type)
            ?: mutableListOf()

    private fun put(k: String, value: Any) {
        p.edit().putString(k, g.toJson(value)).apply()
    }

    var cases: MutableList<Case>
        get() = get("cases")
        set(value) = put("cases", value)

    var clients: MutableList<Client>
        get() = get("clients")
        set(value) = put("clients", value)

    var tasks: MutableList<Task>
        get() = get("tasks")
        set(value) = put("tasks", value)

    var docs: MutableList<Doc>
        get() = get("docs")
        set(value) = put("docs", value)

    var trash: MutableList<TrashItem>
        get() = get("trash")
        set(value) = put("trash", value)
}

class MainActivity:ComponentActivity(){override fun onCreate(s:Bundle?){super.onCreate(s);val store=Store(this);purge(store);createChannel();if(Build.VERSION.SDK_INT>=33)requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),7);WorkManager.getInstance(this).enqueueUniquePeriodicWork("crm-reminders",ExistingPeriodicWorkPolicy.KEEP,PeriodicWorkRequestBuilder<ReminderWorker>(1,TimeUnit.DAYS).build());setContent{CRMApp(store)}}private fun createChannel(){val n=getSystemService(NotificationManager::class.java);if(Build.VERSION.SDK_INT>=26)n.createNotificationChannel(NotificationChannel("events","Судебные события",NotificationManager.IMPORTANCE_HIGH))}private fun purge(s:Store){s.trash=s.trash.filter{System.currentTimeMillis()-it.deleted<30L*24*60*60*1000}.toMutableList()}}
class ReminderWorker(c:Context,p:WorkerParameters):Worker(c,p){override fun doWork():Result{val s=Store(applicationContext);val fmt=SimpleDateFormat("dd.MM.yyyy",Locale.US);val now=Calendar.getInstance();s.cases.forEach{if(it.date.isBlank())return@forEach;runCatching{val d=Calendar.getInstance().apply{time=fmt.parse(it.date)!!;set(Calendar.HOUR_OF_DAY,9);set(Calendar.MINUTE,0)};val days=((d.timeInMillis-now.timeInMillis)/86400000.0).toInt();if(days==3||days==1){val n=applicationContext.getSystemService(NotificationManager::class.java);val x=Notification.Builder(applicationContext,"events").setSmallIcon(R.drawable.ic_femida).setContentTitle("Напоминание: заседание").setContentText("${it.date} • дело ${it.no}").setAutoCancel(true).build();n.notify((it.id.hashCode()+days),x)}}};return Result.success()}}

@Composable
fun CRMApp(store: Store) {
    MaterialTheme(colorScheme = lightColorScheme(primary = Forest, secondary = Gold, background = Cream, surface = White, onSurface = Ink)) {
        val nav = rememberNavController()
        var drawer by remember { mutableStateOf(false) }
        var tick by remember { mutableIntStateOf(0) }
        fun refresh() { tick++ }

        val content: @Composable () -> Unit = {
            Scaffold(bottomBar = { BottomBar(nav) }) { pad ->
                Box(Modifier.fillMaxSize().padding(pad)) {
                    val refreshVersion = tick
                    key(refreshVersion) {
                    NavHost(navController = nav, startDestination = "home") {
                        composable("home") { Home(store, { drawer = true }, { refresh() }, nav) }
                        composable("calendar") { CalendarScreen(store, { drawer = true }) }
                        composable("clients") { Clients(store, { refresh() }, { drawer = true }) }
                        composable("cases") { Cases(store, { refresh() }, { drawer = true }) }
                        composable("tasks") { Tasks(store, { refresh() }, { drawer = true }) }
                        composable("docs") { Documents(store, { refresh() }, { drawer = true }) }
                        composable("search") { Search(store, { drawer = true }) }
                        composable("trash") { Trash(store, { refresh() }, { drawer = true }) }
                    }
                    }
                }
            }
        }

        if (drawer) {
            ModalNavigationDrawer(
                drawerContent = { Drawer { route -> drawer = false; nav.navigate(route) } },
                gesturesEnabled = true
            ) { content() }
        } else {
            content()
        }
    }
}
@Composable fun Header(onMenu:()->Unit,title:String="Advokat CRM"){Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.CenterVertically){IconButton(onMenu){Icon(Icons.Default.Menu,"Меню",tint=Forest)};Surface(Modifier.size(44.dp),CircleShape,color=Forest){Icon(painterResource(R.drawable.ic_femida),null,Modifier.padding(5.dp))};Spacer(Modifier.width(12.dp));Column{Text(title,fontSize=20.sp,fontWeight=FontWeight.Bold,color=Forest);Text("Юридическая практика",fontSize=11.sp,color=Gold)}}}
@Composable fun Home(s:Store,onMenu:()->Unit,refresh:()->Unit,nav:NavHostController){val showClient=remember{mutableStateOf(false)};val showCase=remember{mutableStateOf(false)};val cases=s.cases;val tasks=s.tasks;Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())){Header(onMenu);Text("Добро пожаловать",Modifier.padding(horizontal=18.dp),fontSize=13.sp,color=Gold);Text("Ваша практика под контролем",Modifier.padding(horizontal=18.dp),fontSize=27.sp,fontWeight=FontWeight.Bold,color=Forest);Text(SimpleDateFormat("EEEE, d MMMM yyyy",Locale("ru")).format(Date()).replaceFirstChar{it.uppercase()},Modifier.padding(18.dp,3.dp),color=Green);Row(Modifier.padding(horizontal=18.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)){Stat(Icons.Default.Gavel,"Дела",cases.size.toString(),Modifier.weight(1f)){nav.navigate("cases")};Stat(Icons.Default.Event,"Заседания",cases.count{it.date.isNotBlank()}.toString(),Modifier.weight(1f)){nav.navigate("calendar")};Stat(Icons.Default.TaskAlt,"Задачи",tasks.count{it.status!="Готово"}.toString(),Modifier.weight(1f)){nav.navigate("tasks")}};Section("Ближайшие заседания");cases.filter{it.date.isNotBlank()}.take(3).forEach{EventCard(it)};Section("Просроченные задачи");tasks.filter{it.status!="Готово"&&it.deadline.isNotBlank()}.take(2).forEach{TaskCard(it)};Section("Быстрые действия");Row(Modifier.padding(18.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)){QuickButton(Icons.Default.PersonAdd,"Новый клиент"){showClient.value=true};QuickButton(Icons.Default.AddTask,"Новое дело"){showCase.value=true}};Spacer(Modifier.height(20.dp));if(showClient.value){ClientDialog(s, refresh, close = { showClient.value = false })};if(showCase.value){CaseDialog(s, refresh, close = { showCase.value = false })}}}
@Composable fun Stat(icon:androidx.compose.ui.graphics.vector.ImageVector,label:String,value:String,modifier:Modifier=Modifier,click:()->Unit={})=Card(modifier.clickable(onClick=click),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=White)){Column(Modifier.padding(13.dp)){Icon(icon,null,tint=Gold,modifier=Modifier.size(22.dp));Text(value,fontSize=24.sp,fontWeight=FontWeight.Bold,color=Forest);Text(label,fontSize=12.sp,color=Green)}}
@Composable fun Section(t:String){Text(t,Modifier.padding(18.dp,12.dp,18.dp,6.dp),fontSize=18.sp,fontWeight=FontWeight.Bold,color=Forest)}
@Composable fun EventCard(c:Case)=Card(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=5.dp),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=White)){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Gavel,null,tint=Gold,modifier=Modifier.size(28.dp));Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(c.date,fontWeight=FontWeight.Bold,color=Gold);Text(c.client.ifBlank{"Без клиента"},fontWeight=FontWeight.Bold);Text("${c.court} • ${c.no}",fontSize=12.sp,color=Green)}}}
@Composable fun TaskCard(t:Task)=Card(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=4.dp),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=White)){Row(Modifier.padding(13.dp)){Icon(Icons.Default.TaskAlt,null,tint=Gold);Spacer(Modifier.width(10.dp));Column{Text(t.title,fontWeight=FontWeight.Bold);Text("${t.caseNo} • ${t.deadline} • ${t.priority}",fontSize=12.sp,color=Green)}}}
@Composable fun QuickButton(i:androidx.compose.ui.graphics.vector.ImageVector,t:String,click:()->Unit)=Button(click,shape=RoundedCornerShape(15.dp),colors=ButtonDefaults.buttonColors(containerColor=Forest)){Icon(i,null);Spacer(Modifier.width(6.dp));Text(t,fontSize=12.sp)}

val mainItems=listOf("home" to "Главная","calendar" to "Календарь","clients" to "Клиенты","cases" to "Дела")
@Composable fun BottomBar(nav:NavHostController){
    var more by remember{mutableStateOf(false)}
    val current=nav.currentBackStackEntryAsState().value?.destination?.route
    Box(Modifier.fillMaxWidth()){
        NavigationBar(containerColor=White){
            mainItems.forEach{(r,l)->NavigationBarItem(selected=current==r,onClick={more=false;nav.navigate(r){launchSingleTop=true;restoreState=true}},icon={Icon(navIcon(r),null)},label={Text(l,fontSize=9.sp)})}
            NavigationBarItem(selected=false,onClick={more=true},icon={Icon(Icons.Default.MoreHoriz,null)},label={Text("Ещё",fontSize=9.sp)})
        }
        Box(Modifier.align(Alignment.BottomEnd).padding(end=8.dp).size(48.dp)){
            DropdownMenu(expanded=more,onDismissRequest={more=false},modifier=Modifier.width(240.dp)){
                listOf("tasks" to "Задачи" to Icons.Default.TaskAlt,"docs" to "Документы" to Icons.Default.Description,"search" to "Поиск" to Icons.Default.Search,"trash" to "Корзина" to Icons.Default.DeleteSweep).forEach{e->
                    DropdownMenuItem(text={Text(e.first.second)},leadingIcon={Icon(e.second,null)},onClick={more=false;nav.navigate(e.first.first){launchSingleTop=true;restoreState=true}})
                }
            }
        }
    }
}
@Composable fun navIcon(r:String)=when(r){"home"->Icons.Default.Dashboard;"calendar"->Icons.Default.CalendarMonth;"clients"->Icons.Default.PeopleAlt;else->Icons.Default.Gavel}
@Composable fun Drawer(go:(String)->Unit){ModalDrawerSheet(Modifier.width(320.dp),drawerContainerColor=White){Row(Modifier.padding(24.dp),verticalAlignment=Alignment.CenterVertically){Surface(Modifier.size(50.dp),CircleShape,color=Forest){Icon(painterResource(R.drawable.ic_femida),null,Modifier.padding(5.dp))};Spacer(Modifier.width(12.dp));Column{Text("ADVОKAT CRM",fontSize=22.sp,fontWeight=FontWeight.Bold,color=Forest);Text("Профессиональная практика",fontSize=12.sp,color=Gold)}};HorizontalDivider(color=Gold.copy(alpha=.3f));listOf("home" to "Главная" to Icons.Default.Dashboard,"calendar" to "Календарь" to Icons.Default.CalendarMonth,"clients" to "Клиенты" to Icons.Default.PeopleAlt,"cases" to "Дела" to Icons.Default.Gavel,"tasks" to "Задачи" to Icons.Default.TaskAlt,"docs" to "Документы" to Icons.Default.Description,"search" to "Поиск" to Icons.Default.Search,"trash" to "Корзина" to Icons.Default.DeleteSweep).forEach{e->NavigationDrawerItem(label={Text(e.first.second)},selected=false,onClick={go(e.first.first)},icon={Icon(e.second,null,tint=if(e.first.first=="trash")Color(0xFF8A4A3A) else Forest)},modifier=Modifier.padding(horizontal=10.dp,vertical=2.dp))}}}

@Composable
fun CalendarScreen(s: Store, onMenu: () -> Unit) {
    var monthOffset by remember { mutableIntStateOf(0) }
    var selectedDay by remember { mutableStateOf<String?>(null) }
    val cal = remember(monthOffset) { Calendar.getInstance().apply { add(Calendar.MONTH, monthOffset); set(Calendar.DAY_OF_MONTH, 1) } }
    val monthName = SimpleDateFormat("LLLL yyyy", Locale("ru")).format(cal.time).replaceFirstChar { it.uppercase() }
    val firstDow = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7
    val days = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    val cases = s.cases.filter { it.date.isNotBlank() }
    val byDate = cases.groupBy { it.date }
    Column(Modifier.fillMaxSize()) {
        Header(onMenu, "Календарь")
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ monthOffset-- }) { Icon(Icons.Default.ChevronLeft, "Предыдущий месяц", tint = Forest) }
            Text(monthName, Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Forest)
            IconButton({ monthOffset++ }) { Icon(Icons.Default.ChevronRight, "Следующий месяц", tint = Forest) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            listOf("Пн","Вт","Ср","Чт","Пт","Сб","Вс").forEach { Text(it, Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontSize = 12.sp, color = Green) }
        }
        Column(Modifier.padding(horizontal = 10.dp)) {
            val total = ((firstDow + days + 6) / 7) * 7
            for (row in 0 until total step 7) {
                Row(Modifier.fillMaxWidth()) {
                    for (col in 0..6) {
                        val n = row + col - firstDow + 1
                        if (n in 1..days) {
                            val date = String.format(Locale.US, "%02d.%02d.%04d", n, cal.get(Calendar.MONTH) + 1, cal.get(Calendar.YEAR))
                            val hasEvent = byDate.containsKey(date)
                            val selected = selectedDay == date
                            Box(Modifier.weight(1f).padding(2.dp).aspectRatio(1f).clickable { selectedDay = date }) {
                                Surface(Modifier.fillMaxSize(), RoundedCornerShape(12.dp), color = if (selected) Forest else if (hasEvent) Gold.copy(alpha = .18f) else White) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                        Text(n.toString(), color = if (selected) White else Forest, fontWeight = if (hasEvent) FontWeight.Bold else FontWeight.Normal)
                                        if (hasEvent) Icon(Icons.Default.Event, null, Modifier.size(12.dp), tint = if (selected) White else Gold)
                                    }
                                }
                            }
                        } else { Spacer(Modifier.weight(1f).padding(2.dp).aspectRatio(1f)) }
                    }
                }
            }
        }
        HorizontalDivider(Modifier.padding(vertical = 8.dp), color = Gold.copy(alpha = .25f))
        val shown = selectedDay?.let { byDate[it].orEmpty() } ?: cases.filter { it.date == SimpleDateFormat("dd.MM.yyyy", Locale.US).format(Date()) }
        Text(if (selectedDay == null) "Сегодня" else "Заседания ${selectedDay}", Modifier.padding(horizontal = 18.dp, vertical = 8.dp), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Forest)
        if (shown.isEmpty()) Text("На выбранную дату заседаний нет", Modifier.padding(18.dp), color = Green)
        else LazyColumn { items(shown, key = { it.id }) { c -> Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = White)) { Column(Modifier.padding(16.dp)) { Text(c.date, fontWeight = FontWeight.Bold, color = Gold); Text(c.no.ifBlank { "Без номера дела" }, fontWeight = FontWeight.Bold, color = Forest); Text(c.client.ifBlank { "Без клиента" }, color = Ink); Text(c.court.ifBlank { "Суд не указан" }, color = Green); Text("Вид: ${c.category.ifBlank { "Судебное заседание" }}", fontSize = 12.sp, color = Green) } } } }
    }
}
@Composable fun Clients(s:Store,refresh:()->Unit,onMenu:()->Unit){var editing by remember{mutableStateOf<Client?>(null)};var adding by remember{mutableStateOf(false)};Column(Modifier.fillMaxSize()){Header(onMenu);ScreenTitle("Клиенты",Icons.Default.PeopleAlt){adding=true};LazyColumn{items(s.clients,key={it.id}){c->EntityCard(Icons.Default.Person,c.name,"${c.phone} • ${c.email}\nУслуги ${c.fee} • Внесено ${c.paid} • Остаток ${money(c.fee.toDoubleOrNull(),c.paid.toDoubleOrNull())}\nДела: ${s.cases.filter{it.clientId==c.id || (it.clientId.isBlank() && it.client==c.name)}.joinToString { it.no.ifBlank { "без номера" } }.ifBlank { "нет" }}\n${c.history.firstOrNull()?:"История изменений пока пуста"}",onDelete={softDeleteClient(s,c,refresh)},onEdit={editing=c})}}};if(adding)ClientDialog(s, refresh, close = { adding = false });editing?.let{client -> ClientDialog(s, refresh, close = { editing = null }, old = client)}}
@Composable fun Cases(s:Store,refresh:()->Unit,onMenu:()->Unit){var editing by remember{mutableStateOf<Case?>(null)};var adding by remember{mutableStateOf(false)};Column(Modifier.fillMaxSize()){Header(onMenu);ScreenTitle("Дела",Icons.Default.Gavel){adding=true};LazyColumn{items(s.cases,key={it.id}){c->EntityCard(Icons.Default.Gavel,"${c.no} • ${c.client}","${c.court}\n${c.category} • ${c.status}\nРассмотрение: ${c.date}\n${c.history.firstOrNull()?:"История изменений пока пуста"}",onDelete={softDeleteCase(s,c,refresh)},onEdit={editing=c})}}};if(adding)CaseDialog(s, refresh, close = { adding = false });editing?.let{caseItem -> CaseDialog(s, refresh, close = { editing = null }, old = caseItem)}}
@Composable fun Tasks(s:Store,refresh:()->Unit,onMenu:()->Unit){var editing by remember{mutableStateOf<Task?>(null)};var adding by remember{mutableStateOf(false)};Column(Modifier.fillMaxSize()){Header(onMenu);ScreenTitle("Задачи",Icons.Default.TaskAlt){adding=true};LazyColumn{items(s.tasks,key={it.id}){t->EntityCard(Icons.Default.TaskAlt,t.title,"${t.caseNo} • ${t.deadline}\n${t.priority} • ${t.status}",onDelete={s.trash=(s.trash+TrashItem(type="task",title=t.title,payload=Gson().toJson(t))).toMutableList();s.tasks=s.tasks.filter{it.id!=t.id}.toMutableList();refresh()},onEdit={editing=t})}}};if(adding)TaskDialog(s, refresh, close = { adding = false });editing?.let{taskItem -> TaskDialog(s, refresh, close = { editing = null }, old = taskItem)}}
@Composable
fun Documents(s: Store, refresh: () -> Unit, onMenu: () -> Unit) {
    var adding by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        Header(onMenu)
        ScreenTitle("Документы", Icons.Default.Description) { adding = true }
        LazyColumn {
            items(s.docs, key = { it.id }) { d ->
                EntityCard(
                    Icons.Default.Description,
                    d.name,
                    "${d.type} • ${d.caseNo}\n${if (d.path.isBlank()) "Файл не загружен" else File(d.path).name}",
                    onDelete = {
                        s.trash = (s.trash + TrashItem(type = "doc", title = d.name, payload = Gson().toJson(d))).toMutableList()
                        s.docs = s.docs.filter { it.id != d.id }.toMutableList()
                        refresh()
                    },
                    onEdit = {}
                )
            }
        }
        if (adding) {
            DocDialog(s, refresh, close = { adding = false })
        }
    }
}
@Composable fun Search(s:Store,onMenu:()->Unit){var q by remember{mutableStateOf("")};Column{Header(onMenu);Text("Поиск",Modifier.padding(horizontal=18.dp),fontSize=27.sp,fontWeight=FontWeight.Bold,color=Forest);OutlinedTextField(q,{q=it},Modifier.fillMaxWidth().padding(18.dp),placeholder={Text("Клиент, номер дела, суд, телефон, документ")},leadingIcon={Icon(Icons.Default.Search,null)},shape=RoundedCornerShape(16.dp));val qq=q.trim().lowercase();val cs=s.cases.filter{listOf(it.no,it.client,it.court).any{v->v.lowercase().contains(qq)}};val cl=s.clients.filter{listOf(it.name,it.phone,it.email).any{v->v.lowercase().contains(qq)}};val ds=s.docs.filter{listOf(it.name,it.caseNo,it.type).any{v->v.lowercase().contains(qq)}};LazyColumn{items(cs){Text("Дело: ${it.no} — ${it.court}",Modifier.padding(12.dp),color=Forest)};items(cl){Text("Клиент: ${it.name} — ${it.phone}",Modifier.padding(12.dp),color=Forest)};items(ds){Text("Документ: ${it.name} — ${it.caseNo}",Modifier.padding(12.dp),color=Forest)}}}}
@Composable fun Trash(s:Store,refresh:()->Unit,onMenu:()->Unit){Column{Header(onMenu);ScreenTitle("Корзина",Icons.Default.DeleteSweep){};LazyColumn{items(s.trash,key={it.id}){t->EntityCard(Icons.Default.DeleteSweep,t.title,"Автоудаление через ${maxOf(0,30-((System.currentTimeMillis()-t.deleted)/(86400000))).toInt()} дней",onDelete={s.trash=s.trash.filter{it.id!=t.id}.toMutableList();refresh()},onEdit={})}}}}
@Composable fun ScreenTitle(t:String,i:androidx.compose.ui.graphics.vector.ImageVector,add:()->Unit){Row(Modifier.fillMaxWidth().padding(18.dp),verticalAlignment=Alignment.CenterVertically){Icon(i,null,tint=Gold);Spacer(Modifier.width(10.dp));Text(t,Modifier.weight(1f),fontSize=27.sp,fontWeight=FontWeight.Bold,color=Forest);FloatingActionButton(add,containerColor=Forest,contentColor=White){Icon(Icons.Default.Add,null)}}}
@Composable fun EntityCard(i:androidx.compose.ui.graphics.vector.ImageVector,title:String,sub:String,onDelete:()->Unit,onEdit:()->Unit)=Card(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=5.dp),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=White)){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Icon(i,null,tint=Gold,modifier=Modifier.size(28.dp));Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(title,fontWeight=FontWeight.Bold,color=Forest);Text(sub,color=Green,fontSize=12.sp)};IconButton(onClick=onEdit){Icon(Icons.Default.Edit,null,tint=Forest)};IconButton(onClick=onDelete){Icon(Icons.Default.DeleteOutline,null,tint=Color(0xFF8A4A3A))}}}
fun money(a:Double?,b:Double?):String="%.0f ₽".format((a?:0.0)-(b?:0.0))

fun softDeleteCase(s:Store,c:Case,r:()->Unit){s.trash=(s.trash+TrashItem(type="case",title=c.no,payload=Gson().toJson(c))).toMutableList();s.cases=s.cases.filter{it.id!=c.id}.toMutableList();r()}
fun softDeleteClient(s:Store,c:Client,r:()->Unit){s.trash=(s.trash+TrashItem(type="client",title=c.name,payload=Gson().toJson(c))).toMutableList();s.clients=s.clients.filter{it.id!=c.id}.toMutableList();s.cases=s.cases.map{caseItem->if(caseItem.clientId==c.id)caseItem.copy(clientId="") else caseItem}.toMutableList();r()}


@Composable fun Field(v:String,on:(String)->Unit,label:String)=OutlinedTextField(v,on,Modifier.fillMaxWidth().padding(vertical=4.dp),label={Text(label)},singleLine=true,shape=RoundedCornerShape(12.dp))
@Composable fun ClientDialog(s:Store,r:()->Unit,close:()->Unit,old:Client?=null){var n by remember{mutableStateOf(old?.name?:"")};var ph by remember{mutableStateOf(old?.phone?:"")};var em by remember{mutableStateOf(old?.email?:"")};var fee by remember{mutableStateOf(old?.fee?:"0")};var paid by remember{mutableStateOf(old?.paid?:"0")};AlertDialog(onDismissRequest=close,title={Text(if(old==null)"Новый клиент" else "Редактировать клиента")},text={Column{Field(n,{n=it},"ФИО");Field(ph,{ph=it},"Телефон");Field(em,{em=it},"Email");Field(fee,{fee=it},"Сумма услуг");Field(paid,{paid=it},"Внесено")}},confirmButton={Button({val c=old?:Client();c.name=n;c.phone=ph;c.email=em;c.fee=fee;c.paid=paid;val list=s.clients.toMutableList();val i=list.indexOfFirst{it.id==c.id};val oldName=if(i>=0) list[i].name else "";if(i>=0){c.history.add(0,"Изменено ${SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.US).format(Date())}");list[i]=c}else{c.history.add(0,"Создано ${SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.US).format(Date())}");list.add(c)};s.clients=list;if(i>=0 && oldName.isNotBlank() && oldName!=c.name){s.cases=s.cases.map{caseItem->if(caseItem.clientId==c.id || (caseItem.clientId.isBlank() && caseItem.client==oldName)) caseItem.copy(client=c.name,clientId=c.id,updated=System.currentTimeMillis()) else caseItem}.toMutableList()};r();close()}){Text("Сохранить")}},dismissButton={TextButton(close){Text("Отмена")}})}
@Composable fun CaseDialog(s:Store,r:()->Unit,close:()->Unit,old:Case?=null){var no by remember{mutableStateOf(old?.no?:"")};var cl by remember{mutableStateOf(old?.client?:"")};var clientId by remember{mutableStateOf(old?.clientId?:"")};var clientMenu by remember{mutableStateOf(false)};var court by remember{mutableStateOf(old?.court?:"")};var cat by remember{mutableStateOf(old?.category?:"")};var date by remember{mutableStateOf(old?.date?:"")};var status by remember{mutableStateOf(old?.status?:"В работе")};var fee by remember{mutableStateOf(old?.fee?:"0")};var paid by remember{mutableStateOf(old?.paid?:"0")};AlertDialog(onDismissRequest=close,title={Text(if(old==null)"Новое дело" else "Редактировать дело")},text={Column{Field(no,{no=it},"Номер дела");Box{OutlinedButton(onClick={clientMenu=true},modifier=Modifier.fillMaxWidth().padding(vertical=4.dp)){Text(if(cl.isBlank())"Выберите клиента" else cl,Modifier.weight(1f));Icon(Icons.Default.ArrowDropDown,null)};DropdownMenu(expanded=clientMenu,onDismissRequest={clientMenu=false}){DropdownMenuItem(text={Text("Без привязки")},onClick={clientId="";cl="";clientMenu=false});s.clients.forEach{c->DropdownMenuItem(text={Text(c.name.ifBlank{"Без имени"})},onClick={clientId=c.id;cl=c.name;clientMenu=false})}}};Field(court,{court=it},"Суд / орган");Field(cat,{cat=it},"Категория");Field(date,{date=it},"Дата рассмотрения (дд.ММ.гггг)");Field(status,{status=it},"Статус");Field(fee,{fee=it},"Гонорар");Field(paid,{paid=it},"Внесено")}},confirmButton={Button({val c=old?:Case();val linked=s.clients.firstOrNull{it.id==clientId};c.no=no;c.client=linked?.name?:cl;c.clientId=linked?.id?:clientId;c.court=court;c.category=cat;c.date=date;c.status=status;c.fee=fee;c.paid=paid;c.updated=System.currentTimeMillis();val list=s.cases.toMutableList();val i=list.indexOfFirst{it.id==c.id};if(i>=0){c.history.add(0,"Изменено ${SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.US).format(Date())}");list[i]=c}else{c.history.add(0,"Создано ${SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.US).format(Date())}");list.add(c)};s.cases=list;r();close()}){Text("Сохранить")}},dismissButton={TextButton(close){Text("Отмена")}})}
@Composable fun TaskDialog(s:Store,r:()->Unit,close:()->Unit,old:Task?=null){var title by remember{mutableStateOf(old?.title?:"")};var no by remember{mutableStateOf(old?.caseNo?:"")};var dl by remember{mutableStateOf(old?.deadline?:"")};var pr by remember{mutableStateOf(old?.priority?:"Средний")};var st by remember{mutableStateOf(old?.status?:"Открыта")};AlertDialog(onDismissRequest=close,title={Text("Задача")},text={Column{Field(title,{title=it},"Задача");Field(no,{no=it},"Дело");Field(dl,{dl=it},"Дедлайн");Field(pr,{pr=it},"Приоритет");Field(st,{st=it},"Статус")}},confirmButton={Button({val t=old?:Task();t.title=title;t.caseNo=no;t.deadline=dl;t.priority=pr;t.status=st;val list=s.tasks.toMutableList();val i=list.indexOfFirst{it.id==t.id};if(i>=0)list[i]=t else list.add(t);s.tasks=list;r();close()}){Text("Сохранить")}},dismissButton={TextButton(close){Text("Отмена")}})}
@Composable fun DocDialog(s:Store,r:()->Unit,close:()->Unit){var name by remember{mutableStateOf("")};var no by remember{mutableStateOf("")};var type by remember{mutableStateOf("Документ")};val ctx=androidx.compose.ui.platform.LocalContext.current;val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri:Uri?->if(uri!=null){val f=File(ctx.filesDir,"documents");f.mkdirs();val out=File(f,"${System.currentTimeMillis()}_${name.ifBlank{"document"}.replace("/","_")}");ctx.contentResolver.openInputStream(uri)?.use{input->out.outputStream().use{input.copyTo(it)}};s.docs=(s.docs+Doc(name=name.ifBlank{out.name},caseNo=no,type=type,path=out.absolutePath)).toMutableList();r();close()}};AlertDialog(onDismissRequest=close,title={Text("Новый документ")},text={Column{Field(name,{name=it},"Название");Field(no,{no=it},"Номер дела");Field(type,{type=it},"Тип");Button({picker.launch(arrayOf("application/pdf","application/msword","application/vnd.openxmlformats-officedocument.wordprocessingml.document","text/plain"))},Modifier.fillMaxWidth()){Icon(Icons.Default.UploadFile,null);Spacer(Modifier.width(8.dp));Text("Выбрать файл")}}},confirmButton={Button({if(name.isNotBlank()){s.docs=(s.docs+Doc(name=name,caseNo=no,type=type)).toMutableList();r();close()}}){Text("Сохранить")}},dismissButton={TextButton(close){Text("Отмена")}})}
