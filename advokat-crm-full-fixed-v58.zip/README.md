Advokat CRM v38

Based on v30/v37 UI and functionality.
Fix: replaced the incorrect black-background launcher emblem inside the app with a dedicated emerald-green header emblem; launcher icon remains unchanged.
Header is now a clean premium deep-green background with the gold bull emblem and no photographic legal background.
Trash immediate refresh behavior is preserved.
