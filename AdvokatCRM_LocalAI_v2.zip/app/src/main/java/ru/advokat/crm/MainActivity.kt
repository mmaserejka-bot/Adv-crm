package ru.advokat.crm

import android.Manifest
import android.app.*
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.work.*
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit
import kotlin.math.max

private val Forest = Color(0xFF0E3327)
private val Green = Color(0xFF2F6B4F)
private val Gold = Color(0xFFC7A45B)
private val Cream = Color(0xFFF5F1E8)
private val Ink = Color(0xFF1E2923)
private val White = Color(0xFFFFFEFB)

// ---------- Local CRM data ----------
data class Case(
    val id: String = UUID.randomUUID().toString(), var no: String = "", var client: String = "",
    var court: String = "", var category: String = "", var parties: String = "",
    var status: String = "В работе", var processStatus: String = "", var date: String = "",
    var notes: String = "", var fee: String = "0", var paid: String = "0",
    var updated: Long = System.currentTimeMillis(), var history: MutableList<String> = mutableListOf()
)
data class Client(
    val id: String = UUID.randomUUID().toString(), var name: String = "", var phone: String = "",
    var email: String = "", var details: String = "", var notes: String = "", var fee: String = "0",
    var paid: String = "0", var updated: Long = System.currentTimeMillis(), var history: MutableList<String> = mutableListOf()
)
data class Task(
    val id: String = UUID.randomUUID().toString(), var title: String = "", var caseNo: String = "",
    var deadline: String = "", var priority: String = "Средний", var status: String = "Открыта"
)
data class Doc(
    val id: String = UUID.randomUUID().toString(), var name: String = "", var caseNo: String = "",
    var type: String = "Документ", var path: String = "", var added: Long = System.currentTimeMillis()
)
data class TrashItem(
    val id: String = UUID.randomUUID().toString(), var type: String = "", var title: String = "",
    var payload: String = "", var deleted: Long = System.currentTimeMillis()
)

class Store(private val context: Context) {
    private val prefs = context.getSharedPreferences("crm", Context.MODE_PRIVATE)
    private val gson = Gson()
    private inline fun <reified T> get(key: String): MutableList<T> =
        gson.fromJson(prefs.getString(key, "[]"), object : TypeToken<MutableList<T>>() {}.type) ?: mutableListOf()
    private fun put(key: String, value: Any) = prefs.edit().putString(key, gson.toJson(value)).apply()
    var cases: MutableList<Case> get() = get("cases") set(v) = put("cases", v)
    var clients: MutableList<Client> get() = get("clients") set(v) = put("clients", v)
    var tasks: MutableList<Task> get() = get("tasks") set(v) = put("tasks", v)
    var docs: MutableList<Doc> get() = get("docs") set(v) = put("docs", v)
    var trash: MutableList<TrashItem> get() = get("trash") set(v) = put("trash", v)
}

// ---------- Tiny on-device ML: intent classifier + semantic retrieval ----------
enum class AiIntent { CLIENT, CASE, TASKS, HEARINGS, SEARCH, STATS, CREATE_TASK, HELP, UNKNOWN }

data class AiAnswer(val text: String, val client: Client? = null, val caseItem: Case? = null)

private fun tokens(s: String): Set<String> = s.lowercase(Locale("ru"))
    .replace(Regex("[^\\p{L}\\p{Nd}]+"), " ").trim().split(Regex("\\s+"))
    .filter { it.length > 2 }.toSet()

private fun similarity(a: String, b: String): Double {
    val x = tokens(a); val y = tokens(b)
    if (x.isEmpty() || y.isEmpty()) return 0.0
    return x.intersect(y).size.toDouble() / max(1, x.union(y).size)
}

class TinyIntentModel {
    private val examples = mapOf(
        AiIntent.CLIENT to listOf("покажи клиента", "найди клиента", "карточка клиента", "клиент телефон", "открой клиента"),
        AiIntent.CASE to listOf("покажи дело", "найди дело", "карточка дела", "дело номер", "открой дело"),
        AiIntent.TASKS to listOf("мои задачи", "покажи задачи", "задачи на сегодня", "просроченные задачи", "дедлайны"),
        AiIntent.HEARINGS to listOf("заседания", "судебные заседания", "суд", "ближайшие заседания", "когда суд"),
        AiIntent.SEARCH to listOf("поиск", "найди", "что есть", "найти документ", "найти информацию"),
        AiIntent.STATS to listOf("статистика", "сколько дел", "сколько клиентов", "состояние практики"),
        AiIntent.CREATE_TASK to listOf("создай задачу", "добавь задачу", "новая задача", "поставь задачу"),
        AiIntent.HELP to listOf("помощь", "что умеешь", "команды", "как пользоваться")
    )
    fun predict(text: String): AiIntent = examples.maxByOrNull { (_, phrases) -> phrases.maxOf { similarity(text, it) } }
        ?.takeIf { similarity(text, it.value.maxByOrNull { p -> similarity(text, p) } ?: "") >= 0.10 }?.key ?: AiIntent.UNKNOWN
}

class LocalAiEngine(private val store: Store) {
    private val model = TinyIntentModel()

    private fun bestClient(query: String): Client? = store.clients.maxByOrNull { c ->
        similarity(query, c.name) * 4 + similarity(query, c.phone) * 2 + similarity(query, c.email)
    }?.takeIf { similarity(query, it.name) > 0 || query.contains(it.name, true) }

    private fun bestCase(query: String): Case? = store.cases.maxByOrNull { c ->
        similarity(query, "${c.no} ${c.client} ${c.court} ${c.category}") * 4
    }?.takeIf { similarity(query, "${it.no} ${it.client} ${it.court} ${it.category}") > 0 || query.contains(it.no, true) }

    fun ask(raw: String): AiAnswer {
        val q = raw.trim()
        if (q.isBlank()) return AiAnswer("Напиши запрос. Например: «покажи клиента Иванова» или «какие заседания на этой неделе?»")
        val intent = model.predict(q)
        return when (intent) {
            AiIntent.CLIENT -> bestClient(q)?.let { AiAnswer("Нашёл клиента. Открываю карточку ниже.", client = it) }
                ?: AiAnswer("Клиент не найден. Попробуй указать фамилию, телефон или email.")
            AiIntent.CASE -> bestCase(q)?.let { AiAnswer("Нашёл дело. Открываю карточку ниже.", caseItem = it) }
                ?: AiAnswer("Дело не найдено. Укажи номер дела, клиента или суд.")
            AiIntent.TASKS -> {
                val open = store.tasks.filter { !it.status.equals("Готово", true) }
                val overdue = open.filter { isOverdue(it.deadline) }
                AiAnswer(if (open.isEmpty()) "Открытых задач нет." else "Открытых задач: ${open.size}. Просроченных: ${overdue.size}.\n\n" + open.take(8).joinToString("\n") { "• ${it.title} — ${it.deadline.ifBlank { "без срока" }} (${it.priority})" })
            }
            AiIntent.HEARINGS -> {
                val items = store.cases.filter { it.date.isNotBlank() }.sortedBy { parseDate(it.date) ?: Long.MAX_VALUE }.take(8)
                AiAnswer(if (items.isEmpty()) "В календаре нет судебных заседаний." else "Ближайшие заседания:\n\n" + items.joinToString("\n") { "• ${it.date} — ${it.no.ifBlank { "без номера" }} — ${it.client.ifBlank { "без клиента" }}${if (it.court.isBlank()) "" else " — ${it.court}"}" })
            }
            AiIntent.SEARCH -> {
                val query = q.removePrefix("поиск").removePrefix("найди").trim()
                val clients = store.clients.filter { similarity(query, "${it.name} ${it.phone} ${it.email}") > 0 }.take(5)
                val cases = store.cases.filter { similarity(query, "${it.no} ${it.client} ${it.court} ${it.category}") > 0 }.take(5)
                AiAnswer("Результаты локального интеллектуального поиска:\n" + (clients.map { "• Клиент: ${it.name}" } + cases.map { "• Дело: ${it.no} — ${it.client}" }).ifEmpty { listOf("Ничего не найдено.") }.joinToString("\n"))
            }
            AiIntent.STATS -> AiAnswer("Сейчас в CRM:\n• клиентов: ${store.clients.size}\n• дел: ${store.cases.size}\n• открытых задач: ${store.tasks.count { !it.status.equals("Готово", true) }}\n• документов: ${store.docs.size}\n• заседаний с датой: ${store.cases.count { it.date.isNotBlank() }}")
            AiIntent.CREATE_TASK -> AiAnswer("Я могу создать задачу. Используй формат: «создай задачу: подготовить ходатайство; дело А12-123; срок 03.10.2026».")
            AiIntent.HELP -> AiAnswer("Я работаю локально и умею искать клиентов, дела и документы, показывать задачи и заседания, давать статистику и создавать задачи. Данные CRM не нужны для отправки запроса в интернет.")
            AiIntent.UNKNOWN -> AiAnswer("Не совсем понял запрос. Попробуй: «покажи клиента Иванова», «покажи дело А12-123», «какие заседания?», «мои задачи» или «статистика».")
        }
    }

    fun createTaskFromCommand(raw: String): Boolean {
        val q = raw.removePrefix("создай задачу").removePrefix("добавь задачу").trim().removePrefix(":").trim()
        if (q.isBlank()) return false
        val parts = q.split(";").map { it.trim() }
        val title = parts.getOrNull(0).orEmpty()
        if (title.isBlank()) return false
        var caseNo = ""; var deadline = ""; var priority = "Средний"
        parts.drop(1).forEach { p ->
            when {
                p.startsWith("дело", true) -> caseNo = p.substringAfter(":", p.substringAfter("дело", "", true)).trim()
                p.startsWith("срок", true) -> deadline = p.substringAfter(":", p.substringAfter("срок", "", true)).trim()
                p.startsWith("приоритет", true) -> priority = p.substringAfter(":", p.substringAfter("приоритет", "", true)).trim()
            }
        }
        store.tasks = (store.tasks + Task(title = title, caseNo = caseNo, deadline = deadline, priority = priority)).toMutableList()
        return true
    }

    private fun parseDate(s: String): Long? = runCatching { SimpleDateFormat("dd.MM.yyyy", Locale.US).parse(s)?.time }.getOrNull()
    private fun isOverdue(s: String): Boolean = parseDate(s)?.let { it < System.currentTimeMillis() } ?: false
}

class MainActivity : ComponentActivity() {
    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        val store = Store(this)
        store.trash = store.trash.filter { System.currentTimeMillis() - it.deleted < 30L * 24 * 60 * 60 * 1000 }.toMutableList()
        createChannel()
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("crm-reminders", ExistingPeriodicWorkPolicy.KEEP, PeriodicWorkRequestBuilder<ReminderWorker>(1, TimeUnit.DAYS).build())
        setContent { CRMApp(store) }
    }
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("events", "Судебные события", NotificationManager.IMPORTANCE_HIGH))
    }
}

class ReminderWorker(c: Context, p: WorkerParameters) : Worker(c, p) {
    override fun doWork(): Result {
        val s = Store(applicationContext); val fmt = SimpleDateFormat("dd.MM.yyyy", Locale.US); val now = Calendar.getInstance()
        s.cases.forEach { c ->
            if (c.date.isBlank()) return@forEach
            runCatching {
                val d = Calendar.getInstance().apply { time = fmt.parse(c.date)!!; set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0) }
                val days = ((d.timeInMillis - now.timeInMillis) / 86400000.0).toInt()
                if (days == 3 || days == 1) {
                    val n = applicationContext.getSystemService(NotificationManager::class.java)
                    n.notify(c.id.hashCode() + days, Notification.Builder(applicationContext, "events").setSmallIcon(R.drawable.ic_femida).setContentTitle("Напоминание: заседание").setContentText("${c.date} • дело ${c.no}").setAutoCancel(true).build())
                }
            }
        }
        return Result.success()
    }
}

@Composable
fun CRMApp(store: Store) {
    MaterialTheme(colorScheme = lightColorScheme(primary = Forest, secondary = Gold, background = Cream, surface = White, onSurface = Ink)) {
        val nav = rememberNavController(); var drawer by remember { mutableStateOf(false) }; var tick by remember { mutableIntStateOf(0) }
        fun refresh() { tick++ }
        val content: @Composable () -> Unit = {
            Scaffold(bottomBar = { BottomBar(nav) }) { pad ->
                Box(Modifier.fillMaxSize().padding(pad)) {
                    NavHost(nav, startDestination = "home") {
                        composable("home") { Home(store, { drawer = true }, refresh) }
                        composable("calendar") { CalendarScreen(store) }
                        composable("clients") { Clients(store, refresh) }
                        composable("cases") { Cases(store, refresh) }
                        composable("tasks") { Tasks(store, refresh) }
                        composable("docs") { Documents(store, refresh) }
                        composable("search") { Search(store) }
                        composable("trash") { Trash(store, refresh) }
                        composable("assistant") { AssistantScreen(store, refresh) }
                    }
                }
            }
        }
        if (drawer) ModalNavigationDrawer(drawerContent = { Drawer { route -> drawer = false; nav.navigate(route) } }, gesturesEnabled = true) { content() } else content()
    }
}

@Composable
fun Header(onMenu: () -> Unit, title: String = "Advokat CRM") {
    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onMenu) { Icon(Icons.Default.Menu, "Меню", tint = Forest) }
        Surface(Modifier.size(44.dp), CircleShape, color = Forest) { Icon(painterResource(R.drawable.ic_femida), null, Modifier.padding(5.dp)) }
        Spacer(Modifier.width(12.dp)); Column { Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Forest); Text("Юридическая практика", fontSize = 11.sp, color = Gold) }
    }
}

@Composable
fun Home(s: Store, onMenu: () -> Unit, refresh: () -> Unit) {
    var showClient by remember { mutableStateOf(false) }; var showCase by remember { mutableStateOf(false) }; var assistant by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header(onMenu); Text("Добро пожаловать", Modifier.padding(horizontal = 18.dp), fontSize = 13.sp, color = Gold)
        Text("Ваша практика под контролем", Modifier.padding(horizontal = 18.dp), fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Forest)
        Text(SimpleDateFormat("EEEE, d MMMM yyyy", Locale("ru")).format(Date()).replaceFirstChar { it.uppercase() }, Modifier.padding(18.dp, 3.dp), color = Green)
        Row(Modifier.padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) { Stat(Icons.Default.Gavel, "Дела", s.cases.size.toString()); Stat(Icons.Default.Event, "Заседания", s.cases.count { it.date.isNotBlank() }.toString()); Stat(Icons.Default.TaskAlt, "Задачи", s.tasks.count { it.status != "Готово" }.toString()) }
        Section("Ближайшие заседания"); s.cases.filter { it.date.isNotBlank() }.take(3).forEach { EventCard(it) }
        Section("Просроченные задачи"); s.tasks.filter { it.status != "Готово" && it.deadline.isNotBlank() }.take(2).forEach { TaskCard(it) }
        Section("Быстрые действия")
        Row(Modifier.padding(18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) { QuickButton(Icons.Default.PersonAdd, "Новый клиент") { showClient = true }; QuickButton(Icons.Default.AddTask, "Новое дело") { showCase = true } }
        OutlinedButton({ assistant = true }, Modifier.fillMaxWidth().padding(horizontal = 18.dp), shape = RoundedCornerShape(16.dp)) { Icon(Icons.Default.AutoAwesome, null); Spacer(Modifier.width(8.dp)); Text("Локальный AI-ассистент") }
        Spacer(Modifier.height(24.dp))
    }
    if (showClient) ClientDialog(s, refresh) { showClient = false }
    if (showCase) CaseDialog(s, refresh) { showCase = false }
    if (assistant) AssistantDialog(s, refresh) { assistant = false }
}

@Composable fun Stat(icon: ImageVector, label: String, value: String) = Card(Modifier.weight(1f), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = White)) { Column(Modifier.padding(13.dp)) { Icon(icon, null, tint = Gold, modifier = Modifier.size(22.dp)); Text(value, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Forest); Text(label, fontSize = 12.sp, color = Green) } }
@Composable fun Section(t: String) { Text(t, Modifier.padding(18.dp, 12.dp, 18.dp, 6.dp), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Forest) }
@Composable fun EventCard(c: Case) = Card(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 5.dp), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = White)) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Gavel, null, tint = Gold, modifier = Modifier.size(28.dp)); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(c.date, fontWeight = FontWeight.Bold, color = Gold); Text(c.client.ifBlank { "Без клиента" }, fontWeight = FontWeight.Bold); Text("${c.court} • ${c.no}", fontSize = 12.sp, color = Green) } } }
@Composable fun TaskCard(t: Task) = Card(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 4.dp), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = White)) { Row(Modifier.padding(13.dp)) { Icon(Icons.Default.TaskAlt, null, tint = Gold); Spacer(Modifier.width(10.dp)); Column { Text(t.title, fontWeight = FontWeight.Bold); Text("${t.caseNo} • ${t.deadline} • ${t.priority}", fontSize = 12.sp, color = Green) } } }
@Composable fun QuickButton(i: ImageVector, t: String, click: () -> Unit) = Button(click, shape = RoundedCornerShape(15.dp), colors = ButtonDefaults.buttonColors(containerColor = Forest)) { Icon(i, null); Spacer(Modifier.width(6.dp)); Text(t, fontSize = 12.sp) }

private val mainItems = listOf("home" to "Главная", "calendar" to "Календарь", "clients" to "Клиенты", "cases" to "Дела")
@Composable fun BottomBar(nav: NavHostController) { var more by remember { mutableStateOf(false) }; Box { NavigationBar(containerColor = White) { mainItems.forEach { (route, label) -> NavigationBarItem(false, { nav.navigate(route) }, icon = { Icon(navIcon(route), null) }, label = { Text(label, fontSize = 9.sp) }) }; NavigationBarItem(false, { more = true }, icon = { Icon(Icons.Default.MoreHoriz, null) }, label = { Text("Ещё", fontSize = 9.sp) }) }; DropdownMenu(more, { more = false }) { listOf("tasks" to "Задачи" to Icons.Default.TaskAlt, "docs" to "Документы" to Icons.Default.Description, "search" to "Поиск" to Icons.Default.Search, "assistant" to "AI-ассистент" to Icons.Default.AutoAwesome, "trash" to "Корзина" to Icons.Default.DeleteSweep).forEach { e -> DropdownMenuItem(text = { Text(e.first.second) }, leadingIcon = { Icon(e.second, null) }, onClick = { more = false; nav.navigate(e.first.first) }) } } } }
@Composable fun navIcon(r: String): ImageVector = when (r) { "home" -> Icons.Default.Dashboard; "calendar" -> Icons.Default.CalendarMonth; "clients" -> Icons.Default.PeopleAlt; else -> Icons.Default.Gavel }

@Composable fun Drawer(go: (String) -> Unit) { ModalDrawerSheet(Modifier.width(320.dp), drawerContainerColor = White) { Row(Modifier.padding(24.dp), verticalAlignment = Alignment.CenterVertically) { Surface(Modifier.size(50.dp), CircleShape, color = Forest) { Icon(painterResource(R.drawable.ic_femida), null, Modifier.padding(5.dp)) }; Spacer(Modifier.width(12.dp)); Column { Text("ADVOKAT CRM", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Forest); Text("Профессиональная практика", fontSize = 12.sp, color = Gold) } }; HorizontalDivider(color = Gold.copy(alpha = .3f)); val items = listOf("home" to "Главная" to Icons.Default.Dashboard, "calendar" to "Календарь" to Icons.Default.CalendarMonth, "clients" to "Клиенты" to Icons.Default.PeopleAlt, "cases" to "Дела" to Icons.Default.Gavel, "tasks" to "Задачи" to Icons.Default.TaskAlt, "docs" to "Документы" to Icons.Default.Description, "assistant" to "AI-ассистент" to Icons.Default.AutoAwesome, "search" to "Поиск" to Icons.Default.Search, "trash" to "Корзина" to Icons.Default.DeleteSweep); items.forEach { e -> NavigationDrawerItem(label = { Text(e.first.second) }, selected = false, onClick = { go(e.first.first) }, icon = { Icon(e.second, null, tint = Forest) }, modifier = Modifier.padding(horizontal = 10.dp, vertical = 2.dp)) } } }

// ---------- AI UI. Every result card has an explicit close button ----------
@Composable fun AssistantScreen(s: Store, refresh: () -> Unit) { Column(Modifier.fillMaxSize()) { Header({}); AssistantBody(s, refresh, Modifier.weight(1f)) } }
@Composable fun AssistantDialog(s: Store, refresh: () -> Unit, close: () -> Unit) { Dialog(onDismissRequest = close) { Surface(shape = RoundedCornerShape(24.dp), color = Cream, modifier = Modifier.fillMaxWidth().padding(16.dp)) { Column(Modifier.padding(8.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Text("Локальный AI", Modifier.weight(1f), fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Forest); IconButton(close) { Icon(Icons.Default.Close, "Закрыть", tint = Forest) } }; AssistantBody(s, refresh, Modifier.fillMaxWidth()) } } } }

@Composable fun AssistantBody(s: Store, refresh: () -> Unit, modifier: Modifier = Modifier) {
    val engine = remember { LocalAiEngine(s) }; var query by remember { mutableStateOf("") }; var answer by remember { mutableStateOf<AiAnswer?>(null) }; var showCard by remember { mutableStateOf(false) }
    Column(modifier.padding(12.dp).verticalScroll(rememberScrollState())) {
        Text("Работает на устройстве", color = Gold, fontSize = 12.sp); Text("Спросите CRM", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Forest)
        Text("Примеры: «покажи клиента Иванова», «какие заседания?», «мои задачи», «статистика».", color = Green, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp, bottom = 12.dp))
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), singleLine = false, minLines = 2, label = { Text("Запрос") }, shape = RoundedCornerShape(16.dp))
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) { Button({ answer = engine.ask(query); showCard = answer?.client != null || answer?.caseItem != null }, colors = ButtonDefaults.buttonColors(containerColor = Forest)) { Icon(Icons.Default.AutoAwesome, null); Spacer(Modifier.width(6.dp)); Text("Выполнить") }; TextButton({ query = "покажи клиента "; answer = null; showCard = false }) { Text("Клиент") } }
        answer?.let { a ->
            Card(Modifier.fillMaxWidth().padding(vertical = 6.dp), colors = CardDefaults.cardColors(containerColor = White), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(16.dp)) { Text(a.text, color = Ink); if (a.client != null || a.caseItem != null) { Spacer(Modifier.height(10.dp)); AssistResultCard(a.client, a.caseItem, showCard) { showCard = false } } } }
            if (query.trim().startsWith("создай задачу", true)) { TextButton({ if (engine.createTaskFromCommand(query)) { answer = AiAnswer("Задача создана локально."); refresh() } }) { Text("Создать эту задачу") } }
        }
    }
}

@Composable fun AssistResultCard(client: Client?, caseItem: Case?, visible: Boolean, close: () -> Unit) {
    if (!visible) return
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Cream), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Text(if (client != null) "Карточка клиента" else "Карточка дела", Modifier.weight(1f), fontWeight = FontWeight.Bold, color = Forest); IconButton(close) { Icon(Icons.Default.Close, "Закрыть карточку", tint = Forest) } }
            if (client != null) { Text(client.name, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Forest); Text("${client.phone.ifBlank { "Телефон не указан" }} • ${client.email.ifBlank { "Email не указан" }}", color = Green); Text("Услуги: ${client.fee} ₽ • Внесено: ${client.paid} ₽", color = Green) }
            caseItem?.let { Text("${it.no.ifBlank { "Без номера" }} — ${it.client.ifBlank { "Без клиента" }}", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Forest); Text("${it.court.ifBlank { "Суд не указан" }} • ${it.date.ifBlank { "Дата не указана" }}", color = Green); Text("${it.category.ifBlank { "Категория не указана" }} • ${it.status}", color = Green) }
        }
    }
}

@Composable fun CalendarScreen(s: Store) { Column(Modifier.fillMaxSize()) { Header({}); Text("Календарь", Modifier.padding(horizontal = 18.dp), fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Forest); LazyColumn { items(s.cases.filter { it.date.isNotBlank() }.sortedBy { it.date }) { c -> Card(Modifier.fillMaxWidth().padding(10.dp), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = White)) { Column(Modifier.padding(16.dp)) { Text(c.date, fontWeight = FontWeight.Bold, color = Gold); Text(c.no, fontWeight = FontWeight.Bold, color = Forest); Text(c.court, color = Green); Text("Вид: ${c.category.ifBlank { "Судебное заседание" }}", fontSize = 12.sp) } } } } } }

@Composable fun Clients(s: Store, refresh: () -> Unit) { var editing by remember { mutableStateOf<Client?>(null) }; var adding by remember { mutableStateOf(false) }; Column(Modifier.fillMaxSize()) { Header({}); ScreenTitle("Клиенты", Icons.Default.PeopleAlt) { adding = true }; LazyColumn { items(s.clients, key = { it.id }) { c -> EntityCard(Icons.Default.Person, c.name, "${c.phone} • ${c.email}\nУслуги ${c.fee} • Внесено ${c.paid} • Остаток ${money(c.fee.toDoubleOrNull(), c.paid.toDoubleOrNull())}", { softDeleteClient(s, c, refresh) }, { editing = c }) } }; if (adding) ClientDialog(s, refresh) { adding = false }; editing?.let { ClientDialog(s, refresh, { editing = null }, it) } } }
@Composable fun Cases(s: Store, refresh: () -> Unit) { var editing by remember { mutableStateOf<Case?>(null) }; var adding by remember { mutableStateOf(false) }; Column(Modifier.fillMaxSize()) { Header({}); ScreenTitle("Дела", Icons.Default.Gavel) { adding = true }; LazyColumn { items(s.cases, key = { it.id }) { c -> EntityCard(Icons.Default.Gavel, "${c.no} • ${c.client}", "${c.court}\n${c.category} • ${c.status}\nРассмотрение: ${c.date}", { softDeleteCase(s, c, refresh) }, { editing = c }) } }; if (adding) CaseDialog(s, refresh) { adding = false }; editing?.let { CaseDialog(s, refresh, { editing = null }, it) } } }
@Composable fun Tasks(s: Store, refresh: () -> Unit) { var editing by remember { mutableStateOf<Task?>(null) }; var adding by remember { mutableStateOf(false) }; Column(Modifier.fillMaxSize()) { Header({}); ScreenTitle("Задачи", Icons.Default.TaskAlt) { adding = true }; LazyColumn { items(s.tasks, key = { it.id }) { t -> EntityCard(Icons.Default.TaskAlt, t.title, "${t.caseNo} • ${t.deadline}\n${t.priority} • ${t.status}", { s.trash = (s.trash + TrashItem(type = "task", title = t.title, payload = Gson().toJson(t))).toMutableList(); s.tasks = s.tasks.filter { it.id != t.id }.toMutableList(); refresh() }, { editing = t }) } }; if (adding) TaskDialog(s, refresh) { adding = false }; editing?.let { TaskDialog(s, refresh, { editing = null }, it) } } }
@Composable fun Documents(s: Store, refresh: () -> Unit) { var adding by remember { mutableStateOf(false) }; Column(Modifier.fillMaxSize()) { Header({}); ScreenTitle("Документы", Icons.Default.Description) { adding = true }; LazyColumn { items(s.docs, key = { it.id }) { d -> EntityCard(Icons.Default.Description, d.name, "${d.type} • ${d.caseNo}\n${if (d.path.isBlank()) "Файл не загружен" else File(d.path).name}", { s.trash = (s.trash + TrashItem(type = "doc", title = d.name, payload = Gson().toJson(d))).toMutableList(); s.docs = s.docs.filter { it.id != d.id }.toMutableList(); refresh() }, {}) } }; if (adding) DocDialog(s, refresh) { adding = false } } }
@Composable fun Search(s: Store) { var q by remember { mutableStateOf("") }; Column { Header({}); Text("Поиск", Modifier.padding(horizontal = 18.dp), fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Forest); OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(18.dp), placeholder = { Text("Клиент, номер дела, суд, телефон, документ") }, leadingIcon = { Icon(Icons.Default.Search, null) }, shape = RoundedCornerShape(16.dp)); val qq = q.trim().lowercase(); LazyColumn { items(s.cases.filter { listOf(it.no, it.client, it.court).any { v -> v.lowercase().contains(qq) } }) { Text("Дело: ${it.no} — ${it.court}", Modifier.padding(12.dp), color = Forest) }; items(s.clients.filter { listOf(it.name, it.phone, it.email).any { v -> v.lowercase().contains(qq) } }) { Text("Клиент: ${it.name} — ${it.phone}", Modifier.padding(12.dp), color = Forest) }; items(s.docs.filter { listOf(it.name, it.caseNo, it.type).any { v -> v.lowercase().contains(qq) } }) { Text("Документ: ${it.name} — ${it.caseNo}", Modifier.padding(12.dp), color = Forest) } } } }
@Composable fun Trash(s: Store, refresh: () -> Unit) { Column { Header({}); ScreenTitle("Корзина", Icons.Default.DeleteSweep) {}; LazyColumn { items(s.trash, key = { it.id }) { t -> EntityCard(Icons.Default.DeleteSweep, t.title, "Автоудаление через ${maxOf(0, 30 - ((System.currentTimeMillis() - t.deleted) / 86400000).toInt())} дней", { s.trash = s.trash.filter { it.id != t.id }.toMutableList(); refresh() }, {}) } } } }

@Composable fun ScreenTitle(t: String, i: ImageVector, add: () -> Unit) { Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Icon(i, null, tint = Gold); Spacer(Modifier.width(10.dp)); Text(t, Modifier.weight(1f), fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Forest); FloatingActionButton(add, containerColor = Forest, contentColor = White) { Icon(Icons.Default.Add, null) } } }
@Composable fun EntityCard(i: ImageVector, title: String, sub: String, onDelete: () -> Unit, onEdit: () -> Unit) = Card(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 5.dp), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = White)) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(i, null, tint = Gold, modifier = Modifier.size(28.dp)); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Bold, color = Forest); Text(sub, color = Green, fontSize = 12.sp) }; IconButton(onEdit) { Icon(Icons.Default.Edit, null, tint = Forest) }; IconButton(onDelete) { Icon(Icons.Default.DeleteOutline, null, tint = Color(0xFF8A4A3A)) } } }
fun money(a: Double?, b: Double?): String = "%.0f ₽".format((a ?: 0.0) - (b ?: 0.0))
fun softDeleteCase(s: Store, c: Case, r: () -> Unit) { s.trash = (s.trash + TrashItem(type = "case", title = c.no, payload = Gson().toJson(c))).toMutableList(); s.cases = s.cases.filter { it.id != c.id }.toMutableList(); r() }
fun softDeleteClient(s: Store, c: Client, r: () -> Unit) { s.trash = (s.trash + TrashItem(type = "client", title = c.name, payload = Gson().toJson(c))).toMutableList(); s.clients = s.clients.filter { it.id != c.id }.toMutableList(); r() }

@Composable fun Field(v: String, on: (String) -> Unit, label: String) = OutlinedTextField(v, on, Modifier.fillMaxWidth().padding(vertical = 4.dp), label = { Text(label) }, singleLine = true, shape = RoundedCornerShape(12.dp))
@Composable fun ClientDialog(s: Store, r: () -> Unit, close: () -> Unit, old: Client? = null) { var n by remember { mutableStateOf(old?.name ?: "") }; var ph by remember { mutableStateOf(old?.phone ?: "") }; var em by remember { mutableStateOf(old?.email ?: "") }; var fee by remember { mutableStateOf(old?.fee ?: "0") }; var paid by remember { mutableStateOf(old?.paid ?: "0") }; AlertDialog(onDismissRequest = close, title = { Text(if (old == null) "Новый клиент" else "Редактировать клиента") }, text = { Column { Field(n, { n = it }, "ФИО"); Field(ph, { ph = it }, "Телефон"); Field(em, { em = it }, "Email"); Field(fee, { fee = it }, "Сумма услуг"); Field(paid, { paid = it }, "Внесено") } }, confirmButton = { Button({ val c = old ?: Client(); c.name = n; c.phone = ph; c.email = em; c.fee = fee; c.paid = paid; val list = s.clients.toMutableList(); val i = list.indexOfFirst { it.id == c.id }; if (i >= 0) list[i] = c else list.add(c); s.clients = list; r(); close() }) { Text("Сохранить") } }, dismissButton = { TextButton(close) { Text("Отмена") } }) }
@Composable fun CaseDialog(s: Store, r: () -> Unit, close: () -> Unit, old: Case? = null) { var no by remember { mutableStateOf(old?.no ?: "") }; var cl by remember { mutableStateOf(old?.client ?: "") }; var court by remember { mutableStateOf(old?.court ?: "") }; var cat by remember { mutableStateOf(old?.category ?: "") }; var date by remember { mutableStateOf(old?.date ?: "") }; var status by remember { mutableStateOf(old?.status ?: "В работе") }; var fee by remember { mutableStateOf(old?.fee ?: "0") }; var paid by remember { mutableStateOf(old?.paid ?: "0") }; AlertDialog(onDismissRequest = close, title = { Text(if (old == null) "Новое дело" else "Редактировать дело") }, text = { Column { Field(no, { no = it }, "Номер дела"); Field(cl, { cl = it }, "Клиент"); Field(court, { court = it }, "Суд / орган"); Field(cat, { cat = it }, "Категория"); Field(date, { date = it }, "Дата рассмотрения (дд.ММ.гггг)"); Field(status, { status = it }, "Статус"); Field(fee, { fee = it }, "Гонорар"); Field(paid, { paid = it }, "Внесено") } }, confirmButton = { Button({ val c = old ?: Case(); c.no = no; c.client = cl; c.court = court; c.category = cat; c.date = date; c.status = status; c.fee = fee; c.paid = paid; val list = s.cases.toMutableList(); val i = list.indexOfFirst { it.id == c.id }; if (i >= 0) list[i] = c else list.add(c); s.cases = list; r(); close() }) { Text("Сохранить") } }, dismissButton = { TextButton(close) { Text("Отмена") } }) }
@Composable fun TaskDialog(s: Store, r: () -> Unit, close: () -> Unit, old: Task? = null) { var title by remember { mutableStateOf(old?.title ?: "") }; var no by remember { mutableStateOf(old?.caseNo ?: "") }; var dl by remember { mutableStateOf(old?.deadline ?: "") }; var pr by remember { mutableStateOf(old?.priority ?: "Средний") }; var st by remember { mutableStateOf(old?.status ?: "Открыта") }; AlertDialog(onDismissRequest = close, title = { Text("Задача") }, text = { Column { Field(title, { title = it }, "Задача"); Field(no, { no = it }, "Дело"); Field(dl, { dl = it }, "Дедлайн"); Field(pr, { pr = it }, "Приоритет"); Field(st, { st = it }, "Статус") } }, confirmButton = { Button({ val t = old ?: Task(); t.title = title; t.caseNo = no; t.deadline = dl; t.priority = pr; t.status = st; val list = s.tasks.toMutableList(); val i = list.indexOfFirst { it.id == t.id }; if (i >= 0) list[i] = t else list.add(t); s.tasks = list; r(); close() }) { Text("Сохранить") } }, dismissButton = { TextButton(close) { Text("Отмена") } }) }
@Composable fun DocDialog(s: Store, r: () -> Unit, close: () -> Unit) { var name by remember { mutableStateOf("") }; var no by remember { mutableStateOf("") }; var type by remember { mutableStateOf("Документ") }; val ctx = androidx.compose.ui.platform.LocalContext.current; val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? -> if (uri != null) { val dir = File(ctx.filesDir, "documents"); dir.mkdirs(); val out = File(dir, "${System.currentTimeMillis()}_${name.ifBlank { "document" }.replace("/", "_")}"); ctx.contentResolver.openInputStream(uri)?.use { input -> out.outputStream().use { input.copyTo(it) } }; s.docs = (s.docs + Doc(name = name.ifBlank { out.name }, caseNo = no, type = type, path = out.absolutePath)).toMutableList(); r(); close() } }; AlertDialog(onDismissRequest = close, title = { Text("Новый документ") }, text = { Column { Field(name, { name = it }, "Название"); Field(no, { no = it }, "Номер дела"); Field(type, { type = it }, "Тип"); Button({ picker.launch(arrayOf("application/pdf", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "text/plain")) }, Modifier.fillMaxWidth()) { Icon(Icons.Default.UploadFile, null); Spacer(Modifier.width(8.dp)); Text("Выбрать файл") } } }, confirmButton = { Button({ if (name.isNotBlank()) { s.docs = (s.docs + Doc(name = name, caseNo = no, type = type)).toMutableList(); r(); close() } }) { Text("Сохранить") } }, dismissButton = { TextButton(close) { Text("Отмена") } }) }
