LOCAL MODEL SLOT

The CRM now contains a local AI layer: on-device intent classification, local semantic retrieval and CRM tools. It does not send CRM data to a server.

A real GGUF/ONNX small LLM can be placed here in a later build. The project deliberately does not fake a neural model by shipping arbitrary weights.

Supported local commands include:
- show/find client
- show/find case
- tasks and overdue tasks
- hearings
- local search
- statistics
- create task using: create task: title; case: ...; deadline: ...; priority: ...
