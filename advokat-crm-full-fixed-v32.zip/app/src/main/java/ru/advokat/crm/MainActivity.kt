package ru.advokat.crm

import android.Manifest
import android.app.*
import android.content.*
import android.net.Uri
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.*
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.IconButton
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import androidx.work.*
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import javax.xml.parsers.DocumentBuilderFactory
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

private val Forest=Color(0xFF0E3327); private val Green=Color(0xFF2F6B4F); private val Gold=Color(0xFFC7A45B); private val Cream=Color(0xFFF5F1E8); private val Ink=Color(0xFF1E2923); private val White=Color(0xFFFFFEFB)

data class Case(val id:String=UUID.randomUUID().toString(),var no:String="",var client:String="",var clientId:String="",var court:String="",var category:String="",var parties:String="",var status:String="В работе",var processStatus:String="",var date:String="",var notes:String="",var description:String="",var updated:Long=System.currentTimeMillis(),var history:MutableList<String> = mutableListOf())
data class Payment(val id:String=UUID.randomUUID().toString(),var amount:String="0",var date:String="",var note:String="")
data class Client(val id:String=UUID.randomUUID().toString(),var name:String="",var phone:String="",var email:String="",var details:String="",var notes:String="",var fee:String="0",var paid:String="0",var installmentEnabled:Boolean=false,var installmentAmount:String="0",var installmentDate:String="",var payments:MutableList<Payment> = mutableListOf(),var updated:Long=System.currentTimeMillis(),var created:Long=System.currentTimeMillis(),var history:MutableList<String> = mutableListOf())
data class Task(val id:String=UUID.randomUUID().toString(),var title:String="",var caseNo:String="",var caseId:String="",var deadline:String="",var priority:String="Средний",var status:String="В работе",var description:String="")
data class DocFolder(val id:String=UUID.randomUUID().toString(),var name:String="Новая папка",var parentId:String="")
data class Doc(val id:String=UUID.randomUUID().toString(),var name:String="",var caseNo:String="",var caseId:String="",var type:String="Документ",var path:String="",var folderId:String="",var added:Long=System.currentTimeMillis())
data class TrashItem(val id:String=UUID.randomUUID().toString(),var type:String="",var title:String="",var payload:String="",var deleted:Long=System.currentTimeMillis())
class Store(private val c: Context) {
    fun context(): Context = c
    private val p = c.getSharedPreferences("crm", 0)
    private val g = Gson()

    private inline fun <reified T> get(k: String): MutableList<T> =
        g.fromJson(p.getString(k, "[]"), object : TypeToken<MutableList<T>>() {}.type)
            ?: mutableListOf()

    private fun put(k: String, value: Any) {
        p.edit().putString(k, g.toJson(value)).apply()
    }

    var cases: MutableList<Case>
        get() = get("cases")
        set(value) = put("cases", value)

    var clients: MutableList<Client>
        get() = get("clients")
        set(value) = put("clients", value)

    var tasks: MutableList<Task>
        get() = get("tasks")
        set(value) = put("tasks", value)

    var docs: MutableList<Doc>
        get() = get("docs")
        set(value) = put("docs", value)

    var docFolders: MutableList<DocFolder>
        get() = get("docFolders")
        set(value) = put("docFolders", value)

    var trash: MutableList<TrashItem>
        get() = get("trash")
        set(value) = put("trash", value)
}

class MainActivity:ComponentActivity(){override fun onCreate(s:Bundle?){super.onCreate(s);val store=Store(this);purge(store);createChannel();if(Build.VERSION.SDK_INT>=33)requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),7);WorkManager.getInstance(this).enqueueUniquePeriodicWork("crm-reminders",ExistingPeriodicWorkPolicy.KEEP,PeriodicWorkRequestBuilder<ReminderWorker>(1,TimeUnit.DAYS).build());setContent{CRMApp(store)}}private fun createChannel(){val n=getSystemService(NotificationManager::class.java);if(Build.VERSION.SDK_INT>=26)n.createNotificationChannel(NotificationChannel("events","Судебные события",NotificationManager.IMPORTANCE_HIGH))}private fun purge(s:Store){s.trash=s.trash.filter{System.currentTimeMillis()-it.deleted<30L*24*60*60*1000}.toMutableList()}}
class ReminderWorker(c:Context,p:WorkerParameters):Worker(c,p){override fun doWork():Result{val s=Store(applicationContext);val fmt=SimpleDateFormat("dd.MM.yyyy",Locale.US);val now=Calendar.getInstance();val n=applicationContext.getSystemService(NotificationManager::class.java);s.cases.forEach{if(it.date.isBlank())return@forEach;runCatching{val d=Calendar.getInstance().apply{time=fmt.parse(it.date.substringBefore(" "))!!;set(Calendar.HOUR_OF_DAY,9);set(Calendar.MINUTE,0)};val days=((d.timeInMillis-now.timeInMillis)/86400000.0).toInt();if(days==3||days==1){val x=Notification.Builder(applicationContext,"events").setSmallIcon(R.drawable.ic_legal_mark).setContentTitle("Напоминание: заседание").setContentText("${it.date} • дело ${it.no}").setAutoCancel(true).build();n.notify((it.id.hashCode()+days),x)}}};return Result.success()}}

@Composable
fun CRMApp(store: Store) {
    val settings=androidx.compose.ui.platform.LocalContext.current.getSharedPreferences("crm_settings",0)
    var night by remember{mutableStateOf(settings.getBoolean("night",false))}
    val scheme=if(night) darkColorScheme(primary=Color(0xFF9AD8B6),onPrimary=Color(0xFF062016),secondary=Color(0xFFE0C27A),onSecondary=Color(0xFF241B08),background=Color(0xFF0B120E),surface=Color(0xFF152019),surfaceVariant=Color(0xFF203027),onSurface=Color(0xFFEAF3EC),onBackground=Color(0xFFEAF3EC),outline=Color(0xFF6C7F73),error=Color(0xFFFFB4AB),onError=Color(0xFF690005)) else lightColorScheme(primary=Forest,onPrimary=White,secondary=Gold,onSecondary=Ink,background=Cream,surface=White,surfaceVariant=Color(0xFFEAE3D5),onSurface=Ink,onBackground=Ink,outline=Color(0xFFB9AE9A),error=Color(0xFFB54A3D),onError=White)
    MaterialTheme(colorScheme = scheme) {
        val nav = rememberNavController()
        var tick by remember { mutableIntStateOf(0) }
        val refresh:()->Unit={tick++}
        val refreshVersion = tick
        Scaffold(bottomBar = { BottomBar(nav) }) { pad ->
            Box(Modifier.fillMaxSize().padding(pad).background(MaterialTheme.colorScheme.background)) {
                // Читаем refreshVersion: после восстановления/удаления Compose гарантированно
                // пересобирает текущий экран, поэтому запись сразу исчезает из корзины.
                if (refreshVersion >= 0) NavHost(navController = nav, startDestination = "home") {
                        composable("home") { Home(store, { nav.navigate("menu") }, refresh, nav) }
                        composable("menu") { MenuPage(nav) }
                        composable("calendar") { CalendarScreen(store, refresh, { nav.navigate("menu") }) }
                        composable("clients") { Clients(store, refresh, { nav.navigate("menu") }) }
                        composable("cases") { Cases(store, refresh, { nav.navigate("menu") }) }
                        composable("archive") { Archive(store, refresh, { nav.navigate("menu") }) }
                        composable("tasks") { Tasks(store, refresh, { nav.navigate("menu") }) }
                        composable("docs") { Documents(store, refresh, { nav.navigate("menu") }) }
                        composable("search") { Search(store, { nav.navigate("menu") }) }
                        composable("trash") { Trash(store, refresh, { nav.navigate("menu") }) }
                        composable("settings") { SettingsPage(store, { nav.popBackStack() }, { night=it }) }
                    }
            }
        }
    }
}
@Composable
fun Header(onMenu:()->Unit,title:String="Advokat CRM"){
    Surface(color=Forest, shadowElevation=3.dp) {
        Row(Modifier.fillMaxWidth().height(72.dp).padding(horizontal=12.dp),verticalAlignment=Alignment.CenterVertically){
            IconButton(onClick=onMenu){Icon(Icons.Default.Menu,"Меню",tint=White,modifier=Modifier.size(28.dp))}
            Surface(Modifier.size(46.dp),RoundedCornerShape(14.dp),color=Color(0xFF163D2F),border=BorderStroke(1.dp,Gold.copy(alpha=.65f))){
                Image(painterResource(R.drawable.ic_bull_launcher),contentDescription="Эмблема Advokat CRM",modifier=Modifier.fillMaxSize().padding(4.dp),contentScale=androidx.compose.ui.layout.ContentScale.Fit)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)){
                Text(title,fontSize=18.sp,fontWeight=FontWeight.Bold,color=White,maxLines=1,overflow=TextOverflow.Ellipsis)
                Text("Юридическая практика",fontSize=11.sp,color=Gold)
            }
            Icon(Icons.Default.AccountCircle,"Профиль",tint=Gold,modifier=Modifier.size(28.dp))
        }
    }
}

@Composable
fun HeroHeader(onMenu:()->Unit){
    Box(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Forest,Color(0xFF174B38))))) {
        Column(Modifier.padding(horizontal=18.dp,vertical=16.dp)){
            Row(verticalAlignment=Alignment.CenterVertically){
                IconButton(onClick=onMenu){Icon(Icons.Default.Menu,"Меню",tint=White,modifier=Modifier.size(28.dp))}
                Spacer(Modifier.weight(1f))
                Surface(Modifier.size(58.dp),RoundedCornerShape(18.dp),color=Color(0xFF163D2F),border=BorderStroke(1.dp,Gold.copy(alpha=.75f))){
                    Image(painterResource(R.drawable.ic_bull_launcher),contentDescription="Эмблема",modifier=Modifier.fillMaxSize().padding(5.dp),contentScale=androidx.compose.ui.layout.ContentScale.Fit)
                }
                Spacer(Modifier.weight(1f))
                Icon(Icons.Default.AccountCircle,"Профиль",tint=Gold,modifier=Modifier.size(28.dp))
            }
            Spacer(Modifier.height(8.dp))
            Text("Доброе утро!",fontSize=16.sp,color=White)
            Text("Адвокат",fontSize=28.sp,fontWeight=FontWeight.Bold,color=White)
            Text(SimpleDateFormat("EEEE, d MMMM yyyy",Locale("ru")).format(Date()).replaceFirstChar{it.uppercase()},fontSize=12.sp,color=Gold,modifier=Modifier.padding(top=3.dp))
        }
    }
}

@Composable
fun Home(s:Store,onMenu:()->Unit,refresh:()->Unit,nav:NavHostController){
    val showClient=remember{mutableStateOf(false)}
    val showCase=remember{mutableStateOf(false)}
    val cases=s.cases.filter{!it.status.equals("Исполнено",true)}
    val tasks=s.tasks.filter{!it.status.equals("Исполнено",true)&&!it.status.equals("Готово",true)&&s.cases.firstOrNull{c->c.id==it.caseId}?.status!="Исполнено"}
    val now=System.currentTimeMillis()
    val upcoming=cases.filter{it.date.isNotBlank()}.mapNotNull{c->parseDateTime(c.date)?.let{d->if(d>=now)c to d else null}}.sortedBy{it.second}.take(3).map{it.first}
    val overdue=tasks.filter{parseDateTime(it.deadline)?.let{d->d<now}==true}.sortedBy{parseDateTime(it.deadline)?:Long.MAX_VALUE}.take(3)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).background(MaterialTheme.colorScheme.background)){
        HeroHeader(onMenu)
        Column(Modifier.padding(top=10.dp)){
            Row(Modifier.padding(horizontal=18.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)){
                Stat(Icons.Default.Gavel,"Дела",cases.size.toString(),Modifier.weight(1f)){nav.navigate("cases")}
                Stat(Icons.Default.TaskAlt,"Задачи",tasks.size.toString(),Modifier.weight(1f)){nav.navigate("tasks")}
            }
            Row(Modifier.padding(horizontal=18.dp,vertical=10.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)){
                Stat(Icons.Default.Event,"События сегодня",cases.count{it.date.startsWith(SimpleDateFormat("dd.MM.yyyy",Locale.US).format(Date()))}.toString(),Modifier.weight(1f)){nav.navigate("calendar")}
                Stat(Icons.Default.WarningAmber,"Просрочено",overdue.size.toString(),Modifier.weight(1f),danger=overdue.isNotEmpty()){nav.navigate("tasks")}
            }
            Section("Сегодня")
            if(upcoming.isEmpty()) Text("Ближайших заседаний нет",Modifier.padding(horizontal=18.dp),color=MaterialTheme.colorScheme.secondary) else upcoming.forEach{EventCard(it)}
            if(overdue.isNotEmpty()){ Section("Просроченные задачи"); overdue.forEach{TaskCard(it)} }
            Button(onClick={showCase.value=true},modifier=Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=12.dp).height(52.dp),shape=RoundedCornerShape(16.dp),colors=ButtonDefaults.buttonColors(containerColor=Forest,contentColor=White)){Icon(Icons.Default.Add,null);Spacer(Modifier.width(8.dp));Text("Новое дело",fontSize=15.sp)}
            OutlinedButton(onClick={showClient.value=true},modifier=Modifier.fillMaxWidth().padding(horizontal=18.dp).height(50.dp),shape=RoundedCornerShape(16.dp),border=BorderStroke(1.dp,Gold),colors=ButtonDefaults.outlinedButtonColors(contentColor=Forest)){Icon(Icons.Default.PersonAdd,null);Spacer(Modifier.width(8.dp));Text("Новый клиент",fontSize=14.sp)}
            Spacer(Modifier.height(18.dp))
        }
    }
    if(showClient.value) ClientDialog(s,refresh,close={showClient.value=false})
    if(showCase.value) CaseDialog(s,refresh,close={showCase.value=false})
}

@Composable
fun Stat(icon:androidx.compose.ui.graphics.vector.ImageVector,label:String,value:String,modifier:Modifier=Modifier,danger:Boolean=false,click:()->Unit={})=Card(modifier.clickable(onClick=click),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),border=BorderStroke(1.dp,if(danger) Color(0xFFB54A3D).copy(alpha=.35f) else Gold.copy(alpha=.28f))){
    Row(Modifier.fillMaxWidth().padding(14.dp),verticalAlignment=Alignment.CenterVertically){
        Surface(Modifier.size(42.dp),CircleShape,color=if(danger) Color(0xFFB54A3D).copy(alpha=.12f) else Gold.copy(alpha=.14f)){Box(contentAlignment=Alignment.Center,modifier=Modifier.fillMaxSize()){Icon(icon,null,tint=if(danger) Color(0xFFB54A3D) else Gold)}}
        Spacer(Modifier.width(11.dp)); Column{Text(label,fontSize=11.sp,color=MaterialTheme.colorScheme.secondary);Text(value,fontSize=24.sp,fontWeight=FontWeight.Bold,color=if(danger) Color(0xFFB54A3D) else MaterialTheme.colorScheme.primary)}
    }
}

@Composable fun Section(t:String){Text(t,Modifier.padding(18.dp,12.dp,18.dp,6.dp),fontSize=18.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)}
@Composable fun EventCard(c:Case)=Card(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=5.dp),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Gavel,null,tint=Gold,modifier=Modifier.size(28.dp));Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(c.date,fontWeight=FontWeight.Bold,color=Gold);Text(c.client.ifBlank{"Без клиента"},fontWeight=FontWeight.Bold);Text("${c.court} • ${c.no}",fontSize=12.sp,color=MaterialTheme.colorScheme.secondary)}}}
@Composable fun TaskCard(t:Task)=Card(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=4.dp),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Row(Modifier.padding(13.dp)){Icon(Icons.Default.TaskAlt,null,tint=Gold);Spacer(Modifier.width(10.dp));Column{Text(t.title,fontWeight=FontWeight.Bold);Text("${t.caseNo} • ${t.deadline} • ${t.priority}",fontSize=12.sp,color=MaterialTheme.colorScheme.secondary)}}}
@Composable fun QuickButton(i:androidx.compose.ui.graphics.vector.ImageVector,t:String,click:()->Unit)=Button(click,shape=RoundedCornerShape(15.dp),colors=ButtonDefaults.buttonColors(containerColor=Forest)){Icon(i,null);Spacer(Modifier.width(6.dp));Text(t,fontSize=12.sp)}

val mainItems=listOf("home" to "Главная","calendar" to "Календарь","cases" to "Дела","clients" to "Клиенты")
@Composable fun BottomBar(nav:NavHostController){
    val current=nav.currentBackStackEntryAsState().value?.destination?.route
    var moreOpen by remember{mutableStateOf(false)}
    NavigationBar(containerColor=MaterialTheme.colorScheme.surface){
        mainItems.forEach{(r,l)->NavigationBarItem(selected=current==r,onClick={moreOpen=false;nav.navigate(r){launchSingleTop=true;restoreState=true}},icon={Icon(navIcon(r),null)},label={Text(l,fontSize=9.sp)})}
        NavigationBarItem(
            selected=moreOpen,
            onClick={moreOpen=!moreOpen},
            icon={
                Box {
                    Icon(Icons.Default.MoreHoriz,null)
                    DropdownMenu(expanded=moreOpen,onDismissRequest={moreOpen=false},offset=DpOffset(0.dp,-260.dp),modifier=Modifier.width(230.dp)){
                        listOf("tasks" to ("Задачи" to Icons.Default.TaskAlt),"docs" to ("Документы" to Icons.Default.Description),"search" to ("Поиск" to Icons.Default.Search),"archive" to ("Архив" to Icons.Default.Inventory2),"trash" to ("Корзина" to Icons.Default.DeleteSweep)).forEach{(route,item)->
                            DropdownMenuItem(text={Text(item.first)},leadingIcon={Icon(item.second,null,tint=MaterialTheme.colorScheme.primary)},onClick={moreOpen=false;nav.navigate(route){launchSingleTop=true}})
                        }
                        HorizontalDivider()
                        DropdownMenuItem(text={Text("Настройки")},leadingIcon={Icon(Icons.Default.Settings,null,tint=MaterialTheme.colorScheme.primary)},onClick={moreOpen=false;nav.navigate("settings")})
                    }
                }
            },
            label={Text("Ещё",fontSize=9.sp)}
        )
    }
}
@Composable fun navIcon(r:String)=when(r){"home"->Icons.Default.Dashboard;"calendar"->Icons.Default.CalendarMonth;"clients"->Icons.Default.PeopleAlt;else->Icons.Default.Gavel}
@Composable
fun MenuPage(nav: NavHostController) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, "Назад", tint = MaterialTheme.colorScheme.primary) }
            Surface(Modifier.size(52.dp), CircleShape, color = Color.Transparent) { Image(painterResource(R.drawable.ic_bull_launcher), contentDescription = "Эмблема Advokat CRM", modifier = Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Fit) }
            Spacer(Modifier.width(12.dp))
            Column { Text("Меню", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary); Text("ADVОKAT CRM", fontSize = 11.sp, color = Gold) }
        }
        HorizontalDivider(color = Gold.copy(alpha=.3f))
        listOf(
            "home" to ("Главная" to Icons.Default.Dashboard), "calendar" to ("Календарь" to Icons.Default.CalendarMonth),
            "clients" to ("Клиенты" to Icons.Default.PeopleAlt), "cases" to ("Дела" to Icons.Default.Gavel),
            "tasks" to ("Задачи" to Icons.Default.TaskAlt), "docs" to ("Документы" to Icons.Default.Description),
            "search" to ("Поиск" to Icons.Default.Search), "archive" to ("Архив" to Icons.Default.Inventory2), "trash" to ("Корзина" to Icons.Default.DeleteSweep), "settings" to ("Настройки" to Icons.Default.Settings)
        ).forEach { (route, item) ->
            NavigationDrawerItem(
                label = { Text(item.first, fontSize = 16.sp) }, selected = false,
                onClick = { nav.navigate(route) { launchSingleTop = true } },
                icon = { Icon(item.second, null, tint = if (route == "trash") Color(0xFF8A4A3A) else MaterialTheme.colorScheme.primary) },
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp)
            )
        }
    }
}

@Composable
fun CalendarScreen(s: Store, refresh: () -> Unit, onMenu: () -> Unit) {
    var deleting by remember { mutableStateOf<Case?>(null) }
    var monthOffset by remember { mutableIntStateOf(0) }
    var selectedDay by remember { mutableStateOf<String?>(null) }
    val cal = remember(monthOffset) { Calendar.getInstance().apply { add(Calendar.MONTH, monthOffset); set(Calendar.DAY_OF_MONTH, 1) } }
    val monthName = SimpleDateFormat("LLLL yyyy", Locale("ru")).format(cal.time).replaceFirstChar { it.uppercase() }
    val firstDow = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7
    val days = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    val cases = s.cases.filter { it.date.isNotBlank() && !it.status.equals("Исполнено", true) }
    val byDate = cases.groupBy { it.date.substringBefore(" ") }
    Column(Modifier.fillMaxSize()) {
        Header(onMenu, "Календарь")
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { monthOffset-- }) { Icon(Icons.Default.ChevronLeft, "Предыдущий месяц", tint = MaterialTheme.colorScheme.primary) }
            Text(monthName, Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            IconButton(onClick = { monthOffset++ }) { Icon(Icons.Default.ChevronRight, "Следующий месяц", tint = MaterialTheme.colorScheme.primary) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            listOf("Пн","Вт","Ср","Чт","Пт","Сб","Вс").forEach { Text(it, Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary) }
        }
        Column(Modifier.padding(horizontal = 10.dp)) {
            val total = ((firstDow + days + 6) / 7) * 7
            for (row in 0 until total step 7) {
                Row(Modifier.fillMaxWidth()) {
                    for (col in 0..6) {
                        val n = row + col - firstDow + 1
                        if (n in 1..days) {
                            val date = String.format(Locale.US, "%02d.%02d.%04d", n, cal.get(Calendar.MONTH) + 1, cal.get(Calendar.YEAR))
                            val hasEvent = byDate.containsKey(date)
                            val selected = selectedDay == date
                            Box(Modifier.weight(1f).padding(2.dp).aspectRatio(1f).clickable { selectedDay = date }) {
                                Surface(Modifier.fillMaxSize(), RoundedCornerShape(12.dp), color = if (selected) Forest else if (hasEvent) Gold.copy(alpha = .18f) else White) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                        Text(n.toString(), color = if (selected) White else MaterialTheme.colorScheme.primary, fontWeight = if (hasEvent) FontWeight.Bold else FontWeight.Normal)
                                        if (hasEvent) Icon(Icons.Default.Event, null, Modifier.size(12.dp), tint = if (selected) White else Gold)
                                    }
                                }
                            }
                        } else { Spacer(Modifier.weight(1f).padding(2.dp).aspectRatio(1f)) }
                    }
                }
            }
        }
        HorizontalDivider(Modifier.padding(vertical = 8.dp), color = Gold.copy(alpha = .25f))
        val shown = selectedDay?.let { byDate[it].orEmpty() } ?: cases.filter { it.date.substringBefore(" ") == SimpleDateFormat("dd.MM.yyyy", Locale.US).format(Date()) }
        Text(if (selectedDay == null) "Сегодня" else "Заседания ${selectedDay}", Modifier.padding(horizontal = 18.dp, vertical = 8.dp), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        if (shown.isEmpty()) Text("На выбранную дату заседаний нет", Modifier.padding(18.dp), color = MaterialTheme.colorScheme.secondary)
        else LazyColumn {
            items(shown, key = { it.id }) { c ->
                Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = White)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(c.date, fontWeight = FontWeight.Bold, color = Gold)
                            Text(c.no.ifBlank { "Без номера дела" }, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Text(c.client.ifBlank { "Без клиента" }, color = Ink)
                            Text(c.court.ifBlank { "Суд не указан" }, color = MaterialTheme.colorScheme.secondary)
                            Text("Вид: ${c.category.ifBlank { "Судебное заседание" }}", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                        }
                        androidx.compose.material3.IconButton(onClick = { deleting = c }) {
                            Icon(Icons.Default.DeleteOutline, "Удалить дело", tint = Color(0xFF8A4A3A))
                        }
                    }
                }
            }
        }
        deleting?.let { c -> ConfirmDeleteDialog("дело", c.no.ifBlank { "без номера" }, { deleting = null }) { softDeleteCase(s, c, refresh); deleting = null } }
    }
}
@Composable
fun Clients(s: Store, refresh: () -> Unit, onMenu: () -> Unit) {
    var editing by remember { mutableStateOf<Client?>(null) }
    var adding by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<Client?>(null) }
    var viewing by remember { mutableStateOf<Client?>(null) }
    var sort by rememberSaveable { mutableStateOf("Алфавиту") }
    var sortMenu by remember { mutableStateOf(false) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var addPayment by remember { mutableStateOf(false) }
    val clients = if (sort == "Алфавиту") s.clients.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.name.trim() }) else s.clients.sortedByDescending { it.created }
    Column(Modifier.fillMaxSize()) {
        Header(onMenu)
        ScreenTitle("Клиенты", Icons.Default.PeopleAlt) { adding = true }
        TabRow(selectedTabIndex = tab) {
            Tab(
                selected = tab == 0,
                onClick = { tab = 0 },
                icon = { Icon(Icons.Default.PeopleAlt, contentDescription = null) },
                text = { Text("Клиенты") }
            )
            Tab(
                selected = tab == 1,
                onClick = { tab = 1 },
                icon = { Icon(Icons.Default.Payments, contentDescription = null) },
                text = { Text("Платежи", fontSize = 12.sp) }
            )
        }
        if (tab == 0) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Сортировка:", fontWeight = FontWeight.Medium)
                Spacer(Modifier.width(8.dp))
                Box {
                    OutlinedButton(onClick = { sortMenu = true }) { Text(sort); Icon(Icons.Default.ArrowDropDown, null) }
                    DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                        listOf("Алфавиту", "Дате создания").forEach { v -> DropdownMenuItem(text = { Text(v) }, onClick = { sort = v; sortMenu = false }) }
                    }
                }
            }
            LazyColumn {
                items(clients, key = { it.id }) { c ->
                    val paid = if (c.payments.isNotEmpty()) c.payments.sumOf { it.amount.toDoubleOrNull() ?: 0.0 } else c.paid.toDoubleOrNull() ?: 0.0
                    EntityCard(Icons.Default.Person, c.name.ifBlank { "Без имени" }, "${c.phone} • ${c.email}\nОстаток: ${money(c.fee.toDoubleOrNull(), paid)}\nДела: ${s.cases.filter { it.clientId == c.id }.joinToString { it.no.ifBlank { "без номера" } }.ifBlank { "нет" }}", onDelete = { deleting = c }, onEdit = { editing = c }, onView = { viewing = c })
                }
            }
        } else {
            ClientPaymentsList(s, refresh, onAdd = { addPayment = true })
        }
        if (adding) ClientDialog(s, refresh, { adding = false })
        editing?.let { c -> ClientDialog(s, refresh, { editing = null }, c) }
        deleting?.let { c -> ConfirmDeleteDialog("клиента", c.name, { deleting = null }) { softDeleteClient(s, c, refresh); deleting = null } }
        viewing?.let { c -> ClientViewDialog(c) { viewing = null } }
        if (addPayment) PaymentDialog(s, refresh) { addPayment = false }
    }
}

@Composable
fun ClientPaymentsList(s: Store, refresh: () -> Unit, onAdd: () -> Unit) {
    val payments = s.clients.flatMap { c -> c.payments.map { p -> Triple(c, p, p.amount.toDoubleOrNull() ?: 0.0) } }.sortedByDescending { it.second.date }
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("Платежи клиентов", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        FloatingActionButton(onClick = onAdd, containerColor = Forest, contentColor = White) { Icon(Icons.Default.Add, "Новый платёж") }
    }
    if (payments.isEmpty()) Text("Платежей пока нет", Modifier.padding(20.dp), color = MaterialTheme.colorScheme.secondary)
    else LazyColumn {
        items(payments, key = { it.second.id }) { (c, p, _) ->
            Card(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 5.dp), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(14.dp)) {
                    Text(c.name.ifBlank { "Без имени" }, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text("${p.amount} ₽${if (p.date.isBlank()) "" else " • ${p.date}"}", fontWeight = FontWeight.Bold, color = Gold)
                    if (p.note.isNotBlank()) Text(p.note, fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                }
            }
        }
    }
}

@Composable
fun PaymentDialog(s: Store, refresh: () -> Unit, close: () -> Unit) {
    var clientId by remember { mutableStateOf(s.clients.firstOrNull()?.id ?: "") }
    var amount by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(SimpleDateFormat("dd.MM.yyyy", Locale.US).format(Date())) }
    var note by remember { mutableStateOf("") }
    var clientMenu by remember { mutableStateOf(false) }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    AlertDialog(onDismissRequest = close, title = { Text("Новый платёж") }, text = { Column(Modifier.verticalScroll(rememberScrollState())) {
        Box { OutlinedButton(onClick = { clientMenu = true }, modifier = Modifier.fillMaxWidth()) { Text(s.clients.firstOrNull { it.id == clientId }?.name ?: "Выберите клиента", Modifier.weight(1f)); Icon(Icons.Default.ArrowDropDown, null) }; DropdownMenu(expanded = clientMenu, onDismissRequest = { clientMenu = false }) { s.clients.forEach { c -> DropdownMenuItem(text = { Text(c.name.ifBlank { "Без имени" }) }, onClick = { clientId = c.id; clientMenu = false }) } } }
        Field(amount, { amount = it }, "Сумма", numeric = true, decimal = true)
        Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.weight(1f)) { Field(date, { date = it }, "Дата") }; IconButton(onClick = { val c=Calendar.getInstance(); DatePickerDialog(ctx,{_,y,m,d->date=String.format(Locale.US,"%02d.%02d.%04d",d,m+1,y)},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show() }) { Icon(Icons.Default.CalendarMonth, "Дата") } }
        Field(note, { note = it }, "Комментарий")
    } }, confirmButton = { Button(onClick = { val c=s.clients.firstOrNull{it.id==clientId}; val a=digitsInput(amount,true); if(c!=null && a.toDoubleOrNull()!=null && a.toDoubleOrNull()!!>0){ c.payments=(c.payments + Payment(amount=a,date=date,note=capitalizeInput(note))).toMutableList(); s.clients=s.clients.filterNot{it.id==c.id}.toMutableList().apply{add(c)}; refresh(); close() } }) { Text("Сохранить") } }, dismissButton = { TextButton(onClick = close) { Text("Отмена") } })
}

@Composable
fun Cases(s: Store, refresh: () -> Unit, onMenu: () -> Unit) {
    var editing by remember { mutableStateOf<Case?>(null) }
    var adding by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<Case?>(null) }
    var viewing by remember { mutableStateOf<Case?>(null) }
    val active = s.cases.filter { it.status != "Исполнено" }
    Column(Modifier.fillMaxSize()) {
        Header(onMenu)
        ScreenTitle("Дела", Icons.Default.Gavel) { adding = true }
        if (active.isEmpty()) Text("Активных дел нет", Modifier.padding(20.dp), color = MaterialTheme.colorScheme.secondary)
        else LazyColumn { items(active, key = { it.id }) { c -> EntityCard(Icons.Default.Gavel, "${c.no} • ${c.client}", "${c.court}\n${c.category} • ${c.status}\nРассмотрение: ${c.date}\n${c.description.ifBlank { c.notes }.ifBlank { "Описание дела не задано" }}", onDelete = { deleting = c }, onEdit = { editing = c }, onView = { viewing = c }) } }
        if (adding) CaseDialog(s, refresh, { adding = false })
        editing?.let { c -> CaseDialog(s, refresh, { editing = null }, c) }
        deleting?.let { c -> ConfirmDeleteDialog("дело", c.no.ifBlank { "без номера" }, { deleting = null }) { softDeleteCase(s, c, refresh); deleting = null } }
        viewing?.let { c -> CaseViewDialog(s, c) { viewing = null } }
    }
}

@Composable
fun Archive(s: Store, refresh: () -> Unit, onMenu: () -> Unit) {
    var editing by remember { mutableStateOf<Case?>(null) }
    var deleting by remember { mutableStateOf<Case?>(null) }
    var viewing by remember { mutableStateOf<Task?>(null) }
    val archived = s.cases.filter { it.status == "Исполнено" }
    Column(Modifier.fillMaxSize()) {
        Header(onMenu)
        Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Inventory2, null, tint = Gold); Spacer(Modifier.width(10.dp)); Text("Архив", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary) }
        if (archived.isEmpty()) Text("Исполненных дел пока нет", Modifier.padding(20.dp), color = MaterialTheme.colorScheme.secondary)
        else LazyColumn { items(archived, key = { it.id }) { c ->
            EntityCard(Icons.Default.Inventory2, "${c.no} • ${c.client}", "${c.court}\n${c.category} • Исполнено\nРассмотрение: ${c.date}\n${c.description.ifBlank { c.notes }}", onDelete = { deleting = c }, onEdit = { editing = c })
            s.tasks.filter { it.caseId == c.id }.sortedBy { parseDateTime(it.deadline) ?: Long.MAX_VALUE }.forEach { t ->
                Card(Modifier.fillMaxWidth().padding(start = 30.dp, end = 14.dp, top = 2.dp, bottom = 5.dp), shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.TaskAlt, null, tint = Gold); Spacer(Modifier.width(8.dp)); Text(t.title, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); Text(t.status, fontSize = 11.sp) }
                        Text("Срок: ${t.deadline}", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.clickable { viewing = t })
                        if (t.description.isNotBlank()) Text(t.description, fontSize = 12.sp)
                    }
                }
            }
        } }
        editing?.let { c -> CaseDialog(s, refresh, { editing = null }, c) }
        deleting?.let { c -> ConfirmDeleteDialog("дело", c.no.ifBlank { "без номера" }, { deleting = null }) { softDeleteCase(s, c, refresh); deleting = null } }
        viewing?.let { t -> TaskViewDialog(t) { viewing = null } }
    }
}

@Composable
fun Tasks(s: Store, refresh: () -> Unit, onMenu: () -> Unit) {
    var editing by remember { mutableStateOf<Task?>(null) }
    var adding by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<Task?>(null) }
    var viewing by remember { mutableStateOf<Task?>(null) }
    val archivedCaseIds = s.cases.filter { it.status == "Исполнено" }.map { it.id }.toSet()
    val activeTasks = s.tasks.filter { it.caseId.isBlank() || it.caseId !in archivedCaseIds }
    val grouped = activeTasks.groupBy { it.caseId.ifBlank { "__none__" } }
    Column(Modifier.fillMaxSize()) {
        Header(onMenu)
        ScreenTitle("Задачи", Icons.Default.TaskAlt) { adding = true }
        LazyColumn {
            grouped.entries.sortedWith(compareBy({ if (it.key == "__none__") "" else s.cases.firstOrNull { c -> c.id == it.key }?.no ?: "" }, { it.key })).forEach { entry ->
                val case = if (entry.key == "__none__") null else s.cases.firstOrNull { it.id == entry.key }
                item {
                    Text(if (case == null) "Без привязки к делу" else "Дело № ${case.no.ifBlank { "без номера" }}", Modifier.fillMaxWidth().padding(start = 18.dp, top = 14.dp, end = 18.dp, bottom = 6.dp), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
                items(entry.value.sortedBy { parseDateTime(it.deadline) ?: Long.MAX_VALUE }, key = { it.id }) { t ->
                    EntityCard(Icons.Default.TaskAlt, t.title, "Срок исполнения: ${t.deadline}\n${t.priority} • ${if (t.status == "Открыта") "В работе" else t.status}\n${t.description}", onDelete = { deleting = t }, onEdit = { editing = t }, onView = { viewing = t })
                }
            }
        }
        if (adding) TaskDialog(s, refresh, { adding = false })
        editing?.let { t -> TaskDialog(s, refresh, { editing = null }, t) }
        deleting?.let { t -> ConfirmDeleteDialog("задачу", t.title, { deleting = null }) { softDeleteTask(s, t, refresh); deleting = null } }
        viewing?.let { t -> TaskViewDialog(t) { viewing = null } }
    }
}

@Composable
fun Documents(s: Store, refresh: () -> Unit, onMenu: () -> Unit) {
    var folder by remember { mutableStateOf("") }
    var addingFolder by remember { mutableStateOf(false) }
    var addingDoc by remember { mutableStateOf(false) }
    var folderName by remember { mutableStateOf("") }
    var deleteDoc by remember { mutableStateOf<Doc?>(null) }
    var deleteFolder by remember { mutableStateOf<DocFolder?>(null) }
    var editingDoc by remember { mutableStateOf<Doc?>(null) }
    val folders = s.docFolders
    val currentDocs = s.docs.filter { it.folderId == folder }
    Column(Modifier.fillMaxSize()) {
        Header(onMenu, "Документы")
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Folder, null, tint = Gold); Spacer(Modifier.width(10.dp)); Text(if (folder.isBlank()) "Все документы" else folders.firstOrNull { it.id == folder }?.name ?: "Папка", Modifier.weight(1f), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            IconButton(onClick = { addingFolder = true }) { Icon(Icons.Default.CreateNewFolder, "Новая папка", tint = MaterialTheme.colorScheme.primary) }
            IconButton(onClick = { addingDoc = true }) { Icon(Icons.Default.UploadFile, "Загрузить", tint = MaterialTheme.colorScheme.primary) }
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = folder.isBlank(), onClick = { folder = "" }, label = { Text("Все") })
            folders.forEach { f ->
                Row(Modifier.clickable { folder = f.id }, verticalAlignment = Alignment.CenterVertically) {
                    FilterChip(selected = folder == f.id, onClick = { folder = f.id }, label = { Text(f.name) }, leadingIcon = { Icon(Icons.Default.Folder, null) })
                    IconButton(onClick = { deleteFolder = f }) { Icon(Icons.Default.DeleteOutline, "Удалить папку", tint = Color(0xFF8A4A3A)) }
                }
            }
        }
        if (currentDocs.isEmpty()) Text("Документов в этой папке пока нет", Modifier.padding(20.dp), color = MaterialTheme.colorScheme.secondary)
        else LazyColumn { items(currentDocs, key = { it.id }) { d -> EntityCard(Icons.Default.Description, d.name, "${d.type} • ${d.caseNo.ifBlank { "Без привязки к делу" }}", onDelete = { deleteDoc = d }, onEdit = { editingDoc = d }, onView = { openDocumentFile(s, d) }) } }
        if (addingFolder) AlertDialog(onDismissRequest = { addingFolder = false }, title = { Text("Новая папка") }, text = { Field(folderName, { folderName = it }, "Название папки") }, confirmButton = { Button({ if (folderName.isNotBlank()) { s.docFolders = (s.docFolders + DocFolder(name = capitalizeInput(folderName.trim()))).toMutableList(); folderName = ""; addingFolder = false; refresh() } }) { Text("Создать") } }, dismissButton = { TextButton({ addingFolder = false }) { Text("Отмена") } })
        if (addingDoc) DocDialog(s, refresh, { addingDoc = false }, folder)
        editingDoc?.let { d -> DocDialog(s, refresh, { editingDoc = null }, d.folderId, d) }
        deleteDoc?.let { d -> ConfirmDeleteDialog("документ", d.name, { deleteDoc = null }) { softDeleteDoc(s, d, refresh); deleteDoc = null } }
        deleteFolder?.let { f -> ConfirmDeleteDialog("папку", f.name, { deleteFolder = null }) { s.docFolders = s.docFolders.filter { it.id != f.id }.toMutableList(); s.docs = s.docs.map { if (it.folderId == f.id) it.copy(folderId = "") else it }.toMutableList(); if (folder == f.id) folder = ""; deleteFolder = null; refresh() } }
    }
}

fun openDocumentFile(s: Store, d: Doc) {
    val ctx = s.context(); val file = File(d.path)
    if (!file.exists()) { android.widget.Toast.makeText(ctx, "Файл не найден", android.widget.Toast.LENGTH_LONG).show(); return }
    val uri = androidx.core.content.FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", file)
    val mime = when (file.extension.lowercase(Locale.US)) { "pdf" -> "application/pdf"; "doc" -> "application/msword"; "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"; "txt" -> "text/plain"; "jpg", "jpeg" -> "image/jpeg"; "png" -> "image/png"; else -> "*/*" }
    val intent = Intent(Intent.ACTION_VIEW).apply { setDataAndType(uri, mime); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK) }
    try {
        val chooser = Intent.createChooser(intent, if (mime == "application/pdf") "Открыть PDF" else "Открыть документ").apply { addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK) }
        ctx.startActivity(chooser)
    } catch (_: Exception) {
        android.widget.Toast.makeText(ctx, if (mime == "application/pdf") "Установите приложение для чтения PDF (например, Adobe Acrobat или другое PDF-приложение)" else "Нет приложения для открытия этого формата", android.widget.Toast.LENGTH_LONG).show()
    }
}

@Composable
fun Search(s: Store, onMenu: () -> Unit) { var q by remember { mutableStateOf("") }; Column { Header(onMenu); Text("Поиск", Modifier.padding(horizontal = 18.dp), fontSize = 27.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary); OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(18.dp), placeholder = { Text("Клиент, номер дела, суд, телефон, документ") }, leadingIcon = { Icon(Icons.Default.Search, null) }, shape = RoundedCornerShape(16.dp)); val qq = q.trim().lowercase(); LazyColumn { items(s.cases.filter { listOf(it.no, it.client, it.court).any { v -> v.lowercase().contains(qq) } }) { Text("Дело: ${it.no} — ${it.court}", Modifier.padding(12.dp), color = MaterialTheme.colorScheme.primary) }; items(s.clients.filter { listOf(it.name, it.phone, it.email).any { v -> v.lowercase().contains(qq) } }) { Text("Клиент: ${it.name} — ${it.phone}", Modifier.padding(12.dp), color = MaterialTheme.colorScheme.primary) }; items(s.docs.filter { listOf(it.name, it.caseNo, it.type).any { v -> v.lowercase().contains(qq) } }) { Text("Документ: ${it.name} — ${it.caseNo}", Modifier.padding(12.dp), color = MaterialTheme.colorScheme.primary) } } } }

fun restoreTrashItem(s: Store, t: TrashItem) {
    val gson = Gson()
    var restored = false
    when (t.type) {
        "client" -> runCatching { gson.fromJson(t.payload, Client::class.java) }.getOrNull()?.let { item -> s.clients = (s.clients.filter { it.id != item.id } + item).toMutableList(); restored = true }
        "case" -> runCatching { gson.fromJson(t.payload, Case::class.java) }.getOrNull()?.let { item -> s.cases = (s.cases.filter { it.id != item.id } + item).toMutableList(); restored = true }
        "task" -> runCatching { gson.fromJson(t.payload, Task::class.java) }.getOrNull()?.let { item -> s.tasks = (s.tasks.filter { it.id != item.id } + item).toMutableList(); restored = true }
        "doc" -> runCatching { gson.fromJson(t.payload, Doc::class.java) }.getOrNull()?.let { item -> s.docs = (s.docs.filter { it.id != item.id } + item).toMutableList(); restored = true }
    }
    if (restored) s.trash = s.trash.filter { it.id != t.id }.toMutableList()
}
@Composable
fun Trash(s: Store, refresh: () -> Unit, onMenu: () -> Unit) {
    val items = s.trash.sortedByDescending { it.deleted }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Header(onMenu,"Корзина")
        Row(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=14.dp),verticalAlignment=Alignment.CenterVertically){
            Column(Modifier.weight(1f)){Text("Корзина",fontSize=24.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary);Text("Удалённые элементы хранятся 30 дней",fontSize=12.sp,color=MaterialTheme.colorScheme.secondary)}
            Surface(Modifier.size(42.dp),CircleShape,color=Gold.copy(alpha=.14f)){Box(contentAlignment=Alignment.Center,modifier=Modifier.fillMaxSize()){Icon(Icons.Default.DeleteSweep,null,tint=Gold)}}
        }
        if(items.isEmpty()) Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally){Icon(Icons.Default.DeleteSweep,null,tint=Gold,modifier=Modifier.size(54.dp));Spacer(Modifier.height(8.dp));Text("Корзина пуста",fontSize=18.sp,fontWeight=FontWeight.Bold);Text("Восстановленные и окончательно удалённые элементы исчезают сразу",fontSize=12.sp,color=MaterialTheme.colorScheme.secondary)}}
        else LazyColumn { items(items,key={it.id}){t->
            Card(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=5.dp),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),border=BorderStroke(1.dp,Gold.copy(alpha=.18f))){
                Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){
                    Surface(Modifier.size(42.dp),CircleShape,color=Gold.copy(alpha=.13f)){Box(contentAlignment=Alignment.Center,modifier=Modifier.fillMaxSize()){Icon(Icons.Default.DeleteSweep,null,tint=Gold)}}
                    Spacer(Modifier.width(11.dp)); Column(Modifier.weight(1f)){Text(t.title.ifBlank{"Без названия"},fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary);Text(t.type.replaceFirstChar{it.uppercase()},fontSize=12.sp,color=MaterialTheme.colorScheme.secondary);Text("Удалено: "+SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.US).format(Date(t.deleted)),fontSize=11.sp,color=MaterialTheme.colorScheme.secondary)}
                    IconButton(onClick={restoreTrashItem(s,t);refresh()}){Icon(Icons.Default.Restore,"Восстановить",tint=Forest)}
                    IconButton(onClick={s.trash=s.trash.filterNot{it.id==t.id}.toMutableList();refresh()}){Icon(Icons.Default.DeleteForever,"Удалить навсегда",tint=Color(0xFF8A4A3A))}
                }
            }
        }}
    }
}

@Composable
fun ConfirmDeleteDialog(type: String, title: String, cancel: () -> Unit, confirm: () -> Unit) { AlertDialog(onDismissRequest = cancel, title = { Text("Удалить $type?") }, text = { Text("Вы хотите удалить $type «$title»?") }, confirmButton = { Button(onClick = confirm) { Text("Да") } }, dismissButton = { TextButton(onClick = cancel) { Text("Нет") } }) }

fun softDeleteTask(s: Store, t: Task, r: () -> Unit) { s.trash = (s.trash + TrashItem(type = "task", title = t.title, payload = Gson().toJson(t))).toMutableList(); s.tasks = s.tasks.filter { it.id != t.id }.toMutableList(); r() }
fun softDeleteDoc(s: Store, d: Doc, r: () -> Unit) { s.trash = (s.trash + TrashItem(type = "doc", title = d.name, payload = Gson().toJson(d))).toMutableList(); s.docs = s.docs.filter { it.id != d.id }.toMutableList(); r() }

@Composable fun ScreenTitle(t: String, i: androidx.compose.ui.graphics.vector.ImageVector, add: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=14.dp), verticalAlignment=Alignment.CenterVertically) {
        Surface(Modifier.size(42.dp),CircleShape,color=Gold.copy(alpha=.14f)){Box(contentAlignment=Alignment.Center,modifier=Modifier.fillMaxSize()){Icon(i,null,tint=Gold)}}
        Spacer(Modifier.width(11.dp))
        Text(t, Modifier.weight(1f), fontSize=24.sp, fontWeight=FontWeight.Bold, color=MaterialTheme.colorScheme.primary)
        FloatingActionButton(add, containerColor=Forest, contentColor=White, modifier=Modifier.size(46.dp)) { Icon(Icons.Default.Add,null) }
    }
}
@Composable
fun EntityCard(i: androidx.compose.ui.graphics.vector.ImageVector, title: String, sub: String, onDelete: () -> Unit, onEdit: () -> Unit, onView: () -> Unit = onEdit) = Card(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 5.dp), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), border=BorderStroke(1.dp,Gold.copy(alpha=.18f))) {
    Row(Modifier.padding(12.dp), verticalAlignment=Alignment.CenterVertically){
        Box(Modifier.width(4.dp).height(58.dp).clip(RoundedCornerShape(4.dp)).background(Gold)); Spacer(Modifier.width(10.dp))
        Surface(Modifier.size(42.dp),CircleShape,color=Gold.copy(alpha=.12f)){Box(contentAlignment=Alignment.Center,modifier=Modifier.fillMaxSize()){Icon(i,null,tint=Gold)}}
        Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f).clickable(onClick=onView)){Text(title,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary,maxLines=2,overflow=TextOverflow.Ellipsis);Text(sub,color=MaterialTheme.colorScheme.secondary,fontSize=12.sp,maxLines=4,overflow=TextOverflow.Ellipsis)}
        IconButton(onClick=onEdit){Icon(Icons.Default.Edit,"Редактировать",tint=MaterialTheme.colorScheme.primary)}
        IconButton(onClick=onDelete){Icon(Icons.Default.DeleteOutline,"Удалить",tint=Color(0xFF8A4A3A))}
    }
}

fun money(a: Double?, b: Double?): String = "%.0f ₽".format((a ?: 0.0) - (b ?: 0.0))
fun completeTasksForCase(s: Store, caseId: String) {
    if (caseId.isBlank()) return
    val updated = s.tasks.map { if (it.caseId == caseId) it.copy(status = "Исполнено") else it }.toMutableList()
    s.tasks = updated
}

fun softDeleteCase(s: Store, c: Case, r: () -> Unit) { s.trash = (s.trash + TrashItem(type = "case", title = c.no, payload = Gson().toJson(c))).toMutableList(); s.cases = s.cases.filter { it.id != c.id }.toMutableList(); r() }
fun softDeleteClient(s: Store, c: Client, r: () -> Unit) { s.trash = (s.trash + TrashItem(type = "client", title = c.name, payload = Gson().toJson(c))).toMutableList(); s.clients = s.clients.filter { it.id != c.id }.toMutableList(); r() }

fun capitalizeInput(value: String): String = value.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale("ru")) else it.toString() }
fun digitsInput(value: String, allowDecimal: Boolean = false, allowPlus: Boolean = false): String {
    val allowed = if (allowDecimal) "0123456789.," else "0123456789"
    return value.filter { it in allowed || (allowPlus && it == '+' && value.indexOf(it) == 0) }
}

@Composable fun Field(v: String, on: (String) -> Unit, label: String, numeric: Boolean = false, decimal: Boolean = false, phone: Boolean = false) = OutlinedTextField(
    value = v,
    onValueChange = { value -> on(if (numeric) digitsInput(value, decimal, phone) else if (label.equals("Email", true)) value else capitalizeInput(value)) },
    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
    enabled = true,
    readOnly = false,
    singleLine = true,
    label = { Text(label) },
    placeholder = { if (v.isBlank()) Text("Введите значение") },
    shape = RoundedCornerShape(12.dp),
    keyboardOptions = if (numeric) KeyboardOptions(keyboardType = if (phone) KeyboardType.Phone else if (decimal) KeyboardType.Decimal else KeyboardType.Number) else KeyboardOptions(keyboardType = KeyboardType.Text)
)

fun parseDateTime(value: String): Long? {
    val v = value.trim()
    if (v.isBlank()) return null
    val formats = listOf("dd.MM.yyyy HH:mm", "dd.MM.yyyy H:mm", "dd.MM.yyyy")
    for (pattern in formats) runCatching { return SimpleDateFormat(pattern, Locale.US).apply { isLenient = false }.parse(v)?.time }
    return null
}

@Composable fun ClientViewDialog(c: Client, close: () -> Unit) {
    val legacyPaid = c.paid.toDoubleOrNull() ?: 0.0
    val newPaymentsTotal = c.payments.sumOf { it.amount.toDoubleOrNull() ?: 0.0 }
    val fee = c.fee.toDoubleOrNull() ?: 0.0
    val balance = fee - legacyPaid - newPaymentsTotal
    AlertDialog(onDismissRequest=close,title={Text("Клиент")},text={Column(Modifier.verticalScroll(rememberScrollState())){
        Text(c.name.ifBlank{"Без имени"},fontWeight=FontWeight.Bold,fontSize=20.sp,color=MaterialTheme.colorScheme.primary); Spacer(Modifier.height(10.dp));
        Text("Телефон: ${c.phone.ifBlank{"—"}}"); Text("Email: ${c.email.ifBlank{"—"}}"); Spacer(Modifier.height(8.dp));
        Text("Платежи",fontWeight=FontWeight.Bold); Text("Сумма услуг: ${"%.2f".format(fee)} ₽");
        Text("Внесено ранее: ${"%.2f".format(legacyPaid)} ₽");
        Text("Новые платежи: ${"%.2f".format(newPaymentsTotal)} ₽");
        Text("Остаток: ${"%.2f".format(balance)} ₽",fontWeight=FontWeight.Bold);
        if(c.payments.isNotEmpty()) c.payments.forEachIndexed { i,p -> Text("${i+1}. ${p.amount} ₽ • ${p.date.ifBlank{"дата не указана"}}${if(p.note.isBlank()) "" else " • ${p.note}"}",fontSize=12.sp) };
        Text("Просмотр без редактирования",fontSize=11.sp,color=MaterialTheme.colorScheme.secondary,modifier=Modifier.padding(top=8.dp))
    }},confirmButton={TextButton(close){Text("Закрыть")}})
}

@Composable fun CaseViewDialog(s: Store, c: Case, close: () -> Unit) { val docs = s.docs.filter { it.caseId == c.id }; AlertDialog(onDismissRequest=close,title={Text("Дело")},text={Column(Modifier.verticalScroll(rememberScrollState())){Text(c.no.ifBlank{"Без номера"},fontWeight=FontWeight.Bold,fontSize=20.sp,color=MaterialTheme.colorScheme.primary); Text("Клиент: ${c.client.ifBlank{"—"}}"); Text("Суд / орган: ${c.court.ifBlank{"—"}}"); Text("Категория: ${c.category.ifBlank{"—"}}"); Text("Дата и время: ${c.date.ifBlank{"—"}}"); Text("Статус: ${c.status}"); Text("Описание дела",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=10.dp)); Text(c.description.ifBlank { c.notes }.ifBlank { "—" }); Spacer(Modifier.height(10.dp)); Text("Документы дела",fontWeight=FontWeight.Bold); if(docs.isEmpty()) Text("Привязанных документов нет",color=MaterialTheme.colorScheme.secondary) else docs.forEach { d -> Row(Modifier.fillMaxWidth().padding(vertical=5.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Description,null,tint=Gold); Spacer(Modifier.width(8.dp)); Column(Modifier.weight(1f).clickable { openDocumentFile(s, d) }) { Text(d.name.ifBlank{"Документ"}); Text(d.type,fontSize=11.sp,color=MaterialTheme.colorScheme.secondary) }}}; if(c.history.isNotEmpty()){Spacer(Modifier.height(8.dp));Text("История",fontWeight=FontWeight.Bold);c.history.forEach{Text("• $it")}}}},confirmButton={TextButton(close){Text("Закрыть")}}) }

@Composable
fun ClientDialog(s: Store, r: () -> Unit, close: () -> Unit, old: Client? = null) {
    var n by remember { mutableStateOf(old?.name ?: "") }
    var ph by remember { mutableStateOf(old?.phone ?: "") }
    var em by remember { mutableStateOf(old?.email ?: "") }
    var fee by remember { mutableStateOf(old?.fee ?: "0") }
    val legacyPaid = old?.paid?.toDoubleOrNull() ?: 0.0
    var payments by remember { mutableStateOf((old?.payments ?: emptyList()).map { it.copy() }.toMutableList()) }
    var paymentTab by rememberSaveable { mutableIntStateOf(0) }
    var newPaymentAmount by remember { mutableStateOf("") }
    var newPaymentDate by remember { mutableStateOf(SimpleDateFormat("dd.MM.yyyy", Locale.US).format(Date())) }
    var newPaymentNote by remember { mutableStateOf("") }
    val newPaymentsTotal = payments.sumOf { it.amount.toDoubleOrNull() ?: 0.0 }
    val balance = (fee.toDoubleOrNull() ?: 0.0) - legacyPaid - newPaymentsTotal
    val ctx = androidx.compose.ui.platform.LocalContext.current

    fun pickPaymentDate() {
        val c = Calendar.getInstance()
        DatePickerDialog(ctx, { _, y, m, d ->
            newPaymentDate = String.format(Locale.US, "%02d.%02d.%04d", d, m + 1, y)
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
    }
    fun pickExistingPaymentDate(index: Int) {
        val c = Calendar.getInstance()
        DatePickerDialog(ctx, { _, y, m, d ->
            payments = payments.mapIndexed { idx, p ->
                if (idx == index) p.copy(date = String.format(Locale.US, "%02d.%02d.%04d", d, m + 1, y)) else p
            }.toMutableList()
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
    }
    AlertDialog(
        onDismissRequest = close,
        title = { Text(if (old == null) "Новый клиент" else "Редактировать клиента") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                TabRow(selectedTabIndex = paymentTab) {
                    Tab(
                        selected = paymentTab == 0,
                        onClick = { paymentTab = 0 },
                        icon = { Icon(Icons.Default.Person, contentDescription = null) },
                        text = { Text("Данные", fontSize = 12.sp) }
                    )
                    Tab(
                        selected = paymentTab == 1,
                        onClick = { paymentTab = 1 },
                        icon = { Icon(Icons.Default.Payments, contentDescription = null) },
                        text = { Text("Платежи", fontSize = 12.sp) }
                    )
                    Tab(
                        selected = paymentTab == 2,
                        onClick = { paymentTab = 2 },
                        icon = { Icon(Icons.Default.AddCard, contentDescription = null) },
                        text = { Text("Новый платеж", fontSize = 12.sp) }
                    )
                }
                Spacer(Modifier.height(8.dp))

                when (paymentTab) {
                    0 -> {
                        Card(
                            Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Column(Modifier.padding(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Person, null, tint = Gold)
                                    Spacer(Modifier.width(8.dp))
                                    Text("Основные данные", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                }
                                Spacer(Modifier.height(6.dp))
                                Field(n, { n = it }, "ФИО")
                                Field(ph, { ph = it }, "Телефон", numeric = true, phone = true)
                                Field(em, { em = it }, "Email")
                                Field(fee, { fee = it }, "Сумма услуг", numeric = true, decimal = true)
                                Text("Все поля доступны для ввода и редактирования.", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(top = 4.dp))
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                    1 -> {
                        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                            Column(Modifier.padding(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Payments, null, tint = Gold)
                                    Spacer(Modifier.width(8.dp))
                                    Text("Платежи клиента", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                }
                                Spacer(Modifier.height(8.dp))
                                Text("Внесено ранее: ${"%.2f".format(legacyPaid)} ₽", fontSize = 13.sp, color = MaterialTheme.colorScheme.secondary)
                                Text("Новые платежи: ${"%.2f".format(newPaymentsTotal)} ₽", fontSize = 13.sp, color = MaterialTheme.colorScheme.secondary)
                                Text("Остаток: ${"%.2f".format(balance)} ₽", fontWeight = FontWeight.Bold, color = if (balance > 0) MaterialTheme.colorScheme.primary else Green)
                                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                                if (payments.isEmpty()) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Info, null, tint = MaterialTheme.colorScheme.secondary)
                                        Spacer(Modifier.width(8.dp))
                                        Text("Новых платежей пока нет", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                                    }
                                } else {
                                    payments.forEachIndexed { i, p ->
                                        Card(
                                            Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                            shape = RoundedCornerShape(14.dp),
                                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                                        ) {
                                            Row(Modifier.padding(10.dp), verticalAlignment = Alignment.Top) {
                                                Icon(Icons.Default.ReceiptLong, null, tint = Gold, modifier = Modifier.padding(top = 8.dp))
                                                Spacer(Modifier.width(8.dp))
                                                Column(Modifier.weight(1f)) {
                                                    Field(p.amount, { v -> payments = payments.mapIndexed { idx, x -> if (idx == i) x.copy(amount = v) else x }.toMutableList() }, "Сумма платежа", numeric = true, decimal = true)
                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                        Box(Modifier.weight(1f)) { Field(p.date, { v -> payments = payments.mapIndexed { idx, x -> if (idx == i) x.copy(date = v) else x }.toMutableList() }, "Дата платежа") }
                                                        IconButton(onClick = { pickExistingPaymentDate(i) }) { Icon(Icons.Default.CalendarMonth, "Дата платежа") }
                                                    }
                                                    Field(p.note, { v -> payments = payments.mapIndexed { idx, x -> if (idx == i) x.copy(note = v) else x }.toMutableList() }, "Комментарий")
                                                }
                                                IconButton(onClick = { payments = payments.toMutableList().also { it.removeAt(i) } }) {
                                                    Icon(Icons.Default.DeleteOutline, "Удалить платёж", tint = Color(0xFF8A4A3A))
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else -> {
                        Card(
                            Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Column(Modifier.padding(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.AddCard, null, tint = Gold)
                                    Spacer(Modifier.width(8.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text("Новый платеж", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                        Text("Добавьте отдельную запись платежа", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                                    }
                                }
                                Spacer(Modifier.height(8.dp))
                                Field(newPaymentAmount, { newPaymentAmount = it }, "Сумма", numeric = true, decimal = true)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.weight(1f)) { Field(newPaymentDate, { newPaymentDate = it }, "Дата") }
                                    IconButton(onClick = { pickPaymentDate() }) { Icon(Icons.Default.CalendarMonth, "Дата платежа") }
                                }
                                Field(newPaymentNote, { newPaymentNote = it }, "Комментарий")
                                Spacer(Modifier.height(8.dp))
                                Button(
                                    onClick = {
                                        val amount = digitsInput(newPaymentAmount, true)
                                        if ((amount.toDoubleOrNull() ?: 0.0) > 0) {
                                            payments = (payments + Payment(amount = amount, date = newPaymentDate, note = capitalizeInput(newPaymentNote))).toMutableList()
                                            newPaymentAmount = ""
                                            newPaymentNote = ""
                                            paymentTab = 1
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.AddCard, null)
                                    Spacer(Modifier.width(6.dp))
                                    Text("Добавить платеж")
                                }
                                Text("Поле «Внесено ранее» не изменяется. Новый платеж сохраняется отдельной записью.", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(top = 7.dp))
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                val c = old ?: Client(created = System.currentTimeMillis())
                c.name = capitalizeInput(n)
                c.phone = digitsInput(ph, false, true)
                c.email = em.trim()
                c.fee = digitsInput(fee, true)
                c.payments = payments.map { it.copy(amount = digitsInput(it.amount, true), note = capitalizeInput(it.note)) }.toMutableList()
                c.paid = old?.paid ?: "0"
                val list = s.clients.toMutableList()
                val i = list.indexOfFirst { it.id == c.id }
                if (i >= 0) list[i] = c else list.add(c)
                s.clients = list
                r()
                close()
            }) { Text("Сохранить") }
        },
        dismissButton = { TextButton(close) { Text("Отмена") } }
    )
}
@Composable
fun CaseDialog(s: Store, r: () -> Unit, close: () -> Unit, old: Case? = null) {
    var no by remember { mutableStateOf(old?.no ?: "") }; var cl by remember { mutableStateOf(old?.client ?: "") }; var clientId by remember { mutableStateOf(old?.clientId ?: "") }; var clientMenu by remember { mutableStateOf(false) }; var court by remember { mutableStateOf(old?.court ?: "") }; var cat by remember { mutableStateOf(old?.category ?: "") }; var description by remember { mutableStateOf(old?.description ?: old?.notes ?: "") }; var date by remember { mutableStateOf(old?.date?.substringBefore(" ") ?: "") }; var time by remember { mutableStateOf(old?.date?.substringAfter(" ").takeIf { it != old?.date } ?: "") }; var status by remember { mutableStateOf(if (old?.status == "Исполнено") "Исполнено" else "В работе") }; val ctx = androidx.compose.ui.platform.LocalContext.current
    fun pickDate() { val c = Calendar.getInstance(); DatePickerDialog(ctx, { _, y, m, d -> date = String.format(Locale.US, "%02d.%02d.%04d", d, m + 1, y) }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show() }
    fun pickTime() { val c = Calendar.getInstance(); TimePickerDialog(ctx, { _, h, m -> time = String.format(Locale.US, "%02d:%02d", h, m) }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show() }
    AlertDialog(onDismissRequest = close, title = { Text(if (old == null) "Новое дело" else "Редактировать дело") }, text = { Column(Modifier.verticalScroll(rememberScrollState())) { Field(no, { no = it.filter { ch -> ch.isDigit() || ch in "/-." } }, "Номер дела"); Box { OutlinedButton({ clientMenu = true }, Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Text(if (cl.isBlank()) "Выберите клиента" else cl, Modifier.weight(1f)); Icon(Icons.Default.ArrowDropDown, null) }; DropdownMenu(clientMenu, { clientMenu = false }) { DropdownMenuItem({ Text("Без привязки") }, { clientId = ""; cl = ""; clientMenu = false }); s.clients.forEach { c -> DropdownMenuItem({ Text(c.name.ifBlank { "Без имени" }) }, { clientId = c.id; cl = c.name; clientMenu = false }) } } }; Field(court, { court = it }, "Суд / орган"); Field(cat, { cat = it }, "Категория"); OutlinedTextField(description, { description = capitalizeInput(it) }, Modifier.fillMaxWidth().heightIn(min = 100.dp).padding(vertical = 4.dp), label = { Text("Описание дела") }, shape = RoundedCornerShape(12.dp)); Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.weight(1f)) { Field(date, { date = it }, "Дата рассмотрения") }; IconButton(onClick = { pickDate() }) { Icon(Icons.Default.CalendarMonth, "Выбрать дату") } }; Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.weight(1f)) { Field(time, { time = it }, "Время") }; IconButton(onClick = { pickTime() }) { Icon(Icons.Default.Schedule, "Выбрать время") } }; var statusMenu by remember { mutableStateOf(false) }; OutlinedButton({ statusMenu = true }, Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Text(status, Modifier.weight(1f)); Icon(Icons.Default.ArrowDropDown, null) }; DropdownMenu(statusMenu, { statusMenu = false }) { listOf("В работе", "Исполнено").forEach { v -> DropdownMenuItem({ Text(v) }, { status = v; statusMenu = false }) } } } }, confirmButton = { Button(onClick = { val c = old ?: Case(); val linked = s.clients.firstOrNull { it.id == clientId }; c.no = no.filter { ch -> ch.isDigit() || ch in "/-." }; c.client = linked?.name ?: capitalizeInput(cl); c.clientId = linked?.id ?: clientId; c.court = capitalizeInput(court); c.category = capitalizeInput(cat); c.description = capitalizeInput(description); c.notes = c.description; c.date = listOf(date, time).filter { it.isNotBlank() }.joinToString(" "); c.status = status; c.updated = System.currentTimeMillis(); val list = s.cases.toMutableList(); val i = list.indexOfFirst { it.id == c.id }; if (i >= 0) list[i] = c else list.add(c); s.cases = list; if (c.status == "Исполнено") completeTasksForCase(s, c.id); r(); close() }) { Text("Сохранить") } }, dismissButton = { TextButton(close) { Text("Отмена") } })
}

@Composable
fun TaskDialog(s: Store, r: () -> Unit, close: () -> Unit, old: Task? = null) {
    var title by remember { mutableStateOf(old?.title ?: "") }; var description by remember { mutableStateOf(old?.description ?: "") }; var caseId by remember { mutableStateOf(old?.caseId ?: "") }; var caseNo by remember { mutableStateOf(old?.caseNo ?: "") }; var caseMenu by remember { mutableStateOf(false) }; var dl by remember { mutableStateOf(old?.deadline ?: "") }; var pr by remember { mutableStateOf(old?.priority ?: "Средний") }; var priorityMenu by remember { mutableStateOf(false) }; var st by remember { mutableStateOf(if (old?.status == "Исполнено") "Исполнено" else "В работе") }; var statusMenu by remember { mutableStateOf(false) }; val ctx = androidx.compose.ui.platform.LocalContext.current
    fun pickDateTime() { val c = Calendar.getInstance(); DatePickerDialog(ctx, { _, y, m, d -> TimePickerDialog(ctx, { _, h, min -> dl = String.format(Locale.US, "%02d.%02d.%04d %02d:%02d", d, m + 1, y, h, min) }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show() }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show() }
    AlertDialog(onDismissRequest = close, title = { Text(if (old == null) "Новая задача" else "Редактировать задачу") }, text = { Column(Modifier.verticalScroll(rememberScrollState())) { Field(title, { title = it }, "Задача"); OutlinedTextField(description, { description = capitalizeInput(it) }, Modifier.fillMaxWidth().heightIn(min = 100.dp).padding(vertical = 4.dp), label = { Text("Описание задачи") }); Box { OutlinedButton({ caseMenu = true }, Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Text(if (caseNo.isBlank()) "Выберите дело" else caseNo, Modifier.weight(1f)); Icon(Icons.Default.ArrowDropDown, null) }; DropdownMenu(caseMenu, { caseMenu = false }) { DropdownMenuItem({ Text("Без привязки") }, { caseId = ""; caseNo = ""; caseMenu = false }); s.cases.forEach { c -> DropdownMenuItem({ Text("${c.no.ifBlank { "Без номера" }} • ${c.client}") }, { caseId = c.id; caseNo = c.no; caseMenu = false }) } } }; Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.weight(1f)) { Field(dl, { dl = it }, "Срок исполнения") }; IconButton(onClick = { pickDateTime() }) { Icon(Icons.Default.Event, "Выбрать дату и время") } }; Box { OutlinedButton({ priorityMenu = true }, Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Text(pr, Modifier.weight(1f)); Icon(Icons.Default.ArrowDropDown, null) }; DropdownMenu(priorityMenu, { priorityMenu = false }) { listOf("Высокий", "Средний", "Низкий").forEach { v -> DropdownMenuItem({ Text(v) }, { pr = v; priorityMenu = false }) } } }; OutlinedButton({ statusMenu = true }, Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Text(st, Modifier.weight(1f)); Icon(Icons.Default.ArrowDropDown, null) }; DropdownMenu(statusMenu, { statusMenu = false }) { listOf("В работе", "Исполнено").forEach { v -> DropdownMenuItem({ Text(v) }, { st = v; statusMenu = false }) } } } }, confirmButton = { Button(onClick = { val t = old ?: Task(); t.title = capitalizeInput(title); t.description = capitalizeInput(description); t.caseId = caseId; t.caseNo = caseNo; t.deadline = dl; t.priority = pr; t.status = st; val list = s.tasks.toMutableList(); val i = list.indexOfFirst { it.id == t.id }; if (i >= 0) list[i] = t else list.add(t); s.tasks = list; r(); close() }) { Text("Сохранить") } }, dismissButton = { TextButton(close) { Text("Отмена") } })
}

@Composable fun TaskViewDialog(t: Task, close: () -> Unit) { AlertDialog(onDismissRequest=close,title={Text("Задача")},text={Column(Modifier.verticalScroll(rememberScrollState())){Text(t.title.ifBlank{"Без названия"},fontWeight=FontWeight.Bold,fontSize=20.sp,color=MaterialTheme.colorScheme.primary);Text("Дело: ${t.caseNo.ifBlank{"без привязки"}}");Text("Срок исполнения: ${t.deadline.ifBlank{"—"}}");Text("Приоритет: ${t.priority}");Text("Статус: ${t.status}");Text("Описание",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=10.dp));Text(t.description.ifBlank{"—"});Text("Просмотр без редактирования",fontSize=11.sp,color=MaterialTheme.colorScheme.secondary,modifier=Modifier.padding(top=8.dp))}},confirmButton={TextButton(close){Text("Закрыть")}}) }

@Composable
fun DocDialog(s: Store, r: () -> Unit, close: () -> Unit, initialFolderId: String = "", old: Doc? = null) {
    var name by remember { mutableStateOf(old?.name ?: "") }; var caseId by remember { mutableStateOf(old?.caseId ?: "") }; var type by remember { mutableStateOf(old?.type ?: "Документ") }; var folderId by remember { mutableStateOf(old?.folderId ?: initialFolderId) }; var caseMenu by remember { mutableStateOf(false) }; var folderMenu by remember { mutableStateOf(false) }; val ctx = androidx.compose.ui.platform.LocalContext.current
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    fun save(uri: Uri?) {
        val sourceUri = uri ?: selectedUri
        val sourceName = sourceUri?.lastPathSegment?.substringAfterLast('/') ?: old?.name ?: "document"
        var path = old?.path ?: ""
        if (sourceUri != null) { val dir=File(ctx.filesDir,"documents"); dir.mkdirs(); val safe=name.ifBlank{sourceName}.replace("/","_"); val out=File(dir,"${System.currentTimeMillis()}_$safe"); ctx.contentResolver.openInputStream(sourceUri)?.use{input->out.outputStream().use{input.copyTo(it)}}; path=out.absolutePath }
        val c=s.cases.firstOrNull{it.id==caseId}; val updated=old?.copy(name=capitalizeInput(name.ifBlank{sourceName}),caseNo=c?.no?:"",caseId=caseId,type=capitalizeInput(type),path=path,folderId=folderId) ?: Doc(name=capitalizeInput(name.ifBlank{sourceName}),caseNo=c?.no?:"",caseId=caseId,type=capitalizeInput(type),path=path,folderId=folderId)
        s.docs=s.docs.filterNot{it.id==updated.id}.toMutableList().apply{add(updated)}; r(); close()
    }
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){ selectedUri=it }
    AlertDialog(onDismissRequest=close,title={Text(if(old==null) "Новый документ" else "Редактировать документ")},text={Column(Modifier.verticalScroll(rememberScrollState())){
        Field(name,{name=it},"Название"); Box{OutlinedButton({caseMenu=true},Modifier.fillMaxWidth().padding(vertical=4.dp)){Text(if(caseId.isBlank())"Связать с делом" else s.cases.firstOrNull{it.id==caseId}?.no?:"Дело",Modifier.weight(1f));Icon(Icons.Default.ArrowDropDown,null)};DropdownMenu(caseMenu,{caseMenu=false}){DropdownMenuItem({Text("Без привязки")},{caseId="";caseMenu=false});s.cases.forEach{c->DropdownMenuItem({Text("${c.no.ifBlank{"Без номера"}} • ${c.client}")},{caseId=c.id;caseMenu=false})}}};
        Box{OutlinedButton({folderMenu=true},Modifier.fillMaxWidth().padding(vertical=4.dp)){Text(s.docFolders.firstOrNull{it.id==folderId}?.name?:"Без папки",Modifier.weight(1f));Icon(Icons.Default.ArrowDropDown,null)};DropdownMenu(folderMenu,{folderMenu=false}){DropdownMenuItem({Text("Без папки")},{folderId="";folderMenu=false});s.docFolders.forEach{f->DropdownMenuItem({Text(f.name)},{folderId=f.id;folderMenu=false})}}}; Field(type,{type=it},"Тип");
        Button({picker.launch(arrayOf("application/pdf","application/msword","application/vnd.openxmlformats-officedocument.wordprocessingml.document","text/plain","image/*"))},Modifier.fillMaxWidth()){Icon(Icons.Default.UploadFile,null);Spacer(Modifier.width(8.dp));Text(if(old==null)"Выбрать файл" else "Заменить файл")}; if(selectedUri!=null)Text("Новый файл выбран",fontSize=12.sp,color=Gold)
    }},confirmButton={Button(onClick={save(selectedUri)}){Text("Сохранить")}},dismissButton={TextButton(close){Text("Отмена")}})
}

private fun xmlEscape(v: String): String = v.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;")
private fun xlsxCell(value: String): String = "<c t=\"inlineStr\"><is><t>${xmlEscape(value)}</t></is></c>"
private fun xlsxSheet(rows: List<List<String>>): String = buildString {
    append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>")
    rows.forEachIndexed { i, row -> append("<row r=\"${i+1}\">"); row.forEach { append(xlsxCell(it)) }; append("</row>") }
    append("</sheetData></worksheet>")
}
private fun xlsxExport(s: Store, out: OutputStream) {
    val sheets = linkedMapOf(
        "Клиенты" to listOf(listOf("ID","Имя","Телефон","Email","Сумма услуг","Внесено","Остаток","Рассрочка","Дата платежа","Создан") ) + s.clients.map { c ->
            val paid = if(c.payments.isNotEmpty()) c.payments.sumOf { it.amount.toDoubleOrNull() ?: 0.0 } else c.paid.toDoubleOrNull() ?: 0.0
            listOf(c.id,c.name,c.phone,c.email,c.fee,"$paid",((c.fee.toDoubleOrNull()?:0.0)-paid).toString(),c.installmentEnabled.toString(),c.installmentDate, c.created.toString())
        },
        "Платежи" to listOf(listOf("ID клиента","Клиент","ID платежа","Сумма","Дата","Комментарий")) + s.clients.flatMap { c -> c.payments.map { p -> listOf(c.id,c.name,p.id,p.amount,p.date,p.note) } },
        "Дела" to listOf(listOf("ID","Номер","Клиент","Суд","Категория","Стороны","Статус","Дата","Описание")) + s.cases.map { c -> listOf(c.id,c.no,c.client,c.court,c.category,c.parties,c.status,c.date,c.description) },
        "Задачи" to listOf(listOf("ID","Название","ID дела","Номер дела","Срок","Приоритет","Статус","Описание")) + s.tasks.map { t -> listOf(t.id,t.title,t.caseId,t.caseNo,t.deadline,t.priority,t.status,t.description) },
        "Документы" to listOf(listOf("ID","Название","Номер дела","ID дела","Тип","Путь","ID папки","Добавлен")) + s.docs.map { d -> listOf(d.id,d.name,d.caseNo,d.caseId,d.type,d.path,d.folderId,d.added.toString()) },
        "Папки" to listOf(listOf("ID","Название","Родитель")) + s.docFolders.map { f -> listOf(f.id,f.name,f.parentId) }
    )
    ZipOutputStream(out).use { z ->
        fun put(path:String, text:String) { z.putNextEntry(ZipEntry(path)); z.write(text.toByteArray(Charsets.UTF_8)); z.closeEntry() }
        put("[Content_Types].xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>${(1..sheets.size).joinToString(""){ "<Override PartName=\"/xl/worksheets/sheet$it.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" }}</Types>")
        put("_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>")
        val names=sheets.keys.toList()
        put("xl/workbook.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets>${names.mapIndexed { i,n -> "<sheet name=\"${xmlEscape(n)}\" sheetId=\"${i+1}\" r:id=\"rId${i+1}\"/>" }.joinToString("")}</sheets></workbook>")
        put("xl/_rels/workbook.xml.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">${names.indices.joinToString(""){ i -> "<Relationship Id=\"rId${i+1}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet${i+1}.xml\"/>" }}</Relationships>")
        sheets.values.forEachIndexed { i, rows -> put("xl/worksheets/sheet${i+1}.xml", xlsxSheet(rows)) }
    }
}
private fun cellText(e: org.w3c.dom.Element): String = e.getElementsByTagName("t").item(0)?.textContent ?: ""
private fun xlsxImport(s: Store, input: InputStream) {
    val files=mutableMapOf<String,ByteArray>(); ZipInputStream(input).use { z -> var e=z.nextEntry; while(e!=null){ if(!e.isDirectory) files[e.name]=z.readBytes(); e=z.nextEntry } }
    val wb=DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(files["xl/workbook.xml"]!!.inputStream())
    val rel=DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(files["xl/_rels/workbook.xml.rels"]!!.inputStream())
    val relMap=(0 until rel.getElementsByTagName("Relationship").length).associate { val n=rel.getElementsByTagName("Relationship").item(it) as org.w3c.dom.Element; n.getAttribute("Id") to n.getAttribute("Target") }
    val sheets=wb.getElementsByTagName("sheet")
    fun rows(target:String):List<List<String>> { val path="xl/"+target.removePrefix("/"); val d=DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(files[path]!!.inputStream()); val rs=d.getElementsByTagName("row"); return (0 until rs.length).map { r -> val cells=(rs.item(r) as org.w3c.dom.Element).getElementsByTagName("c"); (0 until cells.length).map { cellText(cells.item(it) as org.w3c.dom.Element) } } }
    val data=mutableMapOf<String,List<List<String>>>(); for(i in 0 until sheets.length){ val sh=sheets.item(i) as org.w3c.dom.Element; data[sh.getAttribute("name")]=rows(relMap[sh.getAttribute("r:id")]!!) }
    data["Клиенты"]?.drop(1)?.forEach { a -> if(a.size>=10){ val id=a[0]; val old=s.clients.firstOrNull{it.id==id}; val c=old?:Client(id=id); c.name=a[1]; c.phone=a[2]; c.email=a[3]; c.fee=a[4]; c.installmentEnabled=a[7].toBoolean(); c.installmentDate=a[8]; c.created=a[9].toLongOrNull()?:c.created; s.clients=s.clients.filterNot{it.id==id}.toMutableList().apply{add(c)} } }
    data["Платежи"]?.drop(1)?.forEach { a -> if(a.size>=6){ val c=s.clients.firstOrNull{it.id==a[0]}?:return@forEach; if(c.payments.none{it.id==a[2]}) c.payments.add(Payment(a[2],a[3],a[4],a[5])); s.clients=s.clients.filterNot{it.id==c.id}.toMutableList().apply{add(c)} } }
    data["Дела"]?.drop(1)?.forEach { a -> if(a.size>=9){ val c=s.cases.firstOrNull{it.id==a[0]}?:Case(id=a[0]); c.no=a[1];c.client=a[2];c.court=a[3];c.category=a[4];c.parties=a[5];c.status=a[6];c.date=a[7];c.description=a[8];s.cases=s.cases.filterNot{it.id==c.id}.toMutableList().apply{add(c)} } }
    data["Задачи"]?.drop(1)?.forEach { a -> if(a.size>=8){ val t=s.tasks.firstOrNull{it.id==a[0]}?:Task(id=a[0]);t.title=a[1];t.caseId=a[2];t.caseNo=a[3];t.deadline=a[4];t.priority=a[5];t.status=a[6];t.description=a[7];s.tasks=s.tasks.filterNot{it.id==t.id}.toMutableList().apply{add(t)} } }
    data["Документы"]?.drop(1)?.forEach { a -> if(a.size>=8){ val d=s.docs.firstOrNull{it.id==a[0]}?:Doc(id=a[0]);d.name=a[1];d.caseNo=a[2];d.caseId=a[3];d.type=a[4];d.path=a[5];d.folderId=a[6];d.added=a[7].toLongOrNull()?:d.added;s.docs=s.docs.filterNot{it.id==d.id}.toMutableList().apply{add(d)} } }
    data["Папки"]?.drop(1)?.forEach { a -> if(a.size>=3){ val f=s.docFolders.firstOrNull{it.id==a[0]}?:DocFolder(id=a[0]);f.name=a[1];f.parentId=a[2];s.docFolders=s.docFolders.filterNot{it.id==f.id}.toMutableList().apply{add(f)} } }
}

@Composable fun SettingsPage(s: Store, onBack: () -> Unit, onNight: (Boolean) -> Unit) {
    val p = androidx.compose.ui.platform.LocalContext.current.getSharedPreferences("crm_settings", 0)
    var night by remember { mutableStateOf(p.getBoolean("night", false)) }
    var high by remember { mutableIntStateOf(p.getInt("notify_high", 3)) }
    var medium by remember { mutableIntStateOf(p.getInt("notify_medium", 1)) }
    var low by remember { mutableIntStateOf(p.getInt("notify_low", 1)) }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) { uri -> uri?.let { ctx.contentResolver.openOutputStream(it)?.use { out -> xlsxExport(s, out) } } }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { runCatching { ctx.contentResolver.openInputStream(it)?.use { input -> xlsxImport(s, input) }; onBack() }.onSuccess { } } }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Surface(color = Forest, modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Назад", tint = White) }
                Column(Modifier.weight(1f)) { Text("Настройки", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold); Text("Параметры приложения", color = Gold, fontSize = 12.sp) }
                Icon(Icons.Default.Settings, null, tint = Gold, modifier = Modifier.size(30.dp))
            }
        }
        Text("Внешний вид", Modifier.padding(18.dp, 20.dp, 18.dp, 8.dp), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
        Card(Modifier.fillMaxWidth().padding(horizontal = 14.dp), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Surface(Modifier.size(44.dp), RoundedCornerShape(14.dp), color = Gold.copy(alpha = .16f)) { Icon(if (night) Icons.Default.DarkMode else Icons.Default.LightMode, null, tint = Gold, modifier = Modifier.padding(10.dp)) }
                Spacer(Modifier.width(14.dp)); Column(Modifier.weight(1f)) { Text("Ночной режим", fontWeight = FontWeight.Bold); Text(if (night) "Тёмное оформление включено" else "Светлое оформление включено", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary) }; Switch(night, { night = it; p.edit().putBoolean("night", it).apply(); onNight(it) })
            }
        }
        Text("Уведомления", Modifier.padding(18.dp, 22.dp, 18.dp, 8.dp), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
        Card(Modifier.fillMaxWidth().padding(horizontal = 14.dp), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(16.dp)) {
                Text("Напоминания о задачах", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text("За сколько дней напоминать о сроке", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(top = 3.dp, bottom = 10.dp))
                SettingRow("Высокий приоритет", high) { high = it; p.edit().putInt("notify_high", it).apply() }
                HorizontalDivider(color = Gold.copy(alpha = .16f))
                SettingRow("Средний приоритет", medium) { medium = it; p.edit().putInt("notify_medium", it).apply() }
                HorizontalDivider(color = Gold.copy(alpha = .16f))
                SettingRow("Низкий приоритет", low) { low = it; p.edit().putInt("notify_low", it).apply() }
            }
        }
        Text("Резервная копия", Modifier.padding(18.dp, 22.dp, 18.dp, 8.dp), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
        Card(Modifier.fillMaxWidth().padding(horizontal = 14.dp), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(16.dp)) {
                Text("Excel", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text("Сохраните данные CRM в Excel или восстановите их из ранее созданной копии.", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(top = 3.dp, bottom = 12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = { exportLauncher.launch("Advokat_CRM_backup.xlsx") }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.FileDownload, null); Spacer(Modifier.width(6.dp)); Text("Экспорт") }
                    OutlinedButton(onClick = { importLauncher.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/zip", "*/*")) }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.FileUpload, null); Spacer(Modifier.width(6.dp)); Text("Загрузить") }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable fun SettingRow(label: String, value: Int, set: (Int) -> Unit) { Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) { Text(label, Modifier.weight(1f)); Text(if (value == 0) "Выкл." else "$value дн."); IconButton(onClick = { set(maxOf(0, value - 1)) }) { Icon(Icons.Default.Remove, null) }; IconButton(onClick = { set(minOf(7, value + 1)) }) { Icon(Icons.Default.Add, null) } } }
