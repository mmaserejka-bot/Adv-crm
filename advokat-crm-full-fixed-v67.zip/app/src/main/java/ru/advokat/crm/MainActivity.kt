package ru.advokat.crm

import android.Manifest
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.*
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.IconButton
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import androidx.work.*
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import javax.xml.parsers.DocumentBuilderFactory
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private val Forest=Color(0xFF0E3327); private val Green=Color(0xFF2F6B4F); private val Gold=Color(0xFFC7A45B); private val Cream=Color(0xFFF5F1E8); private val Ink=Color(0xFF1E2923); private val White=Color(0xFFFFFEFB)

data class Hearing(val id:String=UUID.randomUUID().toString(),var date:String="",var time:String="",var status:String="В работе")
data class Case(val id:String=UUID.randomUUID().toString(),var no:String="",var client:String="",var clientId:String="",var court:String="",var category:String="",var parties:String="",var status:String="В работе",var processStatus:String="",var date:String="",var notes:String="",var description:String="",var hearings:MutableList<Hearing>? = mutableListOf(),var updated:Long=System.currentTimeMillis(),var history:MutableList<String> = mutableListOf())
data class ServiceCharge(val id:String=UUID.randomUUID().toString(),var name:String="Услуга",var amount:String="0")
data class Payment(val id:String=UUID.randomUUID().toString(),var amount:String="0",var date:String="",var note:String="",var place:String="",var serviceId:String="")
data class Client(val id:String=UUID.randomUUID().toString(),var name:String="",var phone:String="",var email:String="",var details:String="",var notes:String="",var fee:String="0",var paid:String="0",var installmentEnabled:Boolean=false,var installmentAmount:String="0",var installmentDate:String="",var payments:MutableList<Payment> = mutableListOf(),var services:MutableList<ServiceCharge> = mutableListOf(),var updated:Long=System.currentTimeMillis(),var created:Long=System.currentTimeMillis(),var history:MutableList<String> = mutableListOf())
data class Task(val id:String=UUID.randomUUID().toString(),var title:String="",var caseNo:String="",var caseId:String="",var deadline:String="",var priority:String="Средний",var status:String="В работе",var description:String="")
data class Meeting(val id:String=UUID.randomUUID().toString(),var name:String="",var date:String="",var time:String="",var place:String="",var notes:String="",var clientId:String="",var clientName:String="",var caseId:String="",var caseNo:String="",var status:String="В работе",var created:Long=System.currentTimeMillis())
data class Contract(val id:String=UUID.randomUUID().toString(),var name:String="",var clientId:String="",var clientName:String="",var caseId:String="",var caseNo:String="",var type:String="Договор",var path:String="",var added:Long=System.currentTimeMillis())
data class ActivityLog(val id:String=UUID.randomUUID().toString(),var title:String="",var detail:String="",var type:String="Изменение",var created:Long=System.currentTimeMillis())
data class DocFolder(val id:String=UUID.randomUUID().toString(),var name:String="Новая папка",var parentId:String="")
data class Doc(val id:String=UUID.randomUUID().toString(),var name:String="",var caseNo:String="",var caseId:String="",var type:String="Документ",var path:String="",var folderId:String="",var added:Long=System.currentTimeMillis())
data class TrashItem(val id:String=UUID.randomUUID().toString(),var type:String="",var title:String="",var payload:String="",var deleted:Long=System.currentTimeMillis())
data class AssistantMessage(val id:String=UUID.randomUUID().toString(),var role:String="user",var content:String="",var created:Long=System.currentTimeMillis())
data class AssistantMemory(val id:String=UUID.randomUUID().toString(),var text:String="",var created:Long=System.currentTimeMillis())
class Store(private val c: Context) {
    fun context(): Context = c
    private val p = c.getSharedPreferences("crm", 0)
    private val g = Gson()

    private inline fun <reified T> get(k: String): MutableList<T> =
        g.fromJson(p.getString(k, "[]"), object : TypeToken<MutableList<T>>() {}.type)
            ?: mutableListOf()

    private fun put(k: String, value: Any) {
        p.edit().putString(k, g.toJson(value)).apply()
    }

    var cases: MutableList<Case>
        get() = get("cases")
        set(value) = put("cases", value)

    var clients: MutableList<Client>
        get() = get("clients")
        set(value) = put("clients", value)

    var tasks: MutableList<Task>
        get() = get("tasks")
        set(value) = put("tasks", value)

    var meetings: MutableList<Meeting>
        get() = get("meetings")
        set(value) = put("meetings", value)

    var contracts: MutableList<Contract>
        get() = get("contracts")
        set(value) = put("contracts", value)

    var activityLogs: MutableList<ActivityLog>
        get() = get("activityLogs")
        set(value) = put("activityLogs", value)

    var docs: MutableList<Doc>
        get() = get("docs")
        set(value) = put("docs", value)

    var docFolders: MutableList<DocFolder>
        get() = get("docFolders")
        set(value) = put("docFolders", value)

    var trash: MutableList<TrashItem>
        get() = get("trash")
        set(value) = put("trash", value)
    var assistantMessages: MutableList<AssistantMessage>
        get() = get("assistantMessages")
        set(value) = put("assistantMessages", value.takeLast(80).toMutableList())

    var assistantMemories: MutableList<AssistantMemory>
        get() = get("assistantMemories")
        set(value) = put("assistantMemories", value.takeLast(100).toMutableList())

    var openAiApiKey: String
        get() = p.getString("openai_api_key", "") ?: ""
        set(value) { p.edit().putString("openai_api_key", value).apply() }

    var openAiModel: String
        get() = p.getString("openai_model", "gpt-5.6-luna") ?: "gpt-5.6-luna"
        set(value) { p.edit().putString("openai_model", value).apply() }
    var assistantPendingDelete: String
        get() = p.getString("assistant_pending_delete", "") ?: ""
        set(value) { p.edit().putString("assistant_pending_delete", value).apply() }
    var assistantOpenClientId: String
        get() = p.getString("assistant_open_client_id", "") ?: ""
        set(value) { p.edit().putString("assistant_open_client_id", value).apply() }
}

fun addActivity(s: Store, title: String, detail: String, type: String = "Изменение") {
    s.activityLogs = (s.activityLogs + ActivityLog(title = title, detail = detail, type = type)).takeLast(200).toMutableList()
}

class MainActivity:ComponentActivity(){override fun onCreate(s:Bundle?){super.onCreate(s);val store=Store(this);purge(store);createChannel();if(Build.VERSION.SDK_INT>=33)requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),7);setContent{CRMApp(store)};requestMicrophoneOnFirstLaunch()}private fun requestMicrophoneOnFirstLaunch(){if(Build.VERSION.SDK_INT<23)return;val prefs=getSharedPreferences("crm_settings",MODE_PRIVATE);if(prefs.getBoolean("microphone_permission_requested",false))return;if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED){prefs.edit().putBoolean("microphone_permission_requested",true).apply();return};prefs.edit().putBoolean("microphone_permission_requested",true).apply();window.decorView.postDelayed({requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),19)},700)}private fun createChannel(){val n=getSystemService(NotificationManager::class.java);if(Build.VERSION.SDK_INT>=26)n.createNotificationChannel(NotificationChannel("events","Судебные события",NotificationManager.IMPORTANCE_HIGH))}private fun purge(s:Store){s.trash=s.trash.filter{System.currentTimeMillis()-it.deleted<30L*24*60*60*1000}.toMutableList()}}
class ReminderWorker(c:Context,p:WorkerParameters):Worker(c,p){override fun doWork():Result{val s=Store(applicationContext);val fmt=SimpleDateFormat("dd.MM.yyyy",Locale.US);val now=Calendar.getInstance();val n=applicationContext.getSystemService(NotificationManager::class.java);s.cases.forEach{if(it.date.isBlank())return@forEach;runCatching{val d=Calendar.getInstance().apply{time=fmt.parse(it.date.substringBefore(" "))!!;set(Calendar.HOUR_OF_DAY,9);set(Calendar.MINUTE,0)};val days=((d.timeInMillis-now.timeInMillis)/86400000.0).toInt();if(days==3||days==1){val x=Notification.Builder(applicationContext,"events").setSmallIcon(R.drawable.ic_legal_mark).setContentTitle("Напоминание: заседание").setContentText("${it.date} • дело ${it.no}").setAutoCancel(true).build();n.notify((it.id.hashCode()+days),x)}}};return Result.success()}}

@Composable
fun CRMApp(store: Store) {
    val settings=androidx.compose.ui.platform.LocalContext.current.getSharedPreferences("crm_settings",0)
    var night by remember{mutableStateOf(settings.getBoolean("night",false))}
    val scheme=if(night) darkColorScheme(primary=Color(0xFF9AD8B6),onPrimary=Color(0xFF062016),secondary=Color(0xFFE0C27A),onSecondary=Color(0xFF241B08),background=Color(0xFF0B120E),surface=Color(0xFF152019),surfaceVariant=Color(0xFF203027),onSurface=Color(0xFFEAF3EC),onBackground=Color(0xFFEAF3EC),outline=Color(0xFF6C7F73),error=Color(0xFFFFB4AB),onError=Color(0xFF690005)) else lightColorScheme(
        primary=Forest, onPrimary=White, primaryContainer=Color(0xFFDCE8DF), onPrimaryContainer=Forest,
        secondary=Gold, onSecondary=Color(0xFF2B210E), secondaryContainer=Color(0xFFF0E3BF), onSecondaryContainer=Ink,
        background=Cream, surface=White, surfaceVariant=Color(0xFFEAE4D7), onSurface=Ink, onBackground=Ink,
        onSurfaceVariant=Color(0xFF4B574F), outline=Color(0xFFB9B09F), error=Color(0xFF8A4A3A), onError=White,
        errorContainer=Color(0xFFF1DDD7), onErrorContainer=Color(0xFF4D1F16)
    )
    MaterialTheme(colorScheme = scheme) {
        val nav = rememberNavController()
        var tick by remember { mutableIntStateOf(0) }
        val refresh:()->Unit={tick++}
        Scaffold(bottomBar = { BottomBar(nav) }) { pad ->
            Box(Modifier.fillMaxSize().padding(pad)) {
                NavHost(navController = nav, startDestination = "home") {
                        composable("home") { Home(store, { nav.navigate("menu") }, refresh, nav) }
                        composable("menu") { MenuPage(nav) }
                        composable("assistant") { AssistantScreen(store, refresh, { nav.navigate("menu") }) }
                        composable("calendar") { CalendarScreen(store, refresh, { nav.navigate("menu") }) }
                        composable("clients") { Clients(store, refresh, { nav.navigate("menu") }) }
                        composable("cases") { Cases(store, refresh, { nav.navigate("menu") }) }
                        composable("archive") { Archive(store, refresh, { nav.navigate("menu") }) }
                        composable("tasks") { Tasks(store, refresh, { nav.navigate("menu") }) }
                        composable("meetings") { Meetings(store, refresh, { nav.navigate("menu") }) }
                        composable("docs") { Documents(store, refresh, { nav.navigate("menu") }) }
                        composable("contracts") { Contracts(store, refresh, { nav.navigate("menu") }) }
                        composable("search") { Search(store, { nav.navigate("menu") }) }
                        composable("trash") { Trash(store, tick, { nav.navigate("menu") }) }
                        composable("settings") { SettingsPage(store, { nav.popBackStack(); }, { enabled: Boolean -> night = enabled }) }
                    }
            }
        }
    }
}
@Composable
fun Header(s: Store, onMenu:()->Unit,title:String="Advokat CRM"){
    Box(Modifier.fillMaxWidth().height(142.dp)){
        Box(Modifier.fillMaxSize().background(Color(0xFF063B2A)))
        Box(Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color(0xFF0A4A35), Color(0xFF052D21)))))
        Row(Modifier.fillMaxSize().padding(horizontal=14.dp,vertical=12.dp),verticalAlignment=Alignment.CenterVertically){
            IconButton(onClick=onMenu,modifier=Modifier.background(Color(0x55000000),CircleShape)){Icon(Icons.Default.Menu,"Меню",tint=Color(0xFFFFF7E6))}
            Spacer(Modifier.width(8.dp))
            Surface(Modifier.size(58.dp),RoundedCornerShape(16.dp),color=Color.Transparent,border=BorderStroke(1.dp,Gold.copy(alpha=.55f))){Image(painterResource(R.drawable.ic_bull_header),"Эмблема Advokat CRM",Modifier.fillMaxSize().padding(3.dp),contentScale=androidx.compose.ui.layout.ContentScale.Fit)}
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)){
                Text(title,fontSize=23.sp,fontWeight=FontWeight.Bold,color=Color(0xFFFFF7E6),maxLines=1,overflow=TextOverflow.Ellipsis)
                Text("Юридическая практика",fontSize=11.sp,color=Gold,maxLines=1)
            }
            NotificationBell(s)
        }
    }
}
@Composable fun NotificationBell(s: Store) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val prefs = ctx.getSharedPreferences("crm_settings", 0)
    var opened by remember { mutableStateOf(false) }
    val logs = s.activityLogs.sortedByDescending { it.created }
    val seen = prefs.getLong("activity_seen", 0L)
    val unread = logs.any { it.created > seen }
    Box {
        IconButton(onClick = { opened = true; prefs.edit().putLong("activity_seen", System.currentTimeMillis()).apply() }) {
            Icon(Icons.Default.Notifications, "Уведомления", tint = Color(0xFFFFF7E6), modifier = Modifier.size(27.dp))
        }
        if (unread) {
            Surface(Modifier.size(10.dp).align(Alignment.TopEnd).offset(x = (-7).dp, y = 7.dp), CircleShape, color = Color(0xFFC94A3A), shadowElevation = 2.dp) {}
        }
        if (opened) ActivityLogDialog(logs) { opened = false }
    }
}

@Composable fun ActivityLogDialog(logs: List<ActivityLog>, close: () -> Unit) {
    AlertDialog(onDismissRequest = close, shape = RoundedCornerShape(28.dp), containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 10.dp,
        title = { Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Notifications, null, tint = Gold); Spacer(Modifier.width(8.dp)); Text("Журнал и уведомления", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold) } },
        text = {
            if (logs.isEmpty()) Text("Пока нет записей. Здесь появятся создания, изменения, удаления и другие действия.", color = MaterialTheme.colorScheme.secondary)
            else Column(Modifier.heightIn(max = 440.dp).verticalScroll(rememberScrollState())) {
                logs.forEach { log ->
                    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), shape = RoundedCornerShape(15.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Row(Modifier.padding(11.dp), verticalAlignment = Alignment.Top) {
                            Icon(if (log.type == "Создание") Icons.Default.AddCircle else if (log.type == "Удаление") Icons.Default.DeleteSweep else Icons.Default.History, null, tint = if (log.type == "Удаление") Color(0xFF8A4A3A) else Gold)
                            Spacer(Modifier.width(9.dp)); Column(Modifier.weight(1f)) {
                                Text(log.title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                if (log.detail.isNotBlank()) Text(log.detail, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.US).format(Date(log.created)), fontSize = 10.sp, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(top = 3.dp))
                            }
                        }
                    }
                }
            }
        }, confirmButton = { TextButton(close) { Text("Закрыть") } })
}

@Composable fun Home(s:Store,onMenu:()->Unit,refresh:()->Unit,nav:NavHostController){
    val showClient=remember{mutableStateOf(false)}; val showCase=remember{mutableStateOf(false)}; val showMeeting=remember{mutableStateOf(false)}; val cases=s.cases.filter{!it.status.equals("Исполнено",true)}; val tasks=s.tasks.filter{!it.status.equals("Исполнено",true)&&!it.status.equals("Готово",true)&&s.cases.firstOrNull{c->c.id==it.caseId}?.status!="Исполнено"}; val now=System.currentTimeMillis()
    val upcoming=cases.filter{it.date.isNotBlank()&&!it.status.equals("Исполнено",true)}.mapNotNull{c->parseDateTime(c.date)?.let{d->if(d>=now)c to d else null}}.sortedBy{it.second}.take(3).map{it.first}
    val overdue=tasks.filter{!it.status.equals("Исполнено",true)&&!it.status.equals("Готово",true)&&parseDateTime(it.deadline)?.let{d->d<now}==true}.sortedBy{parseDateTime(it.deadline)?:Long.MAX_VALUE}.take(2)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())){
        Header(s, onMenu)
        Card(Modifier.fillMaxWidth().padding(horizontal=18.dp, vertical=8.dp).clickable { nav.navigate("assistant") }, shape=RoundedCornerShape(22.dp), colors=CardDefaults.cardColors(containerColor=Forest)) {
            Row(Modifier.padding(15.dp), verticalAlignment=Alignment.CenterVertically) {
                Surface(Modifier.size(46.dp), CircleShape, color=Gold.copy(alpha=.18f)) { Icon(Icons.Default.SmartToy, "ИИ-ассистент", tint=Gold, modifier=Modifier.padding(10.dp)) }
                Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text("ИИ-ассистент", color=White, fontWeight=FontWeight.Bold, fontSize=16.sp); Text("Создать клиента, дело, встречу или найти судебную практику", color=White.copy(alpha=.82f), fontSize=11.sp) }; Icon(Icons.Default.ChevronRight, null, tint=Gold)
            }
        }
        Text("Добро пожаловать",Modifier.padding(horizontal=18.dp),fontSize=13.sp,color=Gold); Text("Ваша практика под контролем",Modifier.padding(horizontal=18.dp),fontSize=27.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary); Text(SimpleDateFormat("EEEE, d MMMM yyyy",Locale("ru")).format(Date()).replaceFirstChar{it.uppercase()},Modifier.padding(18.dp,3.dp),color=MaterialTheme.colorScheme.secondary)
        Row(Modifier.padding(horizontal=18.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)){Stat(Icons.Default.Gavel,"Дела",cases.size.toString(),Modifier.weight(1f)){nav.navigate("cases")};Stat(Icons.Default.Event,"Заседания",cases.count{it.date.isNotBlank()}.toString(),Modifier.weight(1f)){nav.navigate("calendar")};Stat(Icons.Default.TaskAlt,"Задачи",tasks.count{!it.status.equals("Исполнено",true)&&!it.status.equals("Готово",true)}.toString(),Modifier.weight(1f)){nav.navigate("tasks")}}
        Section("Ближайшие заседания"); if(upcoming.isEmpty()) Text("Ближайших заседаний нет",Modifier.padding(horizontal=18.dp),color=MaterialTheme.colorScheme.secondary) else upcoming.forEach{EventCard(it)}
        val upcomingMeetings=s.meetings.filter{!it.status.equals("Исполнено",true)}.mapNotNull{m->parseDateTime("${m.date} ${m.time}")?.let{d->if(d>=now)m to d else null}}.sortedBy{it.second}.take(3).map{it.first}
        Section("Ближайшие встречи"); if(upcomingMeetings.isEmpty()) Text("Ближайших встреч нет",Modifier.padding(horizontal=18.dp),color=MaterialTheme.colorScheme.secondary) else upcomingMeetings.forEach{MeetingCard(it)}
        Section("Просроченные задачи"); if(overdue.isEmpty()) Text("Просроченных задач нет",Modifier.padding(horizontal=18.dp),color=MaterialTheme.colorScheme.secondary) else overdue.forEach{TaskCard(it)}
        Section("Быстрые действия"); Row(Modifier.padding(18.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)){QuickButton(Modifier.weight(1f),Icons.Default.PersonAdd,"Клиент"){showClient.value=true};QuickButton(Modifier.weight(1f),Icons.Default.AddTask,"Дело"){showCase.value=true};QuickButton(Modifier.weight(1f),Icons.Default.Groups,"Встреча"){showMeeting.value=true}}; Spacer(Modifier.height(20.dp)); if(showClient.value){ClientDialog(s,refresh,close={showClient.value=false})}; if(showCase.value){CaseDialog(s,refresh,close={showCase.value=false})}; if(showMeeting.value){MeetingDialog(s,refresh,close={showMeeting.value=false})}
    }
}
@Composable fun Stat(icon:androidx.compose.ui.graphics.vector.ImageVector,label:String,value:String,modifier:Modifier=Modifier,click:()->Unit={})=Card(modifier.clickable(onClick=click),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Column(Modifier.padding(13.dp)){Icon(icon,null,tint=Gold,modifier=Modifier.size(22.dp));Text(value,fontSize=24.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary);Text(label,fontSize=12.sp,color=MaterialTheme.colorScheme.secondary)}}
@Composable fun Section(t:String){Text(t,Modifier.padding(18.dp,12.dp,18.dp,6.dp),fontSize=18.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)}
@Composable fun EventCard(c:Case)=Card(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=5.dp),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Gavel,null,tint=Gold,modifier=Modifier.size(28.dp));Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(c.date,fontWeight=FontWeight.Bold,color=Gold);Text(c.client.ifBlank{"Без клиента"},fontWeight=FontWeight.Bold);Text("${c.court} • ${c.no}",fontSize=12.sp,color=MaterialTheme.colorScheme.secondary)}}}
@Composable fun MeetingCard(m: Meeting)=Card(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=5.dp),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Groups,null,tint=Gold,modifier=Modifier.size(28.dp));Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text("${m.date} • ${m.time}",fontWeight=FontWeight.Bold,color=Gold);Text(m.name.ifBlank{"Без ФИО"},fontWeight=FontWeight.Bold);Text(m.place.ifBlank{"Место не указано"},fontSize=12.sp,color=MaterialTheme.colorScheme.secondary)}}}
@Composable fun TaskCard(t:Task)=Card(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=4.dp),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Row(Modifier.padding(13.dp)){Icon(Icons.Default.TaskAlt,null,tint=Gold);Spacer(Modifier.width(10.dp));Column{Text(t.title,fontWeight=FontWeight.Bold);Text("${t.caseNo} • ${t.deadline} • ${t.priority}",fontSize=12.sp,color=MaterialTheme.colorScheme.secondary)}}}
@Composable fun QuickButton(modifier:Modifier=Modifier,i:androidx.compose.ui.graphics.vector.ImageVector,t:String,click:()->Unit)=Button(onClick=click,modifier=modifier.height(48.dp),contentPadding=PaddingValues(horizontal=5.dp),shape=RoundedCornerShape(14.dp),colors=ButtonDefaults.buttonColors(containerColor=Forest)){Icon(i,null,modifier=Modifier.size(18.dp));Spacer(Modifier.width(4.dp));Text(t,fontSize=11.sp,maxLines=1,overflow=TextOverflow.Ellipsis)}

val mainItems=listOf("home" to "Главная","calendar" to "Календарь","clients" to "Клиенты","cases" to "Дела")
@Composable fun BottomBar(nav:NavHostController){
    val current=nav.currentBackStackEntryAsState().value?.destination?.route
    var moreOpen by remember{mutableStateOf(false)}
    NavigationBar(containerColor=MaterialTheme.colorScheme.surface){
        mainItems.forEach{(r,l)->NavigationBarItem(selected=current==r,onClick={moreOpen=false;nav.navigate(r){launchSingleTop=true;restoreState=true}},icon={Icon(navIcon(r),null)},label={Text(l,fontSize=9.sp)})}
        NavigationBarItem(
            selected=moreOpen,
            onClick={moreOpen=!moreOpen},
            icon={
                Box {
                    Icon(Icons.Default.MoreHoriz,null)
                    DropdownMenu(expanded=moreOpen,onDismissRequest={moreOpen=false},modifier=Modifier.width(230.dp),containerColor=MaterialTheme.colorScheme.surface,tonalElevation=8.dp){
                        listOf("tasks" to ("Задачи" to Icons.Default.TaskAlt),"meetings" to ("Встречи" to Icons.Default.Groups),"docs" to ("Документы" to Icons.Default.Description),"contracts" to ("Договоры" to Icons.Default.Assignment),"search" to ("Поиск" to Icons.Default.Search),"archive" to ("Архив" to Icons.Default.Inventory2),"trash" to ("Корзина" to Icons.Default.DeleteSweep)).forEach{(route,item)->
                            DropdownMenuItem(text={Text(item.first)},leadingIcon={Icon(item.second,null,tint=MaterialTheme.colorScheme.primary)},onClick={moreOpen=false;nav.navigate(route){launchSingleTop=true}})
                        }
                        HorizontalDivider()
                        DropdownMenuItem(text={Text("Настройки")},leadingIcon={Icon(Icons.Default.Settings,null,tint=MaterialTheme.colorScheme.primary)},onClick={moreOpen=false;nav.navigate("settings")})
                    }
                }
            },
            label={Text("Ещё",fontSize=9.sp)}
        )
    }
}
@Composable fun navIcon(r:String)=when(r){"home"->Icons.Default.Dashboard;"calendar"->Icons.Default.CalendarMonth;"clients"->Icons.Default.PeopleAlt;else->Icons.Default.Gavel}
@Composable
fun MenuPage(nav: NavHostController) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, "Назад", tint = MaterialTheme.colorScheme.primary) }
            Surface(Modifier.size(52.dp), CircleShape, color = Color.Transparent) { Image(painterResource(R.drawable.ic_bull_header), contentDescription = "Эмблема Advokat CRM", modifier = Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Fit) }
            Spacer(Modifier.width(12.dp))
            Column { Text("Меню", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary); Text("ADVОKAT CRM", fontSize = 11.sp, color = Gold) }
        }
        HorizontalDivider(color = Gold.copy(alpha=.3f))
        listOf(
            "home" to ("Главная" to Icons.Default.Dashboard), "calendar" to ("Календарь" to Icons.Default.CalendarMonth),
            "clients" to ("Клиенты" to Icons.Default.PeopleAlt), "cases" to ("Дела" to Icons.Default.Gavel),
            "assistant" to ("ИИ-ассистент" to Icons.Default.SmartToy), "tasks" to ("Задачи" to Icons.Default.TaskAlt), "meetings" to ("Встречи" to Icons.Default.Groups), "docs" to ("Документы" to Icons.Default.Description), "contracts" to ("Договоры" to Icons.Default.Assignment),
            "search" to ("Поиск" to Icons.Default.Search), "archive" to ("Архив" to Icons.Default.Inventory2), "trash" to ("Корзина" to Icons.Default.DeleteSweep), "settings" to ("Настройки" to Icons.Default.Settings)
        ).forEach { (route, item) ->
            NavigationDrawerItem(
                label = { Text(item.first, fontSize = 16.sp) }, selected = false,
                onClick = { nav.navigate(route) { launchSingleTop = true } },
                icon = { Icon(item.second, null, tint = if (route == "trash") Color(0xFF8A4A3A) else MaterialTheme.colorScheme.primary) },
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp)
            )
        }
    }
}

@Composable
fun AssistantScreen(s: Store, refresh: () -> Unit, onMenu: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var listening by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    val messages = s.assistantMessages
    val openClientId = s.assistantOpenClientId
    val recognizer = remember { if (SpeechRecognizer.isRecognitionAvailable(ctx)) SpeechRecognizer.createSpeechRecognizer(ctx) else null }
    DisposableEffect(recognizer) { onDispose { recognizer?.destroy() } }

    fun startVoice() {
        if (recognizer == null) { error = "Голосовой ввод недоступен на этом устройстве"; return }
        if (Build.VERSION.SDK_INT >= 23 && androidx.core.content.ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            (ctx as? Activity)?.requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 19)
            error = "Разрешите доступ к микрофону и нажмите кнопку микрофона ещё раз"
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Говорите")
        }
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p0: Bundle?) { listening = true }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(p0: Float) {}
            override fun onBufferReceived(p0: ByteArray?) {}
            override fun onEndOfSpeech() { listening = false }
            override fun onError(p0: Int) { listening = false; error = "Не удалось распознать речь" }
            override fun onResults(b: Bundle?) { listening = false; input = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty() }
            override fun onPartialResults(b: Bundle?) { input = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty() }
            override fun onEvent(p0: Int, p1: Bundle?) {}
        })
        recognizer.startListening(intent)
    }

    fun send() {
        val text = input.trim(); if (text.isBlank() || busy) return
        input = ""; error = ""
        s.assistantMessages = (s.assistantMessages + AssistantMessage(role="user", content=text)).toMutableList()
        if ((text.equals("да", true) || text.equals("подтверждаю", true) || text.equals("подтвердить", true)) && s.assistantPendingDelete.isNotBlank()) {
            runCatching {
                val pending=JSONObject(s.assistantPendingDelete); val type=pending.optString("type"); val id=pending.optString("id")
                val args=JSONObject(pending.toString()).apply { remove("type") }; val result=executeConfirmedDelete(s,type,args,refresh); s.assistantPendingDelete=""; s.assistantMessages=(s.assistantMessages+AssistantMessage(role="assistant",content=result)).toMutableList(); refresh()
            }.onFailure { error=it.message?:"Не удалось удалить" }
            return
        }
        if (text.startsWith("запомни ", true)) {
            val mem = text.substringAfter("запомни ", "").trim()
            if (mem.isNotBlank()) { s.assistantMemories = (s.assistantMemories + AssistantMemory(text=mem)).toMutableList(); s.assistantMessages = (s.assistantMessages + AssistantMessage(role="assistant", content="Запомнил: $mem")).toMutableList(); refresh() }
            return
        }
        busy = true
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) { runAssistantRequest(s, text) }
                s.assistantMessages = (s.assistantMessages + AssistantMessage(role="assistant", content=result)).toMutableList()
                refresh()
            } catch (e: Exception) { error = e.message ?: "Ошибка связи с ИИ" }
            finally { busy = false }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Header(s, onMenu)
        Row(Modifier.fillMaxWidth().padding(horizontal=18.dp, vertical=10.dp), verticalAlignment=Alignment.CenterVertically) {
            Icon(Icons.Default.SmartToy, null, tint=Gold, modifier=Modifier.size(30.dp)); Spacer(Modifier.width(10.dp)); Text("ИИ-ассистент", Modifier.weight(1f), fontSize=26.sp, fontWeight=FontWeight.Bold, color=MaterialTheme.colorScheme.primary)
            IconButton(onClick={showSettings=true}) { Icon(Icons.Default.Settings, "Настройки ассистента", tint=MaterialTheme.colorScheme.primary) }
        }
        Text("Поможет работать с CRM и искать актуальные нормы и судебную практику в интернете.", Modifier.padding(horizontal=18.dp), fontSize=12.sp, color=MaterialTheme.colorScheme.secondary)
        if (messages.isEmpty()) {
            Card(Modifier.fillMaxWidth().padding(18.dp), shape=RoundedCornerShape(20.dp), colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(16.dp)) { Text("Что можно сказать", fontWeight=FontWeight.Bold, color=MaterialTheme.colorScheme.primary); listOf("Создай клиента Иванов Иван Иванович, телефон +7...", "Поставь встречу с Ивановым завтра в 14:00", "Найди судебную практику по лишению родительских прав", "Запомни: мои документы всегда оформляй кратко").forEach { q -> Text("• $q", Modifier.padding(top=7.dp), fontSize=12.sp) } }
            }
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding=PaddingValues(horizontal=14.dp, vertical=8.dp), reverseLayout=false) {
            items(messages, key={it.id}) { m ->
                Row(Modifier.fillMaxWidth().padding(vertical=5.dp), horizontalArrangement=if(m.role=="user") Arrangement.End else Arrangement.Start) {
                    Card(Modifier.widthIn(max=340.dp), shape=RoundedCornerShape(18.dp), colors=CardDefaults.cardColors(containerColor=if(m.role=="user") Forest else MaterialTheme.colorScheme.surfaceVariant)) { Text(m.content, Modifier.padding(12.dp), color=if(m.role=="user") White else MaterialTheme.colorScheme.onSurface, fontSize=14.sp) }
                }
            }
        }
        if (error.isNotBlank()) Text(error, Modifier.padding(horizontal=18.dp, vertical=4.dp), color=MaterialTheme.colorScheme.error, fontSize=12.sp)
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment=Alignment.Bottom) {
            OutlinedTextField(input, { input=it }, Modifier.weight(1f), placeholder={Text("Напишите команду или вопрос...")}, maxLines=4, shape=RoundedCornerShape(20.dp), trailingIcon={ IconButton(onClick={startVoice()}) { Icon(if(listening) Icons.Default.StopCircle else Icons.Default.Mic, "Голосовой ввод", tint=if(listening) MaterialTheme.colorScheme.error else Gold) } })
            Spacer(Modifier.width(6.dp)); IconButton(onClick={send()}, enabled=!busy) { Icon(if(busy) Icons.Default.HourglassTop else Icons.Default.Send, "Отправить", tint=Forest) }
        }
    }
    if (showSettings) AssistantSettingsDialog(s, {showSettings=false})
    if (openClientId.isNotBlank()) {
        val client = s.clients.firstOrNull { it.id == openClientId }
        if (client != null) ClientViewDialog(s, client) { s.assistantOpenClientId = ""; refresh() }
        else s.assistantOpenClientId = ""
    }
}

@Composable fun AssistantSettingsDialog(s: Store, close: () -> Unit) {
    var key by remember { mutableStateOf(s.openAiApiKey) }
    var model by remember { mutableStateOf(s.openAiModel) }
    AlertDialog(onDismissRequest=close, title={Text("Настройки ИИ-ассистента")}, text={Column { Text("Режим работы", fontSize=12.sp, color=MaterialTheme.colorScheme.secondary); Text("Локальный режим — без API-ключа. Ассистент понимает обычную речь и выполняет действия непосредственно в CRM.", fontSize=12.sp, color=MaterialTheme.colorScheme.primary); Spacer(Modifier.height(10.dp)); Text("Облачный режим OpenAI (необязательно)", fontSize=12.sp, color=MaterialTheme.colorScheme.secondary); OutlinedTextField(key,{key=it}, singleLine=true, placeholder={Text("Не требуется для работы")}); Spacer(Modifier.height(8.dp)); Text("Без ключа используются локальное понимание намерений, память CRM, голосовой ввод и работа с записями. Для интернет-поиска права и практики ассистент открывает результаты веб-поиска.", fontSize=11.sp, color=MaterialTheme.colorScheme.secondary) }}, confirmButton={Button(onClick={s.openAiApiKey=key.trim();s.openAiModel=model.trim().ifBlank{"gpt-5.6-luna"};close()}){Text("Сохранить")}}, dismissButton={TextButton(onClick=close){Text("Отмена")}})
}

fun assistantTools(): JSONArray {
    fun props(vararg pairs: Pair<String, String>): JSONObject = JSONObject().apply {
        put("type", "object")
        val p=JSONObject()
        pairs.forEach { (k,t)->p.put(k, JSONObject().put("type", t)) }
        put("properties", p)
        put("additionalProperties", false)
    }
    fun fn(name:String, desc:String, parameters:JSONObject, required:List<String>)=JSONObject().apply{
        put("type","function");put("name",name);put("description",desc)
        put("parameters",parameters.put("required",JSONArray(required)).put("additionalProperties",false))
    }
    return JSONArray().apply {
        put(JSONObject().apply{put("type","web_search")})
        put(fn("search_clients","Найти клиентов по имени, фамилии, телефону или email.",props("query" to "string"),listOf("query")))
        put(fn("show_client","Открыть полную карточку клиента со всеми делами, заседаниями, встречами, задачами, договорами, документами и платежами.",props("id" to "string"),listOf("id")))
        put(fn("get_client_overview","Получить подробную сводку по клиенту.",props("id" to "string"),listOf("id")))
        put(fn("create_client","Создать клиента.",props("name" to "string","phone" to "string","email" to "string","details" to "string","notes" to "string"),listOf("name")))
        put(fn("update_client","Изменить клиента.",props("id" to "string","name" to "string","phone" to "string","email" to "string","details" to "string","notes" to "string"),listOf("id")))

        put(fn("search_cases","Найти дела по номеру, клиенту, суду или категории.",props("query" to "string"),listOf("query")))
        put(fn("create_case","Создать дело и при наличии clientId связать его с клиентом.",props("clientId" to "string","client" to "string","no" to "string","court" to "string","category" to "string","date" to "string","description" to "string","notes" to "string"),listOf("no")))
        put(fn("update_case","Изменить дело по ID.",props("id" to "string","no" to "string","court" to "string","category" to "string","date" to "string","description" to "string","notes" to "string","status" to "string"),listOf("id")))
        put(fn("archive_case","Перенести дело в архив.",props("id" to "string"),listOf("id")))
        put(fn("delete_case","Подготовить удаление дела. Всегда требуется подтверждение.",props("id" to "string"),listOf("id")))

        put(fn("create_hearing","Добавить судебное заседание в конкретное дело.",props("caseId" to "string","date" to "string","time" to "string","status" to "string"),listOf("caseId","date","time")))
        put(fn("update_hearing","Изменить судебное заседание.",props("caseId" to "string","hearingId" to "string","date" to "string","time" to "string","status" to "string"),listOf("caseId","hearingId")))
        put(fn("delete_hearing","Удалить судебное заседание после подтверждения.",props("caseId" to "string","hearingId" to "string"),listOf("caseId","hearingId")))

        put(fn("search_tasks","Найти задачи по тексту, клиенту или делу.",props("query" to "string"),listOf("query")))
        put(fn("create_task","Создать задачу.",props("title" to "string","caseId" to "string","deadline" to "string","priority" to "string","description" to "string"),listOf("title")))
        put(fn("update_task","Изменить задачу.",props("id" to "string","title" to "string","deadline" to "string","priority" to "string","description" to "string","status" to "string"),listOf("id")))
        put(fn("archive_task","Перенести задачу в архив.",props("id" to "string"),listOf("id")))
        put(fn("delete_task","Подготовить удаление задачи. Всегда требуется подтверждение.",props("id" to "string"),listOf("id")))

        put(fn("search_meetings","Найти встречи по клиенту, дате или тексту.",props("query" to "string"),listOf("query")))
        put(fn("create_meeting","Создать встречу.",props("clientId" to "string","clientName" to "string","caseId" to "string","caseNo" to "string","date" to "string","time" to "string","place" to "string","notes" to "string"),listOf("date","time")))
        put(fn("update_meeting","Изменить или перенести встречу.",props("id" to "string","date" to "string","time" to "string","place" to "string","notes" to "string","clientName" to "string","clientId" to "string","caseId" to "string","caseNo" to "string"),listOf("id")))
        put(fn("archive_meeting","Перенести встречу в архив.",props("id" to "string"),listOf("id")))
        put(fn("delete_meeting","Подготовить удаление встречи. Всегда требуется подтверждение.",props("id" to "string"),listOf("id")))

        put(fn("search_contracts","Найти договоры по названию, клиенту или делу.",props("query" to "string"),listOf("query")))
        put(fn("create_contract","Создать договор и связать его с клиентом/делом. Если есть путь к уже существующему файлу, можно указать path.",props("name" to "string","type" to "string","clientId" to "string","caseId" to "string","path" to "string"),listOf("name")))
        put(fn("update_contract","Изменить договор.",props("id" to "string","name" to "string","type" to "string","clientId" to "string","caseId" to "string","path" to "string"),listOf("id")))
        put(fn("delete_contract","Подготовить удаление договора. Всегда требуется подтверждение.",props("id" to "string"),listOf("id")))

        put(fn("search_documents","Найти документы по названию, номеру дела или типу.",props("query" to "string"),listOf("query")))
        put(fn("open_document","Открыть существующий документ из CRM по ID.",props("id" to "string"),listOf("id")))
        put(fn("delete_document","Подготовить удаление документа. Всегда требуется подтверждение.",props("id" to "string"),listOf("id")))

        put(fn("add_payment","Внести оплату клиенту с датой, суммой и комментарием. Можно связать с услугой по serviceId.",props("clientId" to "string","amount" to "string","date" to "string","note" to "string","serviceId" to "string"),listOf("clientId","amount")))
        put(fn("delete_payment","Подготовить удаление платежа. Всегда требуется подтверждение.",props("clientId" to "string","paymentId" to "string"),listOf("clientId","paymentId")))
        put(fn("get_client_payments","Показать платежи, услуги и остаток клиента.",props("clientId" to "string"),listOf("clientId")))

        put(fn("remember_user_fact","Запомнить пользовательскую инструкцию или предпочтение.",props("text" to "string"),listOf("text")))
    }
}

fun executeAssistantFunction(s: Store, name: String, args: JSONObject, refresh: (() -> Unit)? = null): String {
    fun str(k:String)=args.optString(k,"")
    fun clientById(id:String)=s.clients.firstOrNull{it.id==id}
    fun caseById(id:String)=s.cases.firstOrNull{it.id==id}
    fun taskById(id:String)=s.tasks.firstOrNull{it.id==id}
    fun meetingById(id:String)=s.meetings.firstOrNull{it.id==id}
    fun contractById(id:String)=s.contracts.firstOrNull{it.id==id}
    fun docById(id:String)=s.docs.firstOrNull{it.id==id}
    when(name){
        "search_clients" -> {
            val q=str("query").trim(); if(q.isBlank()) return "Укажите имя, фамилию, телефон или email."
            val nq=q.lowercase(Locale("ru")); val matches=s.clients.filter{c->listOf(c.name,c.phone,c.email,c.details,c.notes).any{it.lowercase(Locale("ru")).contains(nq)}}.take(12)
            if(matches.isEmpty()) return "Клиенты по запросу «$q» не найдены."
            return matches.joinToString("\n"){c->"ID=${c.id} | ${c.name.ifBlank{"Без имени"}} | тел. ${c.phone.ifBlank{"—"}}"}
        }
        "show_client" -> { val c=clientById(str("id"))?:return "Клиент не найден.";s.assistantOpenClientId=c.id;refresh?.invoke();return "Открыл полную карточку клиента «${c.name.ifBlank{"Без имени"}}»: дела, заседания, встречи, задачи, договоры, документы и платежи." }
        "get_client_overview" -> {
            val c=clientById(str("id"))?:return "Клиент не найден."
            val cases=s.cases.filter{it.clientId==c.id || (it.clientId.isBlank()&&it.client.equals(c.name,true))}
            val meetings=s.meetings.filter{it.clientId==c.id || (it.clientId.isBlank()&&it.clientName.equals(c.name,true))}
            val tasks=s.tasks.filter{t->cases.any{it.id==t.caseId}}
            val contracts=s.contracts.filter{it.clientId==c.id || (it.clientId.isBlank()&&it.clientName.equals(c.name,true))}
            val docs=s.docs.filter{d->cases.any{it.id==d.caseId || (d.caseId.isBlank()&&d.caseNo.isNotBlank()&&d.caseNo==it.no)}}
            val hearings=cases.flatMap{ca->hearingsOf(ca).map{h->"${h.date} ${h.time} — дело № ${ca.no}"}}
            val payments=c.payments.joinToString("; "){"${it.amount} ₽ (${it.date.ifBlank{"дата не указана"}})"}.ifBlank{"нет"}
            return "${c.name}: дел ${cases.size}, заседаний ${hearings.size}, встреч ${meetings.size}, задач ${tasks.size}, договоров ${contracts.size}, документов ${docs.size}, платежей ${c.payments.size}. Заседания: ${hearings.joinToString("; ").ifBlank{"нет"}}. Платежи: $payments"
        }
        "create_client" -> { val c=Client(name=str("name"),phone=str("phone"),email=str("email"),details=str("details"),notes=str("notes"));s.clients=(s.clients+c).toMutableList();addActivity(s,"Создан клиент",c.name,"Создание");refresh?.invoke();return "Создал клиента «${c.name}»." }
        "update_client" -> { val c=clientById(str("id"))?:return "Клиент не найден";if(args.has("name"))c.name=str("name");if(args.has("phone"))c.phone=str("phone");if(args.has("email"))c.email=str("email");if(args.has("details"))c.details=str("details");if(args.has("notes"))c.notes=str("notes");c.updated=System.currentTimeMillis();s.clients=s.clients.map{if(it.id==c.id)c else it}.toMutableList();addActivity(s,"Изменён клиент",c.name,"Изменение");refresh?.invoke();return "Изменил данные клиента «${c.name}»." }
        "search_cases" -> { val q=str("query").lowercase(Locale("ru"));val ms=s.cases.filter{listOf(it.no,it.client,it.court,it.category).any{v->v.lowercase(Locale("ru")).contains(q)}}.take(15);return if(ms.isEmpty())"Дела не найдены." else ms.joinToString("\n"){ "ID=${it.id} | дело № ${it.no} | ${it.client} | ${it.court}" } }
        "create_case" -> { val c=Case(clientId=str("clientId"),client=str("client"),no=str("no"),court=str("court"),category=str("category"),date=str("date"),description=str("description"),notes=str("notes")); if(c.clientId.isNotBlank()&&c.client.isBlank())c.client=clientById(c.clientId)?.name.orEmpty();s.cases=(s.cases+c).toMutableList();addActivity(s,"Создано дело",c.no,"Создание");refresh?.invoke();return "Создал дело № ${c.no}${if(c.client.isNotBlank())" для ${c.client}" else ""}." }
        "update_case" -> { val c=caseById(str("id"))?:return "Дело не найдено";if(args.has("no"))c.no=str("no");if(args.has("court"))c.court=str("court");if(args.has("category"))c.category=str("category");if(args.has("date"))c.date=str("date");if(args.has("description"))c.description=str("description");if(args.has("notes"))c.notes=str("notes");if(args.has("status"))c.status=str("status");c.updated=System.currentTimeMillis();s.cases=s.cases.map{if(it.id==c.id)c else it}.toMutableList();addActivity(s,"Изменено дело",c.no,"Изменение");refresh?.invoke();return "Изменил дело № ${c.no}." }
        "archive_case" -> { val c=caseById(str("id"))?:return "Дело не найдено";c.status="Исполнено";s.cases=s.cases.map{if(it.id==c.id)c else it}.toMutableList();addActivity(s,"Дело перенесено в архив",c.no,"Исполнение");refresh?.invoke();return "Перенёс дело № ${c.no} в архив." }
        "create_hearing" -> { val c=caseById(str("caseId"))?:return "Дело не найдено";val h=Hearing(date=str("date"),time=str("time"),status=str("status").ifBlank{"В работе"});c.hearings=(c.hearings?:mutableListOf()).toMutableList().apply{add(h)};s.cases=s.cases.map{if(it.id==c.id)c else it}.toMutableList();addActivity(s,"Добавлено заседание","${c.no}: ${h.date} ${h.time}","Создание");refresh?.invoke();return "Добавил судебное заседание по делу № ${c.no}: ${h.date} ${h.time}." }
        "update_hearing" -> { val c=caseById(str("caseId"))?:return "Дело не найдено";val h=(c.hearings?:mutableListOf()).firstOrNull{it.id==str("hearingId")}?:return "Заседание не найдено";if(args.has("date"))h.date=str("date");if(args.has("time"))h.time=str("time");if(args.has("status"))h.status=str("status");s.cases=s.cases.map{if(it.id==c.id)c else it}.toMutableList();addActivity(s,"Изменено заседание","${c.no}: ${h.date} ${h.time}","Изменение");refresh?.invoke();return "Изменил заседание по делу № ${c.no}: ${h.date} ${h.time}." }
        "delete_hearing" -> { val c=caseById(str("caseId"))?:return "Дело не найдено";val h=(c.hearings?:mutableListOf()).firstOrNull{it.id==str("hearingId")}?:return "Заседание не найдено";s.assistantPendingDelete=JSONObject().put("type","hearing").put("id",h.id).put("caseId",c.id).toString();return "Подтвердите удаление заседания ${h.date} ${h.time} по делу № ${c.no}. Ответьте «Да»." }
        "search_tasks" -> { val q=str("query").lowercase(Locale("ru"));val ms=s.tasks.filter{listOf(it.title,it.description,it.caseNo).any{v->v.lowercase(Locale("ru")).contains(q)}}.take(15);return if(ms.isEmpty())"Задачи не найдены." else ms.joinToString("\n"){ "ID=${it.id} | ${it.title} | ${it.deadline}" } }
        "create_task" -> { val t=Task(title=str("title"),caseId=str("caseId"),caseNo=s.cases.firstOrNull{it.id==str("caseId")}?.no.orEmpty(),deadline=str("deadline"),priority=str("priority").ifBlank{"Средний"},description=str("description"));s.tasks=(s.tasks+t).toMutableList();addActivity(s,"Создана задача",t.title,"Создание");refresh?.invoke();return "Создал задачу «${t.title}»${if(t.deadline.isNotBlank())" со сроком ${t.deadline}" else ""}." }
        "update_task" -> { val t=taskById(str("id"))?:return "Задача не найдена";if(args.has("title"))t.title=str("title");if(args.has("deadline"))t.deadline=str("deadline");if(args.has("priority"))t.priority=str("priority");if(args.has("description"))t.description=str("description");if(args.has("status"))t.status=str("status");s.tasks=s.tasks.map{if(it.id==t.id)t else it}.toMutableList();addActivity(s,"Изменена задача",t.title,"Изменение");refresh?.invoke();return "Изменил задачу «${t.title}»." }
        "archive_task" -> { val t=taskById(str("id"))?:return "Задача не найдена";t.status="Исполнено";s.tasks=s.tasks.map{if(it.id==t.id)t else it}.toMutableList();addActivity(s,"Задача перенесена в архив",t.title,"Исполнение");refresh?.invoke();return "Перенёс задачу «${t.title}» в архив." }
        "search_meetings" -> { val q=str("query").lowercase(Locale("ru"));val ms=s.meetings.filter{listOf(it.clientName,it.name,it.date,it.time,it.place,it.notes,it.caseNo).any{v->v.lowercase(Locale("ru")).contains(q)}}.take(15);return if(ms.isEmpty())"Встречи не найдены." else ms.joinToString("\n"){ "ID=${it.id} | ${it.date} ${it.time} | ${it.clientName.ifBlank{it.name}}" } }
        "create_meeting" -> { val m=Meeting(name=str("clientName"),clientId=str("clientId"),clientName=str("clientName"),caseId=str("caseId"),caseNo=str("caseNo"),date=str("date"),time=str("time"),place=str("place"),notes=str("notes"));s.meetings=(s.meetings+m).toMutableList();addActivity(s,"Создана встреча",m.name.ifBlank{"Встреча"},"Создание");refresh?.invoke();return "Создал встречу ${m.date} ${m.time}${if(m.clientName.isNotBlank())" с ${m.clientName}" else ""}." }
        "update_meeting" -> { val m=meetingById(str("id"))?:return "Встреча не найдена";if(args.has("date"))m.date=str("date");if(args.has("time"))m.time=str("time");if(args.has("place"))m.place=str("place");if(args.has("notes"))m.notes=str("notes");if(args.has("clientName"))m.clientName=str("clientName");if(args.has("clientId"))m.clientId=str("clientId");if(args.has("caseId"))m.caseId=str("caseId");if(args.has("caseNo"))m.caseNo=str("caseNo");s.meetings=s.meetings.map{if(it.id==m.id)m else it}.toMutableList();addActivity(s,"Изменена встреча",m.clientName.ifBlank{"Встреча"},"Изменение");refresh?.invoke();return "Изменил встречу: ${m.date} ${m.time}." }
        "archive_meeting" -> { val m=meetingById(str("id"))?:return "Встреча не найдена";m.status="Исполнено";s.meetings=s.meetings.map{if(it.id==m.id)m else it}.toMutableList();addActivity(s,"Встреча перенесена в архив",m.clientName.ifBlank{"Встреча"},"Исполнение");refresh?.invoke();return "Перенёс встречу ${m.date} ${m.time} в архив." }
        "search_contracts" -> { val q=str("query").lowercase(Locale("ru"));val ms=s.contracts.filter{listOf(it.name,it.clientName,it.caseNo,it.type).any{v->v.lowercase(Locale("ru")).contains(q)}}.take(15);return if(ms.isEmpty())"Договоры не найдены." else ms.joinToString("\n"){ "ID=${it.id} | ${it.name} | ${it.clientName} | дело ${it.caseNo.ifBlank{"—"}}" } }
        "create_contract" -> { val c=Contract(name=str("name"),type=str("type").ifBlank{"Договор"},clientId=str("clientId"),caseId=str("caseId"),path=str("path"));c.clientName=clientById(c.clientId)?.name.orEmpty();c.caseNo=caseById(c.caseId)?.no.orEmpty();s.contracts=(s.contracts+c).toMutableList();addActivity(s,"Добавлен договор",c.name,"Создание");refresh?.invoke();return "Создал договор «${c.name}»${if(c.clientName.isNotBlank())" для ${c.clientName}" else ""}." }
        "update_contract" -> { val c=contractById(str("id"))?:return "Договор не найден";if(args.has("name"))c.name=str("name");if(args.has("type"))c.type=str("type");if(args.has("clientId")){c.clientId=str("clientId");c.clientName=clientById(c.clientId)?.name.orEmpty()};if(args.has("caseId")){c.caseId=str("caseId");c.caseNo=caseById(c.caseId)?.no.orEmpty()};if(args.has("path"))c.path=str("path");s.contracts=s.contracts.map{if(it.id==c.id)c else it}.toMutableList();addActivity(s,"Изменён договор",c.name,"Изменение");refresh?.invoke();return "Изменил договор «${c.name}»." }
        "search_documents" -> { val q=str("query").lowercase(Locale("ru"));val ms=s.docs.filter{listOf(it.name,it.caseNo,it.type).any{v->v.lowercase(Locale("ru")).contains(q)}}.take(15);return if(ms.isEmpty())"Документы не найдены." else ms.joinToString("\n"){ "ID=${it.id} | ${it.name} | ${it.type} | дело ${it.caseNo.ifBlank{"—"}}" } }
        "open_document" -> { val d=docById(str("id"))?:return "Документ не найден";openDocumentFile(s,d);return "Открыл документ «${d.name}»." }
        "add_payment" -> { val c=clientById(str("clientId"))?:return "Клиент не найден";val p=Payment(amount=str("amount"),date=str("date"),note=str("note"),serviceId=str("serviceId"));c.payments=(c.payments+p).toMutableList();s.clients=s.clients.map{if(it.id==c.id)c else it}.toMutableList();addActivity(s,"Добавлен платёж","${c.name}: ${p.amount} ₽","Создание");refresh?.invoke();return "Внёс оплату ${p.amount} ₽ клиенту «${c.name}»${if(p.date.isNotBlank())" от ${p.date}" else ""}." }
        "get_client_payments" -> { val c=clientById(str("clientId"))?:return "Клиент не найден";val total=c.payments.sumOf{parseMoney(it.amount)};val balance=parseMoney(c.fee)-total;return "Платежи клиента «${c.name}»: ${c.payments.joinToString("; "){"${it.amount} ₽ от ${it.date.ifBlank{"—"}}"}.ifBlank{"нет"}}. Всего оплачено: ${formatMoney(total)} ₽. Остаток по общей сумме: ${formatMoney(balance.coerceAtLeast(0.0))} ₽." }
        "remember_user_fact" -> { val mem=str("text");s.assistantMemories=(s.assistantMemories+AssistantMemory(text=mem)).toMutableList();return "Запомнил: $mem" }
        "delete_client","delete_case","delete_task","delete_meeting","delete_contract","delete_document","delete_payment" -> {
            val type=name.removePrefix("delete_");val id=str("id");
            val title=when(type){"client"->clientById(id)?.name;"case"->caseById(id)?.no;"task"->taskById(id)?.title;"meeting"->meetingById(id)?.clientName;"contract"->contractById(id)?.name;"document"->docById(id)?.name;"payment"->"платёж $id";else->null}
            if(title==null && type!="payment") return "Запись не найдена"
            s.assistantPendingDelete=JSONObject(args.toString()).put("type",type).toString()
            return "Подтвердите удаление ${when(type){"client"->"клиента";"case"->"дела";"task"->"задачи";"meeting"->"встречи";"contract"->"договора";"document"->"документа";else->"платежа"}} «${title ?: id}». Ответьте «Да»."
        }
    }
    return "Функция $name выполнена."
}

fun executeConfirmedDelete(s: Store, type: String, args: JSONObject, refresh: (() -> Unit)? = null): String {
    val id=args.optString("id")
    return when(type){
        "client" -> { val c=s.clients.firstOrNull{it.id==id}?:return "Клиент не найден";softDeleteClient(s,c){};addActivity(s,"Удалён клиент",c.name,"Удаление");refresh?.invoke();"Клиент «${c.name}» удалён и перемещён в Корзину." }
        "case" -> { val c=s.cases.firstOrNull{it.id==id}?:return "Дело не найдено";softDeleteCase(s,c){};addActivity(s,"Удалено дело",c.no,"Удаление");refresh?.invoke();"Дело «${c.no}» удалено и перемещено в Корзину." }
        "task" -> { val t=s.tasks.firstOrNull{it.id==id}?:return "Задача не найдена";softDeleteTask(s,t){};addActivity(s,"Удалена задача",t.title,"Удаление");refresh?.invoke();"Задача «${t.title}» удалена и перемещена в Корзину." }
        "meeting" -> { val m=s.meetings.firstOrNull{it.id==id}?:return "Встреча не найдена";softDeleteMeeting(s,m){};addActivity(s,"Удалена встреча",m.clientName.ifBlank{"Встреча"},"Удаление");refresh?.invoke();"Встреча удалена и перемещена в Корзину." }
        "contract" -> { val c=s.contracts.firstOrNull{it.id==id}?:return "Договор не найден";s.trash=(s.trash+TrashItem(type="contract",title=c.name,payload=Gson().toJson(c))).toMutableList();s.contracts=s.contracts.filterNot{it.id==c.id}.toMutableList();addActivity(s,"Удалён договор",c.name,"Удаление");refresh?.invoke();"Договор «${c.name}» удалён и перемещён в Корзину." }
        "document" -> { val d=s.docs.firstOrNull{it.id==id}?:return "Документ не найден";softDeleteDoc(s,d){};refresh?.invoke();"Документ «${d.name}» удалён и перемещён в Корзину." }
        "payment" -> { val clientId=args.optString("clientId");val c=s.clients.firstOrNull{it.id==clientId}?:return "Клиент не найден";val p=c.payments.firstOrNull{it.id==id}?:return "Платёж не найден";c.payments=c.payments.filterNot{it.id==id}.toMutableList();s.clients=s.clients.map{if(it.id==c.id)c else it}.toMutableList();addActivity(s,"Удалён платёж","${c.name}: ${p.amount} ₽","Удаление");refresh?.invoke();"Платёж ${p.amount} ₽ клиента «${c.name}» удалён." }
        "hearing" -> { val c=s.cases.firstOrNull{it.id==args.optString("caseId")}?:return "Дело не найдено";val h=(c.hearings?:mutableListOf()).firstOrNull{it.id==id}?:return "Заседание не найдено";c.hearings=(c.hearings?:mutableListOf()).filterNot{it.id==id}.toMutableList();s.cases=s.cases.map{if(it.id==c.id)c else it}.toMutableList();addActivity(s,"Удалено заседание","${c.no}: ${h.date} ${h.time}","Удаление");refresh?.invoke();"Заседание ${h.date} ${h.time} по делу № ${c.no} удалено." }
        else -> "Неизвестный тип записи"
    }
}


fun localAssistantReply(s: Store, text: String, refresh: (() -> Unit)? = null): String {
    val q = text.trim()
    val lower = q.lowercase(Locale("ru"))
    fun findClient(name: String): Client? {
        val n=name.trim().lowercase(Locale("ru"))
        return s.clients.firstOrNull { it.name.lowercase(Locale("ru")).contains(n) }
    }
    fun clientFromText(): Client? {
        val byId = Regex("(?:клиент|по|у|для)\\s+([А-ЯЁA-Z][А-ЯЁA-Zа-яёa-z-]+(?:\\s+[А-ЯЁA-Zа-яёA-Z-]+){0,2})").find(q)
        val candidate = byId?.groupValues?.getOrNull(1).orEmpty()
        return if (candidate.isNotBlank()) findClient(candidate) else s.clients.firstOrNull { lower.contains(it.name.lowercase(Locale("ru")).split(" ").firstOrNull().orEmpty()) && it.name.isNotBlank() }
    }
    fun dateFromText(): String {
        val explicit = Regex("\\b\\d{1,2}[./]\\d{1,2}(?:[./]\\d{2,4})?\\b").find(q)?.value
        if (explicit != null) {
            val p=explicit.replace('/','.').split('.')
            val y=when(p.size){3->if(p[2].length==2)"20${p[2]}" else p[2]; else->SimpleDateFormat("yyyy",Locale.US).format(Date())}
            return "%02d.%02d.%s".format(Locale.US,p[0].toInt(),p[1].toInt(),y)
        }
        val cal=Calendar.getInstance()
        if (lower.contains("послезавтра")) cal.add(Calendar.DAY_OF_MONTH,2)
        else if (lower.contains("завтра")) cal.add(Calendar.DAY_OF_MONTH,1)
        else return SimpleDateFormat("dd.MM.yyyy",Locale.US).format(cal.time)
        return SimpleDateFormat("dd.MM.yyyy",Locale.US).format(cal.time)
    }
    fun timeFromText(): String = Regex("\\b([01]?\\d|2[0-3])[:.]([0-5]\\d)\\b").find(q)?.let { "%02d:%02d".format(Locale.US,it.groupValues[1].toInt(),it.groupValues[2].toInt()) } ?: ""
    fun refreshNow(){ refresh?.invoke() }
    if (lower.startsWith("запомни ")) { val mem=q.substringAfter("запомни ").trim(); if(mem.isNotBlank()){s.assistantMemories=(s.assistantMemories+AssistantMemory(text=mem)).toMutableList();refreshNow();return "Запомнил: $mem"} }
    if (lower in listOf("да","подтверждаю","подтвердить") && s.assistantPendingDelete.isNotBlank()) return runCatching { val p=JSONObject(s.assistantPendingDelete); val r=executeConfirmedDelete(s,p.optString("type"),p,refresh); s.assistantPendingDelete=""; r }.getOrElse { it.message ?: "Не удалось удалить запись." }

    // Full client overview / navigation.
    if ((lower.contains("покажи") || lower.contains("открой") || lower.contains("всё") || lower.contains("все")) && (lower.contains("по ") || lower.contains("про ") || lower.contains("клиент"))) {
        val c=clientFromText()
        if(c!=null){s.assistantOpenClientId=c.id;refreshNow();return "Открыл карточку клиента «${c.name}» со всеми делами, заседаниями, встречами, задачами, договорами, документами и платежами."}
    }
    if (lower.contains("найди") && (lower.contains("клиент") || lower.contains("иванов") || lower.contains("петров") || lower.contains("сидоров"))) {
        val c=clientFromText()
        return if(c!=null){s.assistantOpenClientId=c.id;refreshNow();"Нашёл клиента «${c.name}» и открыл его карточку."} else "Клиент не найден. Уточните фамилию, имя или телефон."
    }

    // Legal / case-law: no API key is needed; open a web search in the device browser.
    if (lower.contains("судебн") || lower.contains("судебную практику") || lower.contains("практик") || lower.contains("закон") || lower.contains("ук рф") || lower.contains("гк рф") || lower.contains("упк рф") || lower.contains("гпк рф")) {
        val encoded=java.net.URLEncoder.encode(q,"UTF-8")
        val uri=android.net.Uri.parse("https://www.google.com/search?q=$encoded")
        val ctx=s.context()
        runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW,uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        return "Открыл веб-поиск по запросу «$q». API-ключ не требуется. После просмотра источников вернитесь в CRM — данные CRM остаются доступными без облачного ИИ."
    }

    // Delete intents: ask for confirmation and never delete immediately.
    if (lower.contains("удали") || lower.contains("удалить")) {
        val c=clientFromText()
        if(lower.contains("клиент") && c!=null){s.assistantPendingDelete=JSONObject().put("type","client").put("id",c.id).toString();return "Подтвердите удаление клиента «${c.name}». Ответьте «Да»."}
        val cse=s.cases.firstOrNull{lower.contains(it.no.lowercase(Locale("ru"))) && it.no.isNotBlank()}
        if((lower.contains("дело")||lower.contains("дела")) && cse!=null){s.assistantPendingDelete=JSONObject().put("type","case").put("id",cse.id).toString();return "Подтвердите удаление дела № ${cse.no}. Ответьте «Да»."}
        val t=s.tasks.firstOrNull{lower.contains(it.title.lowercase(Locale("ru"))) && it.title.isNotBlank()}
        if((lower.contains("задач")||lower.contains("задачу")) && t!=null){s.assistantPendingDelete=JSONObject().put("type","task").put("id",t.id).toString();return "Подтвердите удаление задачи «${t.title}». Ответьте «Да»."}
        val m=s.meetings.firstOrNull{val n=it.clientName.ifBlank{it.name};n.isNotBlank() && lower.contains(n.lowercase(Locale("ru")))}
        if((lower.contains("встреч")||lower.contains("встречу")) && m!=null){s.assistantPendingDelete=JSONObject().put("type","meeting").put("id",m.id).toString();return "Подтвердите удаление встречи «${m.clientName.ifBlank{m.name}}». Ответьте «Да»."}
    }

    // Archive intents.
    if (lower.contains("архив") || lower.contains("в архив")) {
        val cse=s.cases.firstOrNull{it.no.isNotBlank() && lower.contains(it.no.lowercase(Locale("ru")))}
        if(cse!=null){completeCase(s,cse,::refreshNow);return "Перенёс дело № ${cse.no} в архив как исполненное."}
        val c=clientFromText()
        if(c!=null && lower.contains("клиент")){return "Клиенты не переносятся в архив отдельной операцией; можно удалить клиента в Корзину."}
        val t=s.tasks.firstOrNull{it.title.isNotBlank() && lower.contains(it.title.lowercase(Locale("ru")))}
        if(t!=null){completeTask(s,t,::refreshNow);return "Перенёс задачу «${t.title}» в архив как исполненную."}
        val m=s.meetings.firstOrNull{val n=it.clientName.ifBlank{it.name};n.isNotBlank()&&lower.contains(n.lowercase(Locale("ru")))}
        if(m!=null){completeMeeting(s,m,::refreshNow);return "Перенёс встречу в архив как исполненную."}
    }

    // Create client.
    if (lower.contains("создай") && lower.contains("клиент")) {
        val raw=q.substringAfter("клиент","").trim().trim(',','.',':',' ')
        val phone=Regex("\\+?\\d[\\d ()-]{8,}").find(q)?.value.orEmpty()
        val name=raw.split(Regex("(?i)\\bтелефон\\b")).firstOrNull().orEmpty().trim().trim(',','.')
        if(name.isBlank()) return "Уточните ФИО клиента."
        val c=Client(name=capitalizeInput(name),phone=phone)
        s.clients=(s.clients+c).toMutableList();addActivity(s,"Создан клиент",c.name,"Создание");refreshNow();return "Создал клиента «${c.name}»${if(phone.isNotBlank())", телефон $phone" else ""}."
    }
    // Create case.
    if (lower.contains("создай") && lower.contains("дело")) {
        val c=clientFromText(); val no=Regex("(?:№|номер)\\s*([A-Za-zА-Яа-я0-9/-]+)",RegexOption.IGNORE_CASE).find(q)?.groupValues?.get(1).orEmpty()
        if(c==null) return "Уточните клиента для дела."
        val case=Case(no=no,client=c.name,clientId=c.id)
        s.cases=(s.cases+case).toMutableList();addActivity(s,"Создано дело",case.no.ifBlank{"Без номера"},"Создание");refreshNow();return "Создал дело${if(no.isNotBlank())" № $no" else ""} для клиента «${c.name}»."
    }
    // Create task.
    if (lower.contains("создай") && lower.contains("задач")) {
        val title=q.substringAfter("задачу",q.substringAfter("задача","")).trim().trim(':',' ','-')
        if(title.isBlank()) return "Уточните текст задачи."
        val c=clientFromText(); val t=Task(title=title,caseId=c?.let{ s.cases.firstOrNull{x->x.clientId==it.id}?.id }.orEmpty(),caseNo=c?.let{s.cases.firstOrNull{x->x.clientId==it.id}?.no}.orEmpty(),deadline=dateFromText())
        s.tasks=(s.tasks+t).toMutableList();addActivity(s,"Создана задача",t.title,"Создание");refreshNow();return "Создал задачу «${t.title}»${if(c!=null)" для ${c.name}" else ""}. Срок: ${t.deadline}."
    }
    // Create meeting.
    if (lower.contains("создай") && lower.contains("встреч")) {
        val c=clientFromText(); val tm=timeFromText(); val dt=dateFromText(); val name=c?.name.orEmpty()
        if(c==null) return "Уточните клиента для встречи."
        val m=Meeting(name=name,date=dt,time=tm,clientId=c.id,clientName=c.name,caseId=s.cases.firstOrNull{it.clientId==c.id}?.id.orEmpty(),caseNo=s.cases.firstOrNull{it.clientId==c.id}?.no.orEmpty())
        s.meetings=(s.meetings+m).toMutableList();addActivity(s,"Создана встреча",c.name,"Создание");refreshNow();return "Создал встречу с «${c.name}» на $dt${if(tm.isNotBlank())" в $tm" else ""}."
    }
    // Create contract.
    if (lower.contains("создай") && lower.contains("договор")) {
        val c=clientFromText(); if(c==null)return "Уточните клиента для договора."
        val title=q.substringAfter("договор","").trim().trim(':',' ','-').ifBlank{"Договор"}; val ca=s.cases.firstOrNull{it.clientId==c.id}
        val ct=Contract(name=title,clientId=c.id,clientName=c.name,caseId=ca?.id.orEmpty(),caseNo=ca?.no.orEmpty())
        s.contracts=(s.contracts+ct).toMutableList();addActivity(s,"Создан договор",title,"Создание");refreshNow();return "Создал договор «$title» для клиента «${c.name}»."
    }
    // Add payment.
    if ((lower.contains("внеси") || lower.contains("добавь") || lower.contains("оплату") || lower.contains("платёж") || lower.contains("платеж")) && Regex("\\d+[\\s\\d]*([.,]\\d+)?").containsMatchIn(q)) {
        val c=clientFromText() ?: return "Уточните клиента для оплаты."
        val amount=Regex("\\d+[\\s\\d]*([.,]\\d+)?").find(q)?.value?.replace(" ","")?.replace(',','.') ?: return "Уточните сумму оплаты."
        val p=Payment(amount=amount,date=SimpleDateFormat("dd.MM.yyyy",Locale.US).format(Date()),note=q)
        c.payments=(c.payments+p).toMutableList();c.paid=formatMoney(c.payments.sumOf{parseMoney(it.amount)});s.clients=s.clients.map{if(it.id==c.id)c else it}.toMutableList();addActivity(s,"Добавлена оплата","${c.name}: $amount ₽","Оплата");refreshNow();return "Внёс оплату ${formatMoney(parseMoney(amount))} ₽ клиенту «${c.name}». Всего оплачено: ${formatMoney(c.payments.sumOf{parseMoney(it.amount)})} ₽."
    }
    // Simple status queries.
    val c=clientFromText()
    if(c!=null && (lower.contains("сколько")||lower.contains("оплат")||lower.contains("остат"))){val paid=c.payments.sumOf{parseMoney(it.amount)};val bal=parseMoney(c.fee)-paid;return "По клиенту «${c.name}»: оплачено ${formatMoney(paid)} ₽, остаток ${formatMoney(bal.coerceAtLeast(0.0))} ₽."}
    if(lower.contains("что") && lower.contains("по") && c!=null){val cases=s.cases.count{it.clientId==c.id};val meetings=s.meetings.count{it.clientId==c.id};val tasks=s.tasks.count{it.caseId.isNotBlank()&&s.cases.any{x->x.id==it.caseId&&x.clientId==c.id}};return "По клиенту «${c.name}»: дел — $cases, встреч — $meetings, задач — $tasks, договоров — ${s.contracts.count{it.clientId==c.id}}, платежей — ${c.payments.size}."}
    return "Я работаю в локальном режиме без API-ключа. Понимаю запросы на поиск клиентов, создание и изменение записей CRM, архивирование, удаление с подтверждением, платежи и открытие карточек. Сформулируйте действие обычными словами."
}

fun runAssistantRequest(s: Store, userText: String, refresh: (() -> Unit)? = null): String {
    if (s.openAiApiKey.isBlank()) return localAssistantReply(s, userText, refresh)
    val memories=s.assistantMemories.joinToString("\n"){ "- ${it.text}" }.ifBlank{"нет"}
    val clientCtx=s.clients.joinToString("; "){ "${it.id} | ${it.name} | ${it.phone}" }.ifBlank{"нет"}
    val caseCtx=s.cases.joinToString("; "){ "${it.id} | ${it.no} | ${it.client}" }.ifBlank{"нет"}
    val taskCtx=s.tasks.joinToString("; "){ "${it.id} | ${it.title} | ${it.deadline}" }.ifBlank{"нет"}
    val meetingCtx=s.meetings.joinToString("; "){ "${it.id} | ${it.clientName.ifBlank{it.name}} | ${it.date} ${it.time}" }.ifBlank{"нет"}
    val contractCtx=s.contracts.joinToString("; "){ "${it.id} | ${it.name} | ${it.clientName} | ${it.caseNo}" }.ifBlank{"нет"}
    val docCtx=s.docs.joinToString("; "){ "${it.id} | ${it.name} | ${it.caseNo} | ${it.type}" }.ifBlank{"нет"}
    val paymentCtx=s.clients.joinToString("; "){ c -> c.payments.joinToString("; "){ p -> "${c.id}|${p.id}|${p.amount}|${p.date}" } }.ifBlank{"нет"}
    val crm="Клиенты: $clientCtx\nДела: $caseCtx\nЗадачи: $taskCtx\nВстречи: $meetingCtx\nДоговоры: $contractCtx\nДокументы: $docCtx\nПлатежи: $paymentCtx"
    val system="Ты ИИ-ассистент адвоката внутри Advokat CRM. Понимай обычную человеческую речь и самостоятельно определяй намерение, сущность, клиента и нужную операцию. Не требуй от пользователя знать ID: сначала используй поиск/сводку, затем выполняй действие. Для «покажи всё по Иванову» найди клиента и вызови show_client. Для создания, изменения, переноса, архивации и удаления реально изменяй данные CRM через функции. После каждого успешно выполненного действия обязательно ответь пользователю кратко и конкретно, что именно ты сделал и с какой записью; не говори «готово», если функция вернула ошибку. Если данных недостаточно или найдено несколько кандидатов — задай уточняющий вопрос, не угадывай. Для удаления всегда требуй явного подтверждения. Для платежей используй add_payment/delete_payment, для договоров create_contract/update_contract/delete_contract, для документов search_documents/open_document/delete_document, для заседаний create_hearing/update_hearing/delete_hearing. Для поиска актуального права и судебной практики обязательно используй web_search и указывай источники. Пользовательские заметки: $memories. Состояние CRM: $crm"
    var responseId:String?=null
    var input:JSONArray=JSONArray().put(JSONObject().apply{put("role","system");put("content",system)}).put(JSONObject().apply{put("role","user");put("content",userText)})
    repeat(4){
        val body=JSONObject().apply{put("model",s.openAiModel.ifBlank{"gpt-5.6-luna"});put("input",input);put("tools",assistantTools()) ; responseId?.let{put("previous_response_id",it)}}
        val conn=(URL("https://api.openai.com/v1/responses").openConnection() as HttpURLConnection).apply{requestMethod="POST";doOutput=true;setRequestProperty("Authorization","Bearer ${s.openAiApiKey}");setRequestProperty("Content-Type","application/json");connectTimeout=30000;readTimeout=90000}
        conn.outputStream.use{it.write(body.toString().toByteArray(Charsets.UTF_8))}
        val txt=(if(conn.responseCode in 200..299)conn.inputStream else conn.errorStream).bufferedReader().use{it.readText()}
        if(conn.responseCode !in 200..299)throw IllegalStateException("OpenAI: ${conn.responseCode} ${txt.take(500)}")
        val json=JSONObject(txt);responseId=json.optString("id",null);val output=json.optJSONArray("output")?:JSONArray();var finalText="";val calls=mutableListOf<JSONObject>()
        for(i in 0 until output.length()){val item=output.optJSONObject(i)?:continue;when(item.optString("type")){"message"->{val c=item.optJSONArray("content")?:JSONArray();for(j in 0 until c.length())finalText+=c.optJSONObject(j)?.optString("text").orEmpty()}"function_call"->calls.add(item)}}
        if(calls.isEmpty())return finalText.ifBlank{"Готово."}
        val outputs=JSONArray();calls.forEach{call->val args=runCatching{JSONObject(call.optString("arguments","{}"))}.getOrDefault(JSONObject());val result=executeAssistantFunction(s,call.optString("name"),args,refresh);outputs.put(JSONObject().apply{put("type","function_call_output");put("call_id",call.optString("call_id"));put("output",result)})};input=outputs
    }
    return "Не удалось завершить действие за один запрос."
}


@Composable
fun CalendarScreen(s: Store, refresh: () -> Unit, onMenu: () -> Unit) {
    var deleting by remember { mutableStateOf<Case?>(null) }
    var monthOffset by remember { mutableIntStateOf(0) }
    var selectedDay by remember { mutableStateOf<String?>(null) }
    val cal = remember(monthOffset) { Calendar.getInstance().apply { add(Calendar.MONTH, monthOffset); set(Calendar.DAY_OF_MONTH, 1) } }
    val monthName = SimpleDateFormat("LLLL yyyy", Locale("ru")).format(cal.time).replaceFirstChar { it.uppercase() }
    val firstDow = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7
    val days = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    val cases = s.cases.filter { !it.status.equals("Исполнено", true) }
    val meetings = s.meetings.filter { !it.status.equals("Исполнено", true) }
    val tasks = s.tasks.filter { !it.status.equals("Исполнено", true) && !it.status.equals("Готово", true) && s.cases.firstOrNull { c -> c.id == it.caseId }?.status != "Исполнено" }
    val hearings = cases.flatMap { c -> hearingsOf(c).filter { !it.status.equals("Исполнено", true) }.map { h -> c to h } }
    val byDate = hearings.groupBy { it.second.date }
    val meetingByDate = meetings.groupBy { it.date }
    val taskByDate = tasks.mapNotNull { t -> t.deadline.substringBefore(" ").takeIf { it.matches(Regex("\\d{2}\\.\\d{2}\\.\\d{4}")) }?.let { it to t } }.groupBy { it.first }
    Column(Modifier.fillMaxSize()) {
        Header(s, onMenu, "Календарь")
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { monthOffset-- }) { Icon(Icons.Default.ChevronLeft, "Предыдущий месяц", tint = MaterialTheme.colorScheme.primary) }
            Text(monthName, Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            IconButton(onClick = { monthOffset++ }) { Icon(Icons.Default.ChevronRight, "Следующий месяц", tint = MaterialTheme.colorScheme.primary) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            listOf("Пн","Вт","Ср","Чт","Пт","Сб","Вс").forEach { Text(it, Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary) }
        }
        Column(Modifier.padding(horizontal = 10.dp)) {
            val total = ((firstDow + days + 6) / 7) * 7
            for (row in 0 until total step 7) {
                Row(Modifier.fillMaxWidth()) {
                    for (col in 0..6) {
                        val n = row + col - firstDow + 1
                        if (n in 1..days) {
                            val date = String.format(Locale.US, "%02d.%02d.%04d", n, cal.get(Calendar.MONTH) + 1, cal.get(Calendar.YEAR))
                            val hasEvent = byDate.containsKey(date) || meetingByDate.containsKey(date) || taskByDate.containsKey(date)
                            val selected = selectedDay == date
                            Box(Modifier.weight(1f).padding(2.dp).aspectRatio(1f).clickable { selectedDay = date }) {
                                Surface(Modifier.fillMaxSize(), RoundedCornerShape(12.dp), color = if (selected) Forest else if (hasEvent) Gold.copy(alpha = .18f) else White) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                        Text(n.toString(), color = if (selected) White else MaterialTheme.colorScheme.primary, fontWeight = if (hasEvent) FontWeight.Bold else FontWeight.Normal)
                                        if (hasEvent) Icon(Icons.Default.Event, null, Modifier.size(12.dp), tint = if (selected) White else Gold)
                                    }
                                }
                            }
                        } else { Spacer(Modifier.weight(1f).padding(2.dp).aspectRatio(1f)) }
                    }
                }
            }
        }
        HorizontalDivider(Modifier.padding(vertical = 8.dp), color = Gold.copy(alpha = .25f))
        val shown = selectedDay?.let { byDate[it].orEmpty() } ?: hearings.filter { it.second.date == SimpleDateFormat("dd.MM.yyyy", Locale.US).format(Date()) }
        Text(if (selectedDay == null) "Сегодня" else "События ${selectedDay}", Modifier.padding(horizontal = 18.dp, vertical = 8.dp), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        val shownMeetings = selectedDay?.let { meetingByDate[it].orEmpty() } ?: meetings.filter { it.date == SimpleDateFormat("dd.MM.yyyy", Locale.US).format(Date()) }
        val shownTasks = selectedDay?.let { taskByDate[it].orEmpty().map { pair -> pair.second } } ?: tasks.filter { it.deadline.substringBefore(" ") == SimpleDateFormat("dd.MM.yyyy", Locale.US).format(Date()) }
        if (shown.isEmpty() && shownMeetings.isEmpty() && shownTasks.isEmpty()) Text("На выбранную дату событий нет", Modifier.padding(18.dp), color = MaterialTheme.colorScheme.secondary)
        else LazyColumn {
            items(shown, key = { "hearing-${it.first.id}-${it.second.id}" }) { pair -> val c = pair.first; val h = pair.second
                Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = White)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${h.date} • ${h.time}", fontWeight = FontWeight.Bold, color = Gold)
                            Text(c.no.ifBlank { "Без номера дела" }, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Text(c.client.ifBlank { "Без клиента" }, color = Ink)
                            Text(c.court.ifBlank { "Суд не указан" }, color = MaterialTheme.colorScheme.secondary)
                            Text("Вид: ${c.category.ifBlank { "Судебное заседание" }}", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                        }
                        androidx.compose.material3.IconButton(onClick = { deleting = c }) {
                            Icon(Icons.Default.DeleteOutline, "Удалить дело", tint = Color(0xFF8A4A3A))
                        }
                    }
                }
            }
            items(shownTasks, key = { "task-${it.id}" }) { t ->
                Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = White)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.TaskAlt, null, tint = Gold, modifier = Modifier.size(30.dp))
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("${t.deadline}", fontWeight = FontWeight.Bold, color = Gold)
                            Text(t.title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            if (t.caseNo.isNotBlank()) Text("Дело № ${t.caseNo}", fontSize = 12.sp, color = Ink)
                            if (t.description.isNotBlank()) Text(t.description, fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                        }
                    }
                }
            }
            items(shownMeetings, key = { "meeting-${it.id}" }) { m ->
                Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = White)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Groups, null, tint = Gold, modifier = Modifier.size(30.dp))
                        Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text("${m.date} • ${m.time}", fontWeight=FontWeight.Bold, color=Gold); Text(m.name.ifBlank{"Без ФИО"},fontWeight=FontWeight.Bold); Text(m.place.ifBlank{"Место не указано"},fontSize=12.sp,color=MaterialTheme.colorScheme.secondary); if(m.notes.isNotBlank()) Text(m.notes,fontSize=11.sp,color=MaterialTheme.colorScheme.secondary) }
                    }
                }
            }
        }
        deleting?.let { c -> ConfirmDeleteDialog("дело", c.no.ifBlank { "без номера" }, { deleting = null }) { softDeleteCase(s, c, refresh); deleting = null } }
    }
}
@Composable
fun Clients(s: Store, refresh: () -> Unit, onMenu: () -> Unit) {
    var hidden by remember { mutableStateOf(setOf<String>()) }
    var editing by remember { mutableStateOf<Client?>(null) }
    var adding by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<Client?>(null) }
    var viewing by remember { mutableStateOf<Client?>(null) }
    var sort by rememberSaveable { mutableStateOf("Алфавиту") }
    var sortMenu by remember { mutableStateOf(false) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var addPayment by remember { mutableStateOf(false) }
    val clients = (if (sort == "Алфавиту") s.clients.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.name.trim() }) else s.clients.sortedByDescending { it.created }).filter { it.id !in hidden }
    Column(Modifier.fillMaxSize()) {
        Header(s, onMenu)
        ScreenTitle("Клиенты", Icons.Default.PeopleAlt) { adding = true }
        TabRow(selectedTabIndex = tab) {
            Tab(
                selected = tab == 0,
                onClick = { tab = 0 },
                icon = { Icon(Icons.Default.PeopleAlt, contentDescription = null) },
                text = { Text("Клиенты") }
            )
            Tab(
                selected = tab == 1,
                onClick = { tab = 1 },
                icon = { Icon(Icons.Default.Payments, contentDescription = null) },
                text = { Text("Платежи", fontSize = 12.sp) }
            )
        }
        if (tab == 0) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Сортировка:", fontWeight = FontWeight.Medium)
                Spacer(Modifier.width(8.dp))
                Box {
                    OutlinedButton(onClick = { sortMenu = true }) { Text(sort); Icon(Icons.Default.ArrowDropDown, null) }
                    DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                        listOf("Алфавиту", "Дате создания").forEach { v -> DropdownMenuItem(text = { Text(v) }, onClick = { sort = v; sortMenu = false }) }
                    }
                }
            }
            LazyColumn {
                items(clients, key = { it.id }) { c ->
                    val paid = if (c.payments.isNotEmpty()) c.payments.sumOf { it.amount.toDoubleOrNull() ?: 0.0 } else c.paid.toDoubleOrNull() ?: 0.0
                    EntityCard(Icons.Default.Person, c.name.ifBlank { "Без имени" }, "${c.phone} • ${c.email}\nОстаток: ${money(c.fee.toDoubleOrNull(), paid)}\nДела: ${s.cases.filter { it.clientId == c.id }.joinToString { it.no.ifBlank { "без номера" } }.ifBlank { "нет" }}", onDelete = { deleting = c }, onEdit = { editing = c }, onView = { viewing = c })
                }
            }
        } else {
            ClientPaymentsList(s, refresh)
        }
        if (adding) ClientDialog(s, refresh, { adding = false })
        editing?.let { c -> ClientDialog(s, refresh, { editing = null }, c) }
        deleting?.let { c -> ConfirmDeleteDialog("клиента", c.name, { deleting = null }) { softDeleteClient(s, c){hidden=hidden+c.id;refresh()}; deleting = null } }
        viewing?.let { c -> ClientViewDialog(s,c) { viewing = null } }
        if (addPayment) PaymentDialog(s, refresh) { addPayment = false }
    }
}

@Composable
fun ClientPaymentsList(s: Store, refresh: () -> Unit) {
    data class PaymentRow(val client: Client, val payment: Payment, val remaining: Double)

    val rows = s.clients.flatMap { client ->
        val ordered = client.payments.withIndex().sortedWith(
            compareBy<IndexedValue<Payment>> { parseDateTime(it.value.date) ?: Long.MIN_VALUE }
                .thenBy { it.index }
        )
        var paidBefore = 0.0
        val servicePaid = mutableMapOf<String, Double>()
        ordered.map { indexed ->
            val payment = indexed.value
            val amount = parseMoney(payment.amount)
            val service = client.services.firstOrNull { it.id == payment.serviceId }
            val remaining = if (service != null) {
                val paidForService = (servicePaid[service.id] ?: 0.0) + amount
                servicePaid[service.id] = paidForService
                parseMoney(service.amount) - paidForService
            } else {
                paidBefore += amount
                parseMoney(client.fee) - parseMoney(client.paid) - paidBefore
            }
            PaymentRow(client, payment, remaining.coerceAtLeast(0.0))
        }
    }.sortedByDescending { parseDateTime(it.payment.date) ?: Long.MIN_VALUE }

    Row(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "Платежи клиентов",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.weight(1f)
        )
    }

    if (rows.isEmpty()) {
        Text("Платежей пока нет", Modifier.padding(20.dp), color = MaterialTheme.colorScheme.secondary)
    } else LazyColumn {
        items(rows, key = { it.payment.id }) { row ->
            val c = row.client
            val p = row.payment
            val serviceName = c.services.firstOrNull { it.id == p.serviceId }?.name.orEmpty()
            Card(
                Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 5.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(Modifier.padding(14.dp)) {
                    Text(c.name.ifBlank { "Без имени" }, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text(
                        "${p.amount} ₽${if (p.date.isBlank()) "" else " • ${p.date}"}${if (serviceName.isBlank()) "" else " • $serviceName"}",
                        fontWeight = FontWeight.Bold,
                        color = Gold
                    )
                    Text(
                        "Остаток: ${formatMoney(row.remaining)} ₽",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (row.remaining > 0) MaterialTheme.colorScheme.primary else Green
                    )
                    if (p.note.isNotBlank()) Text(p.note, fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                }
            }
        }
    }
}

@Composable
fun PaymentDialog(s: Store, refresh: () -> Unit, close: () -> Unit) {
    var clientId by remember { mutableStateOf(s.clients.firstOrNull()?.id ?: "") }
    var amount by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(SimpleDateFormat("dd.MM.yyyy", Locale.US).format(Date())) }
    var note by remember { mutableStateOf("") }
    var place by remember { mutableStateOf("") }
    var clientMenu by remember { mutableStateOf(false) }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    AlertDialog(onDismissRequest = close, shape = RoundedCornerShape(28.dp), containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 8.dp, title = { Text("Новый платёж", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold) }, text = { Column(Modifier.verticalScroll(rememberScrollState())) {
        Box { OutlinedButton(onClick = { clientMenu = true }, modifier = Modifier.fillMaxWidth()) { Text(s.clients.firstOrNull { it.id == clientId }?.name ?: "Выберите клиента", Modifier.weight(1f)); Icon(Icons.Default.ArrowDropDown, null) }; DropdownMenu(expanded = clientMenu, onDismissRequest = { clientMenu = false }) { s.clients.forEach { c -> DropdownMenuItem(text = { Text(c.name.ifBlank { "Без имени" }) }, onClick = { clientId = c.id; clientMenu = false }) } } }
        Field(amount, { amount = it }, "Сумма", numeric = true, decimal = true)
        Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.weight(1f)) { Field(date, { date = it }, "Дата") }; IconButton(onClick = { val c=Calendar.getInstance(); DatePickerDialog(ctx,{_,y,m,d->date=String.format(Locale.US,"%02d.%02d.%04d",d,m+1,y)},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show() }) { Icon(Icons.Default.CalendarMonth, "Дата") } }
        Field(place, { place = it }, "Где внесена оплата")
        Field(note, { note = it }, "Комментарий")
    } }, confirmButton = { Button(onClick = { val c=s.clients.firstOrNull{it.id==clientId}; val a=digitsInput(amount,true); if(c!=null && a.toDoubleOrNull()!=null && a.toDoubleOrNull()!!>0){ c.payments=(c.payments + Payment(amount=a,date=date,note=capitalizeInput(note),place=capitalizeInput(place))).toMutableList(); s.clients=s.clients.filterNot{it.id==c.id}.toMutableList().apply{add(c)}; addActivity(s,"Добавлен платёж", "${c.name}: ${a} ₽ • ${date}","Создание"); refresh(); close() } }) { Text("Сохранить") } }, dismissButton = { TextButton(onClick = close) { Text("Отмена") } })
}

@Composable
fun Cases(s: Store, refresh: () -> Unit, onMenu: () -> Unit) {
    var hidden by remember { mutableStateOf(setOf<String>()) }; var editing by remember { mutableStateOf<Case?>(null) }; var adding by remember { mutableStateOf(false) }; var deleting by remember { mutableStateOf<Case?>(null) }; var viewing by remember { mutableStateOf<Case?>(null) }
    val active = s.cases.filter { it.status != "Исполнено" && it.id !in hidden }
    Column(Modifier.fillMaxSize()) {
        Header(s, onMenu); ScreenTitle("Дела", Icons.Default.Gavel) { adding = true }
        if (active.isEmpty()) Text("Активных дел нет", Modifier.padding(20.dp), color = MaterialTheme.colorScheme.secondary)
        else LazyColumn { items(active, key = { it.id }) { c ->
            EntityCard(Icons.Default.Gavel, "${c.no} • ${c.client}", "${c.court}\n${c.category} • ${c.status}\nЗаседаний: ${hearingsOf(c).size}", onDelete={deleting=c}, onEdit={editing=c}, onView={viewing=c}, onComplete={completeCase(s,c){hidden=hidden+c.id;refresh()}})
        } }
        if (adding) CaseDialog(s, refresh, { adding=false }); editing?.let { c -> CaseDialog(s,refresh,{editing=null},c) }; deleting?.let { c -> ConfirmDeleteDialog("дело",c.no.ifBlank{"без номера"},{deleting=null}){softDeleteCase(s,c){hidden=hidden+c.id;refresh()};deleting=null} }; viewing?.let { c -> CaseViewDialog(s,c){viewing=null} }
    }
}

@Composable
fun Tasks(s: Store, refresh: () -> Unit, onMenu: () -> Unit) {
    var hidden by remember { mutableStateOf(setOf<String>()) }; var editing by remember { mutableStateOf<Task?>(null) }; var adding by remember { mutableStateOf(false) }; var deleting by remember { mutableStateOf<Task?>(null) }; var viewing by remember { mutableStateOf<Task?>(null) }
    val activeTasks = s.tasks.filter { !it.status.equals("Исполнено", true) && !it.status.equals("Готово", true) && it.id !in hidden }
    val grouped = activeTasks.groupBy { it.caseId.ifBlank { "__none__" } }
    Column(Modifier.fillMaxSize()) { Header(s,onMenu); ScreenTitle("Задачи",Icons.Default.TaskAlt){adding=true}
        LazyColumn { grouped.entries.sortedBy { it.key }.forEach { entry ->
            val case=if(entry.key=="__none__") null else s.cases.firstOrNull{it.id==entry.key}
            item { Text(if(case==null) "Без привязки к делу" else "Дело № ${case.no.ifBlank{"без номера"}}",Modifier.fillMaxWidth().padding(18.dp),fontSize=18.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary) }
            items(entry.value.sortedBy{parseDateTime(it.deadline)?:Long.MAX_VALUE},key={it.id}){t->
                EntityCard(Icons.Default.TaskAlt,t.title,"Срок исполнения: ${t.deadline}\n${t.priority} • В работе\n${t.description}",onDelete={deleting=t},onEdit={editing=t},onView={viewing=t},onComplete={completeTask(s,t){hidden=hidden+t.id;refresh()}})
            }
        } }
        if(adding) TaskDialog(s,refresh,{adding=false}); editing?.let{t->TaskDialog(s,refresh,{editing=null},t)}; deleting?.let{t->ConfirmDeleteDialog("задачу",t.title,{deleting=null}){softDeleteTask(s,t){hidden=hidden+t.id;refresh()};deleting=null}}; viewing?.let{t->TaskViewDialog(t){viewing=null}}
    }
}

@Composable
fun Meetings(s: Store, refresh: () -> Unit, onMenu: () -> Unit) {
    var hidden by remember { mutableStateOf(setOf<String>()) }; var editing by remember { mutableStateOf<Meeting?>(null) }; var adding by remember { mutableStateOf(false) }; var deleting by remember { mutableStateOf<Meeting?>(null) }
    val meetings = s.meetings.filter { !it.status.equals("Исполнено", true) && it.id !in hidden }.sortedWith(compareBy({it.date},{it.time}))
    Column(Modifier.fillMaxSize()) { Header(s,onMenu,"Встречи"); ScreenTitle("Встречи",Icons.Default.Groups){adding=true}
        if(meetings.isEmpty()) Text("Активных встреч пока нет",Modifier.padding(20.dp),color=MaterialTheme.colorScheme.secondary) else LazyColumn{items(meetings,key={it.id}){m->
            EntityCard(Icons.Default.Groups,m.name.ifBlank{"Без ФИО"},"${m.date} • ${m.time}\n${m.place.ifBlank{"Место не указано"}}${if(m.clientName.isNotBlank())"\nКлиент: ${m.clientName}" else ""}${if(m.caseNo.isNotBlank())"\nДело: ${m.caseNo}" else ""}",onDelete={deleting=m},onEdit={editing=m},onView={editing=m},onComplete={completeMeeting(s,m){hidden=hidden+m.id;refresh()}})
        }}
        if(adding) MeetingDialog(s,refresh,{adding=false}); editing?.let{m->MeetingDialog(s,refresh,{editing=null},m)}; deleting?.let{m->ConfirmDeleteDialog("встречу",m.name.ifBlank{"без ФИО"},{deleting=null}){s.trash=(s.trash+TrashItem(type="meeting",title=m.name.ifBlank{"Встреча"},payload=Gson().toJson(m))).toMutableList();s.meetings=s.meetings.filter{it.id!=m.id}.toMutableList();addActivity(s,"Удалена встреча",m.name,"Удаление");hidden=hidden+m.id;deleting=null;refresh()}}
    }
}

@Composable
fun Archive(s: Store, refresh: () -> Unit, onMenu: () -> Unit) {
    var editing by remember { mutableStateOf<Case?>(null) }; var deleting by remember { mutableStateOf<Case?>(null) }; var deletingTask by remember { mutableStateOf<Task?>(null) }; var deletingMeeting by remember { mutableStateOf<Meeting?>(null) }
    val archivedCases=s.cases.filter{it.status=="Исполнено"}; val archivedMeetings=s.meetings.filter{it.status=="Исполнено" && it.caseId.isBlank()}; val archivedTasks=s.tasks.filter{it.status=="Исполнено" && it.caseId.isBlank()}; val archivedHearings=s.cases.flatMap{c->hearingsOf(c).filter{it.status=="Исполнено"}.map{c to it}}
    Column(Modifier.fillMaxSize()) { Header(s,onMenu); Row(Modifier.fillMaxWidth().padding(18.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Inventory2,null,tint=Gold);Spacer(Modifier.width(10.dp));Text("Архив",fontSize=27.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)}
        if(archivedCases.isEmpty()&&archivedMeetings.isEmpty()&&archivedTasks.isEmpty()&&archivedHearings.isEmpty())Text("Архив пока пуст",Modifier.padding(20.dp),color=MaterialTheme.colorScheme.secondary) else LazyColumn{
            if(archivedCases.isNotEmpty())item{Text("Исполненные дела",Modifier.padding(18.dp),fontSize=18.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)}
            items(archivedCases,key={"case-${it.id}"}){c->
                val linkedMeetings=s.meetings.filter{it.caseId==c.id || (it.caseId.isBlank() && c.no.isNotBlank() && it.caseNo==c.no)}
                val linkedTasks=s.tasks.filter{it.caseId==c.id}
                Column(Modifier.fillMaxWidth()) {
                    EntityCard(Icons.Default.Inventory2,"${c.no} • ${c.client}","${c.court}\n${c.category} • Исполнено\nЗаседаний: ${hearingsOf(c).size} • Встреч: ${linkedMeetings.size} • Задач: ${linkedTasks.size}",onDelete={deleting=c},onEdit={editing=c})
                    linkedMeetings.sortedWith(compareBy({it.date},{it.time})).forEach { m ->
                        Card(Modifier.fillMaxWidth().padding(start=30.dp,end=14.dp,top=1.dp,bottom=2.dp),shape=RoundedCornerShape(12.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant)) {
                            Row(Modifier.padding(start=9.dp,end=4.dp,top=7.dp,bottom=7.dp),verticalAlignment=Alignment.CenterVertically){
                                Icon(Icons.Default.Groups,null,tint=Green)
                                Spacer(Modifier.width(7.dp))
                                Column(Modifier.weight(1f)) {
                                    Text("Встреча • ${m.date} ${m.time}",fontSize=12.sp,fontWeight=FontWeight.Bold)
                                    Text(m.name.ifBlank{"Без ФИО"},fontSize=11.sp,color=MaterialTheme.colorScheme.secondary)
                                }
                                IconButton(onClick={deletingMeeting=m}){Icon(Icons.Default.DeleteOutline,"Удалить встречу",tint=MaterialTheme.colorScheme.error)}
                            }
                        }
                    }
                    linkedTasks.sortedBy { it.deadline }.forEach { t ->
                        Card(Modifier.fillMaxWidth().padding(start=30.dp,end=14.dp,top=1.dp,bottom=2.dp),shape=RoundedCornerShape(12.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant)) {
                            Row(Modifier.padding(start=9.dp,end=4.dp,top=4.dp,bottom=4.dp),verticalAlignment=Alignment.CenterVertically){
                                Icon(Icons.Default.TaskAlt,null,tint=Gold); Spacer(Modifier.width(7.dp));
                                Column(Modifier.weight(1f)){Text("Задача • ${t.title.ifBlank{"Без названия"}}",fontSize=12.sp,fontWeight=FontWeight.Bold);Text(t.deadline.ifBlank{"Срок не указан"},fontSize=11.sp,color=MaterialTheme.colorScheme.secondary)}
                                IconButton(onClick={deletingTask=t}){Icon(Icons.Default.DeleteOutline,"Удалить задачу",tint=MaterialTheme.colorScheme.error)}
                            }
                        }
                    }
                }
            }
            if(archivedHearings.isNotEmpty())item{Text("Исполненные судебные заседания",Modifier.padding(18.dp),fontSize=18.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)}
            items(archivedHearings,key={"hearing-${it.first.id}-${it.second.id}"}){pair->val c=pair.first;val h=pair.second;Card(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=3.dp),shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant)){Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Gavel,null,tint=Gold);Spacer(Modifier.width(8.dp));Column{Text("${h.date} • ${h.time}",fontWeight=FontWeight.Bold);Text("Дело № ${c.no.ifBlank{"без номера"}} • ${c.client}",fontSize=12.sp,color=MaterialTheme.colorScheme.secondary)}}}}
            if(archivedMeetings.isNotEmpty())item{Text("Исполненные встречи",Modifier.padding(18.dp),fontSize=18.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)}
            items(archivedMeetings,key={"meeting-${it.id}"}){m->Card(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=3.dp),shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant)){Row(Modifier.padding(start=12.dp,end=4.dp,top=8.dp,bottom=8.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Groups,null,tint=Green);Spacer(Modifier.width(8.dp));Column(Modifier.weight(1f)){Text("${m.date} • ${m.time}",fontWeight=FontWeight.Bold);Text("${m.name.ifBlank{"Без ФИО"}}${if(m.caseNo.isNotBlank())" • дело ${m.caseNo}" else ""}",fontSize=12.sp,color=MaterialTheme.colorScheme.secondary)};IconButton(onClick={deletingMeeting=m}){Icon(Icons.Default.DeleteOutline,"Удалить встречу",tint=MaterialTheme.colorScheme.error)}}}}
            if(archivedTasks.isNotEmpty())item{Text("Исполненные задачи",Modifier.padding(18.dp),fontSize=18.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)}
            items(archivedTasks,key={"task-${it.id}"}){t->Card(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=3.dp),shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant)){Row(Modifier.padding(start=12.dp,end=4.dp,top=8.dp,bottom=8.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.TaskAlt,null,tint=Gold);Spacer(Modifier.width(8.dp));Column(Modifier.weight(1f)){Text(t.title.ifBlank{"Без названия"},fontWeight=FontWeight.Bold);Text("${t.caseNo.ifBlank{"Без дела"}} • ${t.deadline}",fontSize=12.sp,color=MaterialTheme.colorScheme.secondary)};IconButton(onClick={deletingTask=t}){Icon(Icons.Default.DeleteOutline,"Удалить задачу",tint=MaterialTheme.colorScheme.error)}}}}
        }
        editing?.let{c->CaseDialog(s,refresh,{editing=null},c)}; deleting?.let{c->ConfirmDeleteDialog("дело",c.no.ifBlank{"без номера"},{deleting=null}){softDeleteCase(s,c,refresh);deleting=null}}
        deletingTask?.let { t ->
            ConfirmDeleteDialog("задачу",t.title.ifBlank{"без названия"},{deletingTask=null}) {
                softDeleteTask(s,t,refresh)
                deletingTask=null
            }
        }
        deletingMeeting?.let { m ->
            ConfirmDeleteDialog("встречу",m.name.ifBlank{"без ФИО"},{deletingMeeting=null}) {
                softDeleteMeeting(s,m,refresh)
                deletingMeeting=null
            }
        }
    }
}

@Composable
fun Documents(s: Store, refresh: () -> Unit, onMenu: () -> Unit) {
    var hiddenDocs by remember { mutableStateOf(setOf<String>()) }
    var folder by remember { mutableStateOf("") }
    var addingFolder by remember { mutableStateOf(false) }
    var addingDoc by remember { mutableStateOf(false) }
    var folderName by remember { mutableStateOf("") }
    var deleteDoc by remember { mutableStateOf<Doc?>(null) }
    var deleteFolder by remember { mutableStateOf<DocFolder?>(null) }
    var editingDoc by remember { mutableStateOf<Doc?>(null) }
    val folders = s.docFolders
    val currentDocs = s.docs.filter { it.folderId == folder && it.id !in hiddenDocs }
    Column(Modifier.fillMaxSize()) {
        Header(s, onMenu, "Документы")
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Folder, null, tint = Gold); Spacer(Modifier.width(10.dp)); Text(if (folder.isBlank()) "Все документы" else folders.firstOrNull { it.id == folder }?.name ?: "Папка", Modifier.weight(1f), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            IconButton(onClick = { addingFolder = true }) { Icon(Icons.Default.CreateNewFolder, "Новая папка", tint = MaterialTheme.colorScheme.primary) }
            IconButton(onClick = { addingDoc = true }) { Icon(Icons.Default.UploadFile, "Загрузить", tint = MaterialTheme.colorScheme.primary) }
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = folder.isBlank(), onClick = { folder = "" }, label = { Text("Все") })
            folders.forEach { f ->
                Row(Modifier.clickable { folder = f.id }, verticalAlignment = Alignment.CenterVertically) {
                    FilterChip(selected = folder == f.id, onClick = { folder = f.id }, label = { Text(f.name) }, leadingIcon = { Icon(Icons.Default.Folder, null) })
                    IconButton(onClick = { deleteFolder = f }) { Icon(Icons.Default.DeleteOutline, "Удалить папку", tint = Color(0xFF8A4A3A)) }
                }
            }
        }
        if (currentDocs.isEmpty()) Text("Документов в этой папке пока нет", Modifier.padding(20.dp), color = MaterialTheme.colorScheme.secondary)
        else LazyColumn { items(currentDocs, key = { it.id }) { d -> EntityCard(Icons.Default.Description, d.name, "${d.type} • ${d.caseNo.ifBlank { "Без привязки к делу" }}", onDelete = { deleteDoc = d }, onEdit = { editingDoc = d }, onView = { openDocumentFile(s, d) }) } }
        if (addingFolder) AlertDialog(onDismissRequest = { addingFolder = false }, shape = RoundedCornerShape(28.dp), containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 8.dp, title = { Text("Новая папка", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold) }, text = { Field(folderName, { folderName = it }, "Название папки") }, confirmButton = { Button({ if (folderName.isNotBlank()) { s.docFolders = (s.docFolders + DocFolder(name = capitalizeInput(folderName.trim()))).toMutableList(); folderName = ""; addingFolder = false; refresh() } }) { Text("Создать") } }, dismissButton = { TextButton({ addingFolder = false }) { Text("Отмена") } })
        if (addingDoc) DocDialog(s, refresh, { addingDoc = false }, folder)
        editingDoc?.let { d -> DocDialog(s, refresh, { editingDoc = null }, d.folderId, d) }
        deleteDoc?.let { d -> ConfirmDeleteDialog("документ", d.name, { deleteDoc = null }) { softDeleteDoc(s, d){hiddenDocs=hiddenDocs+d.id;refresh()}; deleteDoc = null } }
        deleteFolder?.let { f -> ConfirmDeleteDialog("папку", f.name, { deleteFolder = null }) { s.docFolders = s.docFolders.filter { it.id != f.id }.toMutableList(); s.docs = s.docs.map { if (it.folderId == f.id) it.copy(folderId = "") else it }.toMutableList(); if (folder == f.id) folder = ""; deleteFolder = null; refresh() } }
    }
}

fun openDocumentFile(s: Store, d: Doc) {
    val ctx = s.context()
    val file = File(d.path)
    if (d.path.isBlank() || !file.exists() || !file.isFile) {
        android.widget.Toast.makeText(ctx, "Файл не найден или был перемещён", android.widget.Toast.LENGTH_LONG).show()
        return
    }

    try {
        val uri = androidx.core.content.FileProvider.getUriForFile(
            ctx, "${ctx.packageName}.fileprovider", file
        )
        val mime = when (file.extension.lowercase(Locale.US)) {
            "pdf" -> "application/pdf"
            "doc" -> "application/msword"
            "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            "xls" -> "application/vnd.ms-excel"
            "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            "txt" -> "text/plain"
            "jpg", "jpeg" -> "image/jpeg"
            "png" -> "image/png"
            "webp" -> "image/webp"
            else -> "*/*"
        }
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            clipData = android.content.ClipData.newRawUri(file.name, uri)
        }
        if (intent.resolveActivity(ctx.packageManager) == null) {
            android.widget.Toast.makeText(
                ctx,
                "На устройстве нет приложения для открытия этого файла",
                android.widget.Toast.LENGTH_LONG
            ).show()
            return
        }
        val chooser = Intent.createChooser(intent, "Открыть документ").apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.startActivity(chooser)
    } catch (e: Exception) {
        android.widget.Toast.makeText(
            ctx,
            "Не удалось открыть документ. Проверьте файл или установите приложение для его формата.",
            android.widget.Toast.LENGTH_LONG
        ).show()
    }
}

@Composable
fun Contracts(s: Store, refresh: () -> Unit, onMenu: () -> Unit) {
    var adding by remember{mutableStateOf(false)}; var editing by remember{mutableStateOf<Contract?>(null)}; var deleting by remember{mutableStateOf<Contract?>(null)}
    Column(Modifier.fillMaxSize()){Header(s,onMenu,"Договоры");ScreenTitle("Договоры",Icons.Default.Assignment){adding=true};val list=s.contracts.sortedByDescending{it.added}
        if(list.isEmpty())Text("Договоров пока нет",Modifier.padding(20.dp),color=MaterialTheme.colorScheme.secondary) else LazyColumn{items(list,key={it.id}){c->EntityCard(Icons.Default.Assignment,c.name.ifBlank{"Без названия"},"${c.clientName.ifBlank{"Без клиента"}} • ${c.caseNo.ifBlank{"Без дела"}}",onDelete={deleting=c},onEdit={editing=c},onView={if(c.path.isNotBlank()){val d=Doc(name=c.name,path=c.path,type=c.type);openDocumentFile(s,d)}else editing=c})}}
        if(adding)ContractDialog(s,refresh,{adding=false});editing?.let{c->ContractDialog(s,refresh,{editing=null},c)};deleting?.let{c->ConfirmDeleteDialog("договор",c.name,{deleting=null}){s.trash=(s.trash+TrashItem(type="contract",title=c.name,payload=Gson().toJson(c))).toMutableList();s.contracts=s.contracts.filterNot{it.id==c.id}.toMutableList();addActivity(s,"Удалён договор",c.name,"Удаление");deleting=null;refresh()}}
    }
}

@Composable fun ContractDialog(s: Store,r:()->Unit,close:()->Unit,old:Contract?=null){
    var name by remember{mutableStateOf(old?.name?:"")};var clientId by remember{mutableStateOf(old?.clientId?:"")};var caseId by remember{mutableStateOf(old?.caseId?:"")};var type by remember{mutableStateOf(old?.type?:"Договор")};var selectedUri by remember{mutableStateOf<Uri?>(null)};var clientMenu by remember{mutableStateOf(false)};var caseMenu by remember{mutableStateOf(false)};val ctx=androidx.compose.ui.platform.LocalContext.current
    fun save(){val src=selectedUri;var path=old?.path?:"";val sourceName=src?.lastPathSegment?.substringAfterLast('/')?:old?.name?:"contract";if(src!=null){val dir=File(ctx.filesDir,"contracts");dir.mkdirs();val out=File(dir,"${System.currentTimeMillis()}_${sourceName.replace("/","_")}");ctx.contentResolver.openInputStream(src)?.use{input->out.outputStream().use{input.copyTo(it)}};path=out.absolutePath};val cl=s.clients.firstOrNull{it.id==clientId};val ca=s.cases.firstOrNull{it.id==caseId};val c=old?:Contract();c.name=capitalizeInput(name.ifBlank{sourceName});c.clientId=cl?.id?:"";c.clientName=cl?.name?:"";c.caseId=ca?.id?:"";c.caseNo=ca?.no?:"";c.type=capitalizeInput(type);c.path=path;s.contracts=s.contracts.filterNot{it.id==c.id}.toMutableList().apply{add(c)};addActivity(s,if(old==null)"Добавлен договор" else "Изменён договор",c.name,if(old==null)"Создание" else "Изменение");r();close()}
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){selectedUri=it}
    AlertDialog(onDismissRequest=close,shape=RoundedCornerShape(28.dp),containerColor=MaterialTheme.colorScheme.surface,tonalElevation=8.dp,title={Text(if(old==null)"Новый договор" else "Редактировать договор",color=MaterialTheme.colorScheme.primary,fontWeight=FontWeight.Bold)},text={Column(Modifier.verticalScroll(rememberScrollState())){Field(name,{name=it},"Название договора");Box{OutlinedButton({clientMenu=true},Modifier.fillMaxWidth().padding(vertical=4.dp)){Text(if(clientId.isBlank())"Связать с клиентом" else s.clients.firstOrNull{it.id==clientId}?.name?:"Клиент",Modifier.weight(1f));Icon(Icons.Default.ArrowDropDown,null)};DropdownMenu(clientMenu,{clientMenu=false}){DropdownMenuItem({Text("Без привязки")},{clientId="";clientMenu=false});s.clients.forEach{c->DropdownMenuItem({Text(c.name.ifBlank{"Без имени"})},{clientId=c.id;clientMenu=false})}}};Box{OutlinedButton({caseMenu=true},Modifier.fillMaxWidth().padding(vertical=4.dp)){Text(if(caseId.isBlank())"Связать с делом" else s.cases.firstOrNull{it.id==caseId}?.no?:"Дело",Modifier.weight(1f));Icon(Icons.Default.ArrowDropDown,null)};DropdownMenu(caseMenu,{caseMenu=false}){DropdownMenuItem({Text("Без привязки")},{caseId="";caseMenu=false});s.cases.forEach{c->DropdownMenuItem({Text("${c.no.ifBlank{"Без номера"}} • ${c.client}")},{caseId=c.id;caseMenu=false})}}};Field(type,{type=it},"Тип");Button({picker.launch(arrayOf("application/pdf","application/msword","application/vnd.openxmlformats-officedocument.wordprocessingml.document","text/plain","image/*"))},Modifier.fillMaxWidth()){Icon(Icons.Default.UploadFile,null);Spacer(Modifier.width(8.dp));Text(if(old==null)"Выбрать файл" else "Заменить файл")};if(selectedUri!=null)Text("Новый файл выбран",fontSize=12.sp,color=Gold)}},confirmButton={Button({save()}){Text("Сохранить")}},dismissButton={TextButton(close){Text("Отмена")}})
}

@Composable
fun Search(s: Store, onMenu: () -> Unit) { var q by remember { mutableStateOf("") }; Column { Header(s, onMenu); Text("Поиск", Modifier.padding(horizontal = 18.dp), fontSize = 27.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary); OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(18.dp), placeholder = { Text("Клиент, номер дела, суд, телефон, документ") }, leadingIcon = { Icon(Icons.Default.Search, null) }, shape = RoundedCornerShape(16.dp)); val qq = q.trim().lowercase(); LazyColumn { items(s.cases.filter { listOf(it.no, it.client, it.court).any { v -> v.lowercase().contains(qq) } }) { Text("Дело: ${it.no} — ${it.court}", Modifier.padding(12.dp), color = MaterialTheme.colorScheme.primary) }; items(s.clients.filter { listOf(it.name, it.phone, it.email).any { v -> v.lowercase().contains(qq) } }) { Text("Клиент: ${it.name} — ${it.phone}", Modifier.padding(12.dp), color = MaterialTheme.colorScheme.primary) }; items(s.docs.filter { listOf(it.name, it.caseNo, it.type).any { v -> v.lowercase().contains(qq) } }) { Text("Документ: ${it.name} — ${it.caseNo}", Modifier.padding(12.dp), color = MaterialTheme.colorScheme.primary) } } } }

fun restoreTrashItem(s: Store, t: TrashItem) {
    val gson = Gson()
    var restored = false
    when (t.type) {
        "client" -> runCatching { gson.fromJson(t.payload, Client::class.java) }.getOrNull()?.let { item -> s.clients = (s.clients.filter { it.id != item.id } + item).toMutableList(); restored = true }
        "case" -> runCatching { gson.fromJson(t.payload, Case::class.java) }.getOrNull()?.let { item -> s.cases = (s.cases.filter { it.id != item.id } + item).toMutableList(); restored = true }
        "task" -> runCatching { gson.fromJson(t.payload, Task::class.java) }.getOrNull()?.let { item -> s.tasks = (s.tasks.filter { it.id != item.id } + item).toMutableList(); restored = true }
        "doc" -> runCatching { gson.fromJson(t.payload, Doc::class.java) }.getOrNull()?.let { item -> s.docs = (s.docs.filter { it.id != item.id } + item).toMutableList(); restored = true }
        "meeting" -> runCatching { gson.fromJson(t.payload, Meeting::class.java) }.getOrNull()?.let { item -> s.meetings = (s.meetings.filter { it.id != item.id } + item).toMutableList(); restored = true }
        "contract" -> runCatching { gson.fromJson(t.payload, Contract::class.java) }.getOrNull()?.let { item -> s.contracts = (s.contracts.filter { it.id != item.id } + item).toMutableList(); restored = true }
    }
    if (restored) { s.trash = s.trash.filter { it.id != t.id }.toMutableList(); addActivity(s,"Восстановлено",t.title,"Восстановление") }
}
@Composable
fun Trash(s: Store, refreshVersion: Int, onMenu: () -> Unit) {
    var trashItems by remember { mutableStateOf(s.trash.toList()) }
    LaunchedEffect(refreshVersion) { trashItems = s.trash.toList() }
    fun removeFromTrash(id:String){
        s.trash = s.trash.filter { it.id != id }.toMutableList()
        trashItems = s.trash.toList()
    }
    Column(Modifier.fillMaxSize()) {
        Header(s, onMenu)
        ScreenTitle("Корзина", Icons.Default.DeleteSweep) { }
        if (trashItems.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.DeleteSweep, null, tint = Gold, modifier = Modifier.size(56.dp))
                    Spacer(Modifier.height(10.dp))
                    Text("Корзина пуста", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text("Удалённые элементы будут храниться здесь до 30 дней.", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(horizontal = 32.dp, vertical = 5.dp))
                }
            }
        } else {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 20.dp)) {
                items(trashItems, key = { it.id }) { t ->
                    Card(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 5.dp), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), elevation = CardDefaults.cardElevation(2.dp)) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Surface(Modifier.size(42.dp), CircleShape, color = MaterialTheme.colorScheme.surfaceVariant) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.DeleteSweep, null, tint = Gold) } }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(t.title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                Text(t.type.replaceFirstChar { it.titlecase(Locale("ru")) }, fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                            }
                            IconButton(onClick = {
                                restoreTrashItem(s, t)
                                removeFromTrash(t.id)
                            }) { Icon(Icons.Default.Restore, "Восстановить", tint = MaterialTheme.colorScheme.primary) }
                            IconButton(onClick = {
                                removeFromTrash(t.id)
                            }) { Icon(Icons.Default.DeleteForever, "Удалить навсегда", tint = Color(0xFF8A4A3A)) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ConfirmDeleteDialog(type: String, title: String, cancel: () -> Unit, confirm: () -> Unit) { AlertDialog(onDismissRequest = cancel, shape = RoundedCornerShape(28.dp), containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 8.dp, title = { Text("Удалить $type?", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold) }, text = { Text("Вы хотите удалить $type «$title»?") }, confirmButton = { Button(onClick = confirm) { Text("Да") } }, dismissButton = { TextButton(onClick = cancel) { Text("Нет") } }) }

fun softDeleteTask(s: Store, t: Task, r: () -> Unit) { s.trash = (s.trash + TrashItem(type = "task", title = t.title, payload = Gson().toJson(t))).toMutableList(); s.tasks = s.tasks.filter { it.id != t.id }.toMutableList(); addActivity(s,"Удалена задача",t.title,"Удаление"); r() }
fun softDeleteMeeting(s: Store, m: Meeting, r: () -> Unit) { s.trash = (s.trash + TrashItem(type = "meeting", title = m.name.ifBlank { "Встреча" }, payload = Gson().toJson(m))).toMutableList(); s.meetings = s.meetings.filter { it.id != m.id }.toMutableList(); addActivity(s,"Удалена встреча",m.name.ifBlank { "Встреча" },"Удаление"); r() }
fun softDeleteDoc(s: Store, d: Doc, r: () -> Unit) { s.trash = (s.trash + TrashItem(type = "doc", title = d.name, payload = Gson().toJson(d))).toMutableList(); s.docs = s.docs.filter { it.id != d.id }.toMutableList(); addActivity(s,"Удалён документ",d.name,"Удаление"); r() }

@Composable fun ScreenTitle(t: String, i: androidx.compose.ui.graphics.vector.ImageVector, add: () -> Unit) { Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Icon(i, null, tint = Gold); Spacer(Modifier.width(10.dp)); Text(t, Modifier.weight(1f), fontSize = 27.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary); FloatingActionButton(add, containerColor = Forest, contentColor = MaterialTheme.colorScheme.onPrimary) { Icon(Icons.Default.Add, null) } } }
@Composable fun EntityCard(i: androidx.compose.ui.graphics.vector.ImageVector, title: String, sub: String, onDelete: () -> Unit, onEdit: () -> Unit, onView: () -> Unit = onEdit, onComplete: (() -> Unit)? = null) {
    var confirmCompletion by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 5.dp), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(i, null, tint = Gold, modifier = Modifier.size(28.dp).clickable(onClick = onView))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f).clickable(onClick = onView)) {
                Text(title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text(sub, color = MaterialTheme.colorScheme.secondary, fontSize = 12.sp)
            }
            if (onComplete != null) IconButton(onClick = { confirmCompletion = true }) {
                Icon(Icons.Default.CheckCircle, "Исполнено", tint = Green)
            }
            IconButton(onClick = onEdit) { Icon(Icons.Default.Edit, "Редактировать", tint = MaterialTheme.colorScheme.primary) }
            IconButton(onClick = onDelete) { Icon(Icons.Default.DeleteOutline, "Удалить", tint = Color(0xFF8A4A3A)) }
        }
    }
    if (confirmCompletion && onComplete != null) {
        AlertDialog(
            onDismissRequest = { confirmCompletion = false },
            title = { Text("Подтверждение") },
            text = { Text("Вы действительно выполнили?" ) },
            confirmButton = { Button(onClick = { confirmCompletion = false; onComplete() }) { Text("Да") } },
            dismissButton = { TextButton(onClick = { confirmCompletion = false }) { Text("Нет") } }
        )
    }
}
fun money(a: Double?, b: Double?): String = "%.0f ₽".format((a ?: 0.0) - (b ?: 0.0))
fun completeTasksForCase(s: Store, caseId: String) {
    if (caseId.isBlank()) return
    s.tasks = s.tasks.map { if (it.caseId == caseId) it.copy(status = "Исполнено") else it }.toMutableList()
}
fun completeCase(s: Store, c: Case, r: () -> Unit) {
    c.status = "Исполнено"
    c.hearings = c.hearings.orEmpty().map { it.apply { status = "Исполнено" } }.toMutableList()
    s.cases = s.cases.map { if (it.id == c.id) c else it }.toMutableList()
    completeTasksForCase(s, c.id)
    s.meetings = s.meetings.map { m ->
        val linked = m.caseId == c.id || (m.caseId.isBlank() && c.no.isNotBlank() && m.caseNo == c.no)
        if (linked) m.copy(status = "Исполнено", caseId = if (m.caseId.isBlank()) c.id else m.caseId, caseNo = if (m.caseNo.isBlank()) c.no else m.caseNo) else m
    }.toMutableList()
    addActivity(s, "Исполнено дело", c.no.ifBlank { "Без номера" }, "Исполнение")
    r()
}
fun completeTask(s: Store, t: Task, r: () -> Unit) {
    s.tasks = s.tasks.map { if (it.id == t.id) it.copy(status = "Исполнено") else it }.toMutableList()
    addActivity(s, "Исполнена задача", t.title, "Исполнение")
    r()
}
fun completeMeeting(s: Store, m: Meeting, r: () -> Unit) {
    m.status = "Исполнено"
    s.meetings = s.meetings.map { if (it.id == m.id) m else it }.toMutableList()
    addActivity(s, "Исполнена встреча", m.name.ifBlank { "Встреча" }, "Исполнение")
    r()
}
fun completeHearing(s: Store, c: Case, h: Hearing, r: () -> Unit) {
    h.status = "Исполнено"
    c.hearings = c.hearings.orEmpty().toMutableList()
    s.cases = s.cases.map { if (it.id == c.id) c else it }.toMutableList()
    addActivity(s, "Исполнено судебное заседание", "${c.no.ifBlank { "Без номера" }} • ${h.date} ${h.time}", "Исполнение")
    r()
}
fun hearingsOf(c: Case): List<Hearing> {
    val stored = c.hearings.orEmpty()
    if (stored.isNotEmpty()) return stored
    if (c.date.isBlank()) return emptyList()
    val parts = c.date.split(" ", limit = 2)
    return listOf(Hearing(date = parts.getOrElse(0) { "" }, time = parts.getOrElse(1) { "" }))
}

fun softDeleteCase(s: Store, c: Case, r: () -> Unit) { s.trash = (s.trash + TrashItem(type = "case", title = c.no, payload = Gson().toJson(c))).toMutableList(); s.cases = s.cases.filter { it.id != c.id }.toMutableList(); addActivity(s,"Удалено дело",c.no.ifBlank{"Без номера"},"Удаление"); r() }
fun softDeleteClient(s: Store, c: Client, r: () -> Unit) { s.trash = (s.trash + TrashItem(type = "client", title = c.name, payload = Gson().toJson(c))).toMutableList(); s.clients = s.clients.filter { it.id != c.id }.toMutableList(); addActivity(s,"Удалён клиент",c.name,"Удаление"); r() }

fun capitalizeInput(value: String): String = value.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale("ru")) else it.toString() }
fun digitsInput(value: String, allowDecimal: Boolean = false, allowPlus: Boolean = false): String {
    val allowed = if (allowDecimal) "0123456789.," else "0123456789"
    return value.filter { it in allowed || (allowPlus && it == '+' && value.indexOf(it) == 0) }
}

@Composable fun Field(v: String, on: (String) -> Unit, label: String, numeric: Boolean = false, decimal: Boolean = false, phone: Boolean = false) = OutlinedTextField(
    value = v,
    onValueChange = { value -> on(if (numeric) digitsInput(value, decimal, phone) else if (label.equals("Email", true)) value else capitalizeInput(value)) },
    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
    enabled = true,
    readOnly = false,
    singleLine = true,
    label = { Text(label) },
    placeholder = { if (v.isBlank()) Text("Введите значение") },
    shape = RoundedCornerShape(12.dp),
    keyboardOptions = if (numeric) KeyboardOptions(keyboardType = if (phone) KeyboardType.Phone else if (decimal) KeyboardType.Decimal else KeyboardType.Number) else KeyboardOptions(keyboardType = KeyboardType.Text)
)

fun parseDateTime(value: String): Long? {
    val v = value.trim()
    if (v.isBlank()) return null
    val formats = listOf("dd.MM.yyyy HH:mm", "dd.MM.yyyy H:mm", "dd.MM.yyyy")
    for (pattern in formats) runCatching { return SimpleDateFormat(pattern, Locale.US).apply { isLenient = false }.parse(v)?.time }
    return null
}

data class RoadmapEvent(
    val time: Long,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val title: String,
    val detail: String,
    val color: Color
)

@Composable
fun ClientViewDialog(s: Store, c: Client, close: () -> Unit) {
    val legacyPaid = parseMoney(c.paid)
    val newPaymentsTotal = c.payments.sumOf { payment -> parseMoney(payment.amount) }
    val fee = parseMoney(c.fee)
    val balance = fee - legacyPaid - newPaymentsTotal

    val clientCases = s.cases.filter { item -> item.clientId == c.id || (item.clientId.isBlank() && item.client.equals(c.name, true)) }
    val clientMeetings = s.meetings.filter { item -> item.clientId == c.id || (item.clientId.isBlank() && item.clientName.equals(c.name, true)) }
    val clientTasks = s.tasks.filter { task -> task.caseId.isNotBlank() && clientCases.any { item -> item.id == task.caseId } }
    val clientHearings = clientCases.flatMap { caseItem -> hearingsOf(caseItem).map { hearing -> caseItem to hearing } }
    val clientContracts = s.contracts.filter { it.clientId == c.id || (it.clientId.isBlank() && it.clientName.equals(c.name, true)) }
    val clientDocs = s.docs.filter { doc -> clientCases.any { caseItem -> caseItem.id == doc.caseId || (doc.caseId.isBlank() && doc.caseNo.isNotBlank() && doc.caseNo == caseItem.no) } }

    AlertDialog(
        onDismissRequest = close,
        shape = RoundedCornerShape(28.dp),
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp,
        title = {
            Text(
                "Клиент",
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    c.name.ifBlank { "Без имени" },
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                Text("Телефон: ${c.phone.ifBlank { "—" }}")
                Text("Email: ${c.email.ifBlank { "—" }}")

                Spacer(Modifier.height(10.dp))
                Text("Всё по клиенту", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = MaterialTheme.colorScheme.primary)
                Text("Дела: ${clientCases.size} • Заседания: ${clientHearings.size} • Встречи: ${clientMeetings.size}")
                Text("Задачи: ${clientTasks.size} • Договоры: ${clientContracts.size} • Документы: ${clientDocs.size}")

                Spacer(Modifier.height(10.dp))
                Text("Платежи", fontWeight = FontWeight.Bold)
                Text("Сумма услуг: ${"%.2f".format(fee)} ₽")
                Text("Внесено ранее: ${"%.2f".format(legacyPaid)} ₽")
                Text("Новые платежи: ${"%.2f".format(newPaymentsTotal)} ₽")
                Text("Остаток: ${"%.2f".format(balance)} ₽", fontWeight = FontWeight.Bold)
                c.payments.forEachIndexed { index, payment ->
                    Text(
                        "${index + 1}. ${payment.amount} ₽ • ${payment.date.ifBlank { "дата не указана" }}" +
                            if (payment.note.isBlank()) "" else " • ${payment.note}",
                        fontSize = 12.sp
                    )
                }

                Spacer(Modifier.height(14.dp))
                Text("Дорожная карта", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = MaterialTheme.colorScheme.primary)
                val roadmap = mutableListOf<RoadmapEvent>()
                clientCases.forEach { caseItem ->
                    val dt = parseDateTime(caseItem.date) ?: caseItem.updated
                    roadmap += RoadmapEvent(dt, Icons.Default.Gavel, "Дело № ${caseItem.no.ifBlank { "без номера" }}", caseItem.category.ifBlank { caseItem.status }, Gold)
                    hearingsOf(caseItem).forEach { hearing ->
                        roadmap += RoadmapEvent(parseDateTime("${hearing.date} ${hearing.time}") ?: dt, Icons.Default.Gavel, "Судебное заседание", "${hearing.date} ${hearing.time} • дело № ${caseItem.no.ifBlank { "без номера" }}", Gold)
                    }
                }
                clientMeetings.forEach { meeting ->
                    val caseText = if (meeting.caseNo.isBlank()) "" else " • дело № ${meeting.caseNo}"
                    roadmap += RoadmapEvent(parseDateTime("${meeting.date} ${meeting.time}") ?: meeting.created, Icons.Default.Groups, "Встреча", "${meeting.date} ${meeting.time}$caseText", Green)
                }
                clientTasks.forEach { task ->
                    val caseText = if (task.caseNo.isBlank()) "" else " • дело № ${task.caseNo}"
                    roadmap += RoadmapEvent(parseDateTime(task.deadline) ?: Long.MAX_VALUE, Icons.Default.TaskAlt, "Задача • ${task.title.ifBlank { "Без названия" }}", "${task.deadline}$caseText", Gold)
                }
                val orderedRoadmap = roadmap.sortedWith(compareBy<RoadmapEvent> { it.time }.thenBy { it.title })
                if (orderedRoadmap.isEmpty()) {
                    Text("Активных событий нет", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                } else {
                    orderedRoadmap.forEachIndexed { index, event ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.Top) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(30.dp)) {
                                Icon(event.icon, null, tint = event.color, modifier = Modifier.size(20.dp))
                                if (index < orderedRoadmap.lastIndex) Box(Modifier.width(2.dp).height(24.dp).background(MaterialTheme.colorScheme.outline.copy(alpha = .25f)))
                            }
                            Column(Modifier.weight(1f).padding(start = 6.dp, bottom = 6.dp)) {
                                Text(event.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                                Text(event.detail.ifBlank { "—" }, fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                            }
                        }
                    }
                }

                Spacer(Modifier.height(14.dp))
                Text(
                    "Архив клиента",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                val archivedCases = clientCases.filter { it.status.equals("Исполнено", true) }
                val archivedTasks = clientTasks.filter { it.status.equals("Исполнено", true) }
                val archivedMeetings = clientMeetings.filter { it.status.equals("Исполнено", true) }
                val archivedHearings = clientCases.flatMap { caseItem ->
                    hearingsOf(caseItem)
                        .filter { hearing -> hearing.status.equals("Исполнено", true) }
                        .map { hearing -> caseItem to hearing }
                }
                if (archivedCases.isEmpty() && archivedTasks.isEmpty() && archivedMeetings.isEmpty() && archivedHearings.isEmpty()) {
                    Text("Архив пуст", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                }
                archivedCases.forEach { caseItem ->
                    Text("Дело № ${caseItem.no.ifBlank { "без номера" }} • Исполнено", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                archivedHearings.forEach { pair ->
                    Text("⚖ Заседание • ${pair.second.date} ${pair.second.time} • дело ${pair.first.no.ifBlank { "без номера" }}", fontSize = 12.sp)
                }
                archivedMeetings.forEach { meeting ->
                    Text("● Встреча • ${meeting.date} ${meeting.time}", fontSize = 12.sp)
                }
                archivedTasks.forEach { task ->
                    Text("✓ Задача • ${task.title} • Исполнено", fontSize = 12.sp)
                }

                Spacer(Modifier.height(14.dp))
                Text(
                    "Договоры клиента",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                if (clientContracts.isEmpty()) {
                    Text("Договоров пока нет", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                } else {
                    clientContracts.forEach { contract ->
                        Card(
                            Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Assignment, null, tint = Gold)
                                Spacer(Modifier.width(8.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(contract.name.ifBlank { "Без названия" }, fontWeight = FontWeight.Bold)
                                    Text(
                                        "${contract.type} • ${contract.caseNo.ifBlank { "Без дела" }}",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                }
                                if (contract.path.isNotBlank()) {
                                    IconButton(onClick = {
                                        openDocumentFile(s, Doc(name = contract.name, path = contract.path, type = contract.type))
                                    }) {
                                        Icon(Icons.Default.OpenInNew, "Открыть")
                                    }
                                }
                            }
                        }
                    }
                }
                Text(
                    "Просмотр без редактирования",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        },
        confirmButton = { TextButton(onClick = close) { Text("Закрыть") } }
    )
}

@Composable
fun CaseViewDialog(s: Store, c: Case, close: () -> Unit) {
    val docs = s.docs.filter { it.caseId == c.id }
    val hearings = hearingsOf(c)
    AlertDialog(
        onDismissRequest = close,
        shape = RoundedCornerShape(28.dp),
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp,
        title = { Text("Дело", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(c.no.ifBlank { "Без номера" }, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
                Text("Клиент: ${c.client.ifBlank { "—" }}")
                Text("Суд / орган: ${c.court.ifBlank { "—" }}")
                Text("Категория: ${c.category.ifBlank { "—" }}")
                Text("Статус: ${c.status}")
                Spacer(Modifier.height(10.dp))
                Text("Судебные заседания", fontWeight = FontWeight.Bold)
                if (hearings.isEmpty()) {
                    Text("Заседаний пока нет", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                } else {
                    hearings.forEach { hearing ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Gavel, null, tint = Gold)
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text("${hearing.date} • ${hearing.time}", fontWeight = FontWeight.Bold)
                                Text(hearing.status, fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                            }
                        }
                    }
                }
                Text("Описание дела", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
                Text(c.description.ifBlank { c.notes }.ifBlank { "—" })
                Spacer(Modifier.height(10.dp))
                Text("Документы дела", fontWeight = FontWeight.Bold)
                if (docs.isEmpty()) {
                    Text("Привязанных документов нет", color = MaterialTheme.colorScheme.secondary)
                } else {
                    docs.forEach { doc ->
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { openDocumentFile(s, doc) },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Description, null, tint = Gold)
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text(doc.name.ifBlank { "Документ" })
                                Text(doc.type, fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                            }
                        }
                    }
                }
                if (c.history.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text("История", fontWeight = FontWeight.Bold)
                    c.history.forEach { Text("• $it") }
                }
            }
        },
        confirmButton = { TextButton(onClick = close) { Text("Закрыть") } }
    )
}

@Composable
fun MeetingDialog(s: Store, refresh: () -> Unit, close: () -> Unit, old: Meeting? = null) {
    var name by remember { mutableStateOf(old?.name ?: "") }; var date by remember { mutableStateOf(old?.date ?: SimpleDateFormat("dd.MM.yyyy", Locale.US).format(Date())) }; var time by remember { mutableStateOf(old?.time ?: SimpleDateFormat("HH:mm", Locale.US).format(Date())) }; var place by remember { mutableStateOf(old?.place ?: "") }; var notes by remember { mutableStateOf(old?.notes ?: "") }; var clientId by remember { mutableStateOf(old?.clientId ?: "") }; var caseId by remember { mutableStateOf(old?.caseId ?: "") }; var caseNo by remember { mutableStateOf(old?.caseNo ?: "") }; var clientMenu by remember { mutableStateOf(false) }; var caseMenu by remember { mutableStateOf(false) }; val ctx=androidx.compose.ui.platform.LocalContext.current
    fun pickDate(){val c=Calendar.getInstance();DatePickerDialog(ctx,{_,y,m,d->date=String.format(Locale.US,"%02d.%02d.%04d",d,m+1,y)},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show()}
    fun pickTime(){val c=Calendar.getInstance();TimePickerDialog(ctx,{_,h,m->time=String.format(Locale.US,"%02d:%02d",h,m)},c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),true).show()}
    AlertDialog(onDismissRequest=close,shape=RoundedCornerShape(28.dp),containerColor=MaterialTheme.colorScheme.surface,tonalElevation=10.dp,title={Text(if(old==null)"Новая встреча" else "Редактировать встречу",color=MaterialTheme.colorScheme.primary,fontWeight=FontWeight.Bold)},text={Column(Modifier.verticalScroll(rememberScrollState())){
        Field(name,{name=it},"ФИО")
        Box{OutlinedButton({clientMenu=true},Modifier.fillMaxWidth().padding(vertical=4.dp)){Text(if(clientId.isBlank())"Привязать к клиенту" else s.clients.firstOrNull{it.id==clientId}?.name?:"Клиент",Modifier.weight(1f));Icon(Icons.Default.ArrowDropDown,null)};DropdownMenu(clientMenu,{clientMenu=false}){DropdownMenuItem({Text("Без привязки")},{clientId="";clientMenu=false});s.clients.forEach{c->DropdownMenuItem({Text(c.name.ifBlank{"Без имени"})},{clientId=c.id;name=c.name;clientMenu=false})}}}
        Box{OutlinedButton({caseMenu=true},Modifier.fillMaxWidth().padding(vertical=4.dp)){Text(if(caseNo.isBlank())"Привязать к делу" else "Дело № $caseNo",Modifier.weight(1f));Icon(Icons.Default.ArrowDropDown,null)};DropdownMenu(caseMenu,{caseMenu=false}){DropdownMenuItem({Text("Без привязки")},{caseId="";caseNo="";caseMenu=false});s.cases.filter{!it.status.equals("Исполнено",true)}.forEach{c->DropdownMenuItem({Text("${c.no.ifBlank{"Без номера"}} • ${c.client}")},{caseId=c.id;caseNo=c.no;caseMenu=false})}}}
        Row(verticalAlignment=Alignment.CenterVertically){OutlinedTextField(date,{date=it},Modifier.weight(1f).padding(vertical=4.dp),label={Text("Дата")},singleLine=true,shape=RoundedCornerShape(14.dp));IconButton({pickDate()}){Icon(Icons.Default.CalendarMonth,"Выбрать дату",tint=Gold)}}
        Row(verticalAlignment=Alignment.CenterVertically){OutlinedTextField(time,{time=it},Modifier.weight(1f).padding(vertical=4.dp),label={Text("Время")},singleLine=true,shape=RoundedCornerShape(14.dp));IconButton({pickTime()}){Icon(Icons.Default.Schedule,"Выбрать время",tint=Gold)}}
        Field(place,{place=it},"Место встречи");OutlinedTextField(notes,{notes=it},Modifier.fillMaxWidth().heightIn(min=90.dp).padding(vertical=4.dp),label={Text("Комментарий")},shape=RoundedCornerShape(14.dp))
    }},confirmButton={Button({if(name.isNotBlank()){val cl=s.clients.firstOrNull{it.id==clientId};val ca=s.cases.firstOrNull{it.id==caseId};val m=old?:Meeting();m.name=capitalizeInput(name);m.date=date;m.time=time;m.place=capitalizeInput(place);m.notes=capitalizeInput(notes);m.clientId=cl?.id?:"";m.clientName=cl?.name?:"";m.caseId=ca?.id?:"";m.caseNo=ca?.no?:"";m.status=old?.status?:"В работе";s.meetings=s.meetings.filterNot{it.id==m.id}.toMutableList().apply{add(m)};addActivity(s,if(old==null)"Создана встреча" else "Изменена встреча","${m.name} • ${m.date} ${m.time}",if(old==null)"Создание" else "Изменение");refresh();close()}}){Text("Сохранить")}},dismissButton={TextButton(close){Text("Отмена")}})
}

@Composable
fun ClientTabButton(modifier: Modifier, selected: Boolean, icon: androidx.compose.ui.graphics.vector.ImageVector, text: String, onClick: () -> Unit) {
    Surface(modifier.clickable(onClick = onClick).height(48.dp), shape = RoundedCornerShape(12.dp), color = if (selected) Forest else MaterialTheme.colorScheme.surfaceVariant, border = if (selected) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .25f))) {
        Row(Modifier.fillMaxSize().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            Icon(icon, null, tint = if (selected) White else MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(5.dp)); Text(text, fontSize = 11.sp, color = if (selected) White else MaterialTheme.colorScheme.primary, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun PaymentServiceSelector(services: List<ServiceCharge>, selectedId: String, onSelected: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val selected = services.firstOrNull { it.id == selectedId }
    Box {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), shape = RoundedCornerShape(12.dp)) {
            Icon(Icons.Default.Link, null, tint = Gold); Spacer(Modifier.width(6.dp)); Text(selected?.name?.ifBlank { "Услуга" } ?: "Привязать к услуге", Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis); Icon(Icons.Default.ArrowDropDown, null)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(text = { Text("Без привязки") }, onClick = { onSelected(""); open = false })
            services.forEach { service -> DropdownMenuItem(text = { Text("${service.name.ifBlank { "Услуга" }} • ${formatMoney(parseMoney(service.amount))} ₽") }, onClick = { onSelected(service.id); open = false }) }
        }
    }
}

fun parseMoney(value: String): Double = value.replace(" ", "").replace(',', '.').toDoubleOrNull() ?: 0.0
fun formatMoney(value: Double): String = "%.2f".format(Locale.US, value).removeSuffix("00").removeSuffix(".")

@Composable
fun ClientDialog(s: Store, r: () -> Unit, close: () -> Unit, old: Client? = null) {
    var n by remember { mutableStateOf(old?.name ?: "") }
    var ph by remember { mutableStateOf(old?.phone ?: "") }
    var em by remember { mutableStateOf(old?.email ?: "") }
    var services by remember { mutableStateOf((old?.let { parseServices(it) } ?: emptyList()).map { it.copy() }.toMutableList()) }
    var payments by remember { mutableStateOf((old?.payments ?: emptyList()).map { it.copy() }.toMutableList()) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var serviceName by remember { mutableStateOf("") }
    var serviceAmount by remember { mutableStateOf("") }
    var newPaymentAmount by remember { mutableStateOf("") }
    var newPaymentDate by remember { mutableStateOf(SimpleDateFormat("dd.MM.yyyy", Locale.US).format(Date())) }
    var newPaymentNote by remember { mutableStateOf("") }
    var newPaymentServiceId by remember { mutableStateOf("") }
    var showNewPayment by rememberSaveable { mutableStateOf(false) }
    val totalServices = services.sumOf { parseMoney(it.amount) }
    val legacyPaid = old?.paid?.toDoubleOrNull() ?: 0.0
    val totalPayments = legacyPaid + payments.sumOf { parseMoney(it.amount) }
    val balance = totalServices - totalPayments
    val ctx = androidx.compose.ui.platform.LocalContext.current
    fun pickDate(index: Int? = null) {
        val c = Calendar.getInstance()
        DatePickerDialog(ctx, { _, y, m, d ->
            val value = String.format(Locale.US, "%02d.%02d.%04d", d, m + 1, y)
            if (index == null) newPaymentDate = value else payments = payments.mapIndexed { i, p -> if (i == index) p.copy(date = value) else p }.toMutableList()
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
    }
    AlertDialog(onDismissRequest = close, shape = RoundedCornerShape(28.dp), containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 10.dp,
        title = { Text(if (old == null) "Новый клиент" else "Редактировать клиента", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold) },
        text = { Column(Modifier.verticalScroll(rememberScrollState())) {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ClientTabButton(Modifier.weight(1f), tab == 0, Icons.Default.Person, "Данные") { tab = 0 }
                    ClientTabButton(Modifier.weight(1f), tab == 1, Icons.Default.RequestQuote, "Услуги") { tab = 1 }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ClientTabButton(Modifier.weight(1f), tab == 2, Icons.Default.Payments, "Платежи") { tab = 2 }
                }
            }
            Spacer(Modifier.height(8.dp))
            when (tab) {
                0 -> {
                    Field(n, { n = it }, "ФИО")
                    Field(ph, { ph = it }, "Телефон", numeric = true, phone = true)
                    Field(em, { em = it }, "Email")
                    Card(Modifier.fillMaxWidth().padding(top = 8.dp), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Column(Modifier.padding(12.dp)) {
                            Text("Расчёты", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Text("Услуг: ${"%.2f".format(totalServices)} ₽", fontSize = 13.sp)
                            Text("Оплачено: ${"%.2f".format(totalPayments)} ₽", fontSize = 13.sp)
                            Text("Остаток: ${"%.2f".format(balance)} ₽", fontWeight = FontWeight.Bold, color = if (balance > 0) MaterialTheme.colorScheme.primary else Green)
                        }
                    }
                }
                1 -> {
                    Text("Суммы услуг клиента", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text("Можно добавить несколько отдельных услуг и видеть общий остаток.", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                    services.forEachIndexed { i, service ->
                        Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                            Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.RequestQuote, null, tint = Gold)
                                Spacer(Modifier.width(8.dp))
                                Column(Modifier.weight(1f)) {
                                    Field(service.name, { v -> services = services.mapIndexed { j, x -> if (j == i) x.copy(name = v) else x }.toMutableList() }, "Наименование услуги")
                                    Field(service.amount, { v -> services = services.mapIndexed { j, x -> if (j == i) x.copy(amount = v) else x }.toMutableList() }, "Сумма", numeric = true, decimal = true)
                                    val paidFor = payments.filter { it.serviceId == service.id }.sumOf { parseMoney(it.amount) }
                                    Text("Оплачено: ${"%.2f".format(paidFor)} ₽ • Остаток: ${"%.2f".format((service.amount.toDoubleOrNull() ?: 0.0) - paidFor)} ₽", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                                }
                                IconButton({ services = services.toMutableList().also { it.removeAt(i) } }) { Icon(Icons.Default.DeleteOutline, "Удалить услугу", tint = Color(0xFF8A4A3A)) }
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Field(serviceName, { serviceName = it }, "Новая услуга")
                    Field(serviceAmount, { serviceAmount = it }, "Сумма новой услуги", numeric = true, decimal = true)
                    Button(onClick = { val a = parseMoney(serviceAmount); if (a > 0) { services = (services + ServiceCharge(name = capitalizeInput(serviceName.ifBlank { "Услуга" }), amount = formatMoney(a))).toMutableList(); serviceName = ""; serviceAmount = "" } }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Добавить сумму услуги") }
                    Spacer(Modifier.height(6.dp)); Text("Итого услуг: ${"%.2f".format(totalServices)} ₽", fontWeight = FontWeight.Bold, color = Gold)
                }
                2 -> {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Платежи", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Text("Всего оплачено: ${"%.2f".format(totalPayments)} ₽ • Остаток: ${"%.2f".format(balance)} ₽", fontSize = 12.sp)
                        }
                        OutlinedButton(onClick = { showNewPayment = !showNewPayment }) {
                            Text(if (showNewPayment) "Закрыть" else "Новая оплата")
                        }
                    }
                    if (showNewPayment) {
                        Card(
                            Modifier.fillMaxWidth().padding(vertical = 6.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Column(Modifier.padding(12.dp)) {
                                Text("Новая оплата", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                Text("Добавьте оплату, укажите дату и при необходимости привяжите её к услуге.", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                                Field(newPaymentAmount, { newPaymentAmount = it }, "Сумма оплаты", numeric = true, decimal = true)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.weight(1f)) { Field(newPaymentDate, { newPaymentDate = it }, "Дата") }
                                    IconButton({ pickDate() }) { Icon(Icons.Default.CalendarMonth, "Дата") }
                                }
                                PaymentServiceSelector(services, newPaymentServiceId) { newPaymentServiceId = it }
                                Field(newPaymentNote, { newPaymentNote = it }, "Комментарий")
                                Button(onClick = {
                                    val a = parseMoney(newPaymentAmount)
                                    if (a > 0) {
                                        payments = (payments + Payment(
                                            amount = formatMoney(a),
                                            date = newPaymentDate,
                                            note = capitalizeInput(newPaymentNote),
                                            serviceId = newPaymentServiceId
                                        )).toMutableList()
                                        newPaymentAmount = ""
                                        newPaymentNote = ""
                                        newPaymentServiceId = ""
                                        showNewPayment = false
                                    }
                                }, modifier = Modifier.fillMaxWidth()) {
                                    Icon(Icons.Default.AddCard, null)
                                    Spacer(Modifier.width(6.dp))
                                    Text("Добавить оплату")
                                }
                            }
                        }
                    }
                    Text("История платежей", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 6.dp))
                    if (payments.isEmpty()) {
                        Text("Оплат пока нет", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(vertical = 8.dp))
                    }
                    payments.forEachIndexed { i, p ->
                        Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                            Row(Modifier.padding(10.dp), verticalAlignment = Alignment.Top) {
                                Icon(Icons.Default.ReceiptLong, null, tint = Gold, modifier = Modifier.padding(top = 8.dp))
                                Spacer(Modifier.width(8.dp))
                                Column(Modifier.weight(1f)) {
                                    Field(p.amount, { v -> payments = payments.mapIndexed { j, x -> if (j == i) x.copy(amount = v) else x }.toMutableList() }, "Сумма", numeric = true, decimal = true)
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(Modifier.weight(1f)) { Field(p.date, { v -> payments = payments.mapIndexed { j, x -> if (j == i) x.copy(date = v) else x }.toMutableList() }, "Дата") }
                                        IconButton({ pickDate(i) }) { Icon(Icons.Default.CalendarMonth, "Дата") }
                                    }
                                    PaymentServiceSelector(services, p.serviceId) { sid -> payments = payments.mapIndexed { j, x -> if (j == i) x.copy(serviceId = sid) else x }.toMutableList() }
                                    val historyService = services.firstOrNull { it.id == p.serviceId }
                                    if (historyService != null) {
                                        val serviceAmount = parseMoney(historyService.amount)
                                        val paidBeforeThisPayment = payments
                                            .take(i)
                                            .filter { it.serviceId == historyService.id }
                                            .sumOf { parseMoney(it.amount) }
                                        val paidAfterThisPayment = paidBeforeThisPayment + parseMoney(p.amount)
                                        val serviceRemaining = serviceAmount - paidAfterThisPayment
                                        Text(
                                            "Остаток после оплаты по услуге «${historyService.name.ifBlank { "Услуга" }}»: ${formatMoney(serviceRemaining.coerceAtLeast(0.0))} ₽",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (serviceRemaining > 0) MaterialTheme.colorScheme.primary else Green
                                        )
                                    } else {
                                        val paymentBalance = balance
                                        Text(
                                            "Общий остаток после оплаты: ${formatMoney(paymentBalance.coerceAtLeast(0.0))} ₽",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (paymentBalance > 0) MaterialTheme.colorScheme.primary else Green
                                        )
                                    }
                                    Field(p.note, { v -> payments = payments.mapIndexed { j, x -> if (j == i) x.copy(note = v) else x }.toMutableList() }, "Комментарий")
                                }
                                IconButton({ payments = payments.toMutableList().also { it.removeAt(i) } }) { Icon(Icons.Default.DeleteOutline, "Удалить платёж", tint = Color(0xFF8A4A3A)) }
                            }
                        }
                    }
                }
            }
        } },
        confirmButton = { Button(onClick = {
            val c = old ?: Client(created = System.currentTimeMillis())
            c.name = capitalizeInput(n); c.phone = digitsInput(ph, false, true); c.email = em.trim()
            c.services = services.map { it.copy(amount = formatMoney(parseMoney(it.amount)), name = capitalizeInput(it.name)) }.toMutableList()
            c.fee = "%.2f".format(totalServices).replace(',', '.')
            c.payments = payments.map { it.copy(amount = formatMoney(parseMoney(it.amount)), note = capitalizeInput(it.note)) }.toMutableList()
            val list = s.clients.toMutableList(); val idx = list.indexOfFirst { it.id == c.id }; if (idx >= 0) list[idx] = c else list.add(c); s.clients = list
            addActivity(s, if (old == null) "Создан клиент" else "Изменён клиент", c.name, if (old == null) "Создание" else "Изменение")
            r(); close()
        }) { Text("Сохранить") } },
        dismissButton = { TextButton(close) { Text("Отмена") } }
    )
}

fun parseServices(c: Client): List<ServiceCharge> {
    val total = c.fee.toDoubleOrNull() ?: 0.0
    return if (c.services.isNotEmpty()) c.services else if (total > 0) listOf(ServiceCharge(name = "Услуги", amount = c.fee)) else emptyList()
}

@Composable
fun CaseDialog(s: Store, r: () -> Unit, close: () -> Unit, old: Case? = null) {
    var no by remember { mutableStateOf(old?.no ?: "") }; var cl by remember { mutableStateOf(old?.client ?: "") }; var clientId by remember { mutableStateOf(old?.clientId ?: "") }; var clientMenu by remember { mutableStateOf(false) }; var court by remember { mutableStateOf(old?.court ?: "") }; var cat by remember { mutableStateOf(old?.category ?: "") }; var description by remember { mutableStateOf(old?.description ?: old?.notes ?: "") }; var status by remember { mutableStateOf(if(old?.status=="Исполнено")"Исполнено" else "В работе") }; var statusMenu by remember { mutableStateOf(false) }; val ctx=androidx.compose.ui.platform.LocalContext.current
    val initialHearings=remember(old?.id){old?.let { hearingsOf(it).toMutableList() } ?: mutableListOf<Hearing>().also{if(old?.date?.isNotBlank()==true){val parts=old.date.split(" ",limit=2);it.add(Hearing(date=parts.getOrElse(0){""},time=parts.getOrElse(1){""}))}}}; var hearings by remember(old?.id){mutableStateOf(initialHearings)}; var hearingDialog by remember{mutableStateOf(false)}; var hd by remember{mutableStateOf(SimpleDateFormat("dd.MM.yyyy",Locale.US).format(Date()))}; var ht by remember{mutableStateOf(SimpleDateFormat("HH:mm",Locale.US).format(Date()))}
    fun pickHearingDate(){val c=Calendar.getInstance();DatePickerDialog(ctx,{_,y,m,d->hd=String.format(Locale.US,"%02d.%02d.%04d",d,m+1,y)},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show()}; fun pickHearingTime(){val c=Calendar.getInstance();TimePickerDialog(ctx,{_,h,m->ht=String.format(Locale.US,"%02d:%02d",h,m)},c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),true).show()}
    AlertDialog(onDismissRequest=close,shape=RoundedCornerShape(28.dp),containerColor=MaterialTheme.colorScheme.surface,tonalElevation=8.dp,title={Text(if(old==null)"Новое дело" else "Редактировать дело",color=MaterialTheme.colorScheme.primary,fontWeight=FontWeight.Bold)},text={Column(Modifier.verticalScroll(rememberScrollState())){
        Field(no,{no=it.filter{ch->ch.isDigit()||ch in "/-."}},"Номер дела");Box{OutlinedButton({clientMenu=true},Modifier.fillMaxWidth().padding(vertical=4.dp)){Text(if(cl.isBlank())"Выберите клиента" else cl,Modifier.weight(1f));Icon(Icons.Default.ArrowDropDown,null)};DropdownMenu(clientMenu,{clientMenu=false}){DropdownMenuItem({Text("Без привязки")},{clientId="";cl="";clientMenu=false});s.clients.forEach{c->DropdownMenuItem({Text(c.name.ifBlank{"Без имени"})},{clientId=c.id;cl=c.name;clientMenu=false})}}};Field(court,{court=it},"Суд / орган");Field(cat,{cat=it},"Категория");OutlinedTextField(description,{description=capitalizeInput(it)},Modifier.fillMaxWidth().heightIn(min=100.dp).padding(vertical=4.dp),label={Text("Описание дела")},shape=RoundedCornerShape(12.dp))
        Row(verticalAlignment=Alignment.CenterVertically){Text("Судебные заседания",fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));TextButton({hearingDialog=true}){Icon(Icons.Default.Add,null);Text("Добавить")}}
        if(hearings.isEmpty())Text("Добавьте одно или несколько заседаний",fontSize=12.sp,color=MaterialTheme.colorScheme.secondary) else hearings.forEachIndexed{idx,h->Card(Modifier.fillMaxWidth().padding(vertical=3.dp),shape=RoundedCornerShape(12.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant)){Row(Modifier.padding(8.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Gavel,null,tint=Gold);Spacer(Modifier.width(8.dp));Column(Modifier.weight(1f)){Text("Заседание ${idx+1}",fontWeight=FontWeight.Bold);Text("${h.date} • ${h.time}",fontSize=12.sp);Text(h.status,fontSize=11.sp,color=MaterialTheme.colorScheme.secondary)};if(h.status!="Исполнено")IconButton({h.status="Исполнено";hearings=hearings.toMutableList();addActivity(s,"Исполнено судебное заседание","${no.ifBlank{"Без номера"}} • ${h.date} ${h.time}","Исполнение")}){Icon(Icons.Default.CheckCircle,"Исполнено",tint=Green)};IconButton({hearings=hearings.filterNot{it.id==h.id}.toMutableList()}){Icon(Icons.Default.DeleteOutline,"Удалить",tint=Color(0xFF8A4A3A))}}}}
        Box{OutlinedButton({statusMenu=true},Modifier.fillMaxWidth().padding(vertical=4.dp)){Text(status,Modifier.weight(1f));Icon(Icons.Default.ArrowDropDown,null)};DropdownMenu(statusMenu,{statusMenu=false}){listOf("В работе","Исполнено").forEach{v->DropdownMenuItem({Text(v)},{status=v;statusMenu=false})}}}
    }},confirmButton={Button({val c=old?:Case();val linked=s.clients.firstOrNull{it.id==clientId};c.no=no.filter{ch->ch.isDigit()||ch in "/-."};c.client=linked?.name?:capitalizeInput(cl);c.clientId=linked?.id?:clientId;c.court=capitalizeInput(court);c.category=capitalizeInput(cat);c.description=capitalizeInput(description);c.notes=c.description;c.hearings=hearings.toMutableList();c.date=hearings.firstOrNull()?.let{"${it.date} ${it.time}"}?.trim().orEmpty();c.status=status;c.updated=System.currentTimeMillis();s.cases=s.cases.filterNot{it.id==c.id}.toMutableList().apply{add(c)};if(c.status=="Исполнено")completeTasksForCase(s,c.id);addActivity(s,if(old==null)"Создано дело" else "Изменено дело",c.no.ifBlank{"Без номера"},if(old==null)"Создание" else "Изменение");r();close()}){Text("Сохранить")}},dismissButton={TextButton(close){Text("Отмена")}})
    if(hearingDialog)AlertDialog(onDismissRequest={hearingDialog=false},title={Text("Новое судебное заседание")},text={Column{Row(verticalAlignment=Alignment.CenterVertically){OutlinedTextField(hd,{hd=it},Modifier.weight(1f),label={Text("Дата")},singleLine=true);IconButton({pickHearingDate()}){Icon(Icons.Default.CalendarMonth,"Дата")}};Row(verticalAlignment=Alignment.CenterVertically){OutlinedTextField(ht,{ht=it},Modifier.weight(1f),label={Text("Время")},singleLine=true);IconButton({pickHearingTime()}){Icon(Icons.Default.Schedule,"Время")}}}},confirmButton={Button({hearings=(hearings+Hearing(date=hd,time=ht)).toMutableList();hearingDialog=false}){Text("Добавить")}},dismissButton={TextButton({hearingDialog=false}){Text("Отмена")}})
}

@Composable
fun TaskDialog(s: Store, r: () -> Unit, close: () -> Unit, old: Task? = null) {
    var title by remember { mutableStateOf(old?.title ?: "") }; var description by remember { mutableStateOf(old?.description ?: "") }; var caseId by remember { mutableStateOf(old?.caseId ?: "") }; var caseNo by remember { mutableStateOf(old?.caseNo ?: "") }; var caseMenu by remember { mutableStateOf(false) }; var dl by remember { mutableStateOf(old?.deadline ?: "") }; var pr by remember { mutableStateOf(old?.priority ?: "Средний") }; var priorityMenu by remember { mutableStateOf(false) }; var st by remember { mutableStateOf(if (old?.status == "Исполнено") "Исполнено" else "В работе") }; var statusMenu by remember { mutableStateOf(false) }; val ctx = androidx.compose.ui.platform.LocalContext.current
    fun pickDateTime() { val c = Calendar.getInstance(); DatePickerDialog(ctx, { _, y, m, d -> TimePickerDialog(ctx, { _, h, min -> dl = String.format(Locale.US, "%02d.%02d.%04d %02d:%02d", d, m + 1, y, h, min) }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show() }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show() }
    AlertDialog(onDismissRequest = close, shape = RoundedCornerShape(28.dp), containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 8.dp, title = { Text(if (old == null) "Новая задача" else "Редактировать задачу", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold) }, text = { Column(Modifier.verticalScroll(rememberScrollState())) { Field(title, { title = it }, "Задача"); OutlinedTextField(description, { description = capitalizeInput(it) }, Modifier.fillMaxWidth().heightIn(min = 100.dp).padding(vertical = 4.dp), label = { Text("Описание задачи") }); Box { OutlinedButton({ caseMenu = true }, Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Text(if (caseNo.isBlank()) "Выберите дело" else caseNo, Modifier.weight(1f)); Icon(Icons.Default.ArrowDropDown, null) }; DropdownMenu(caseMenu, { caseMenu = false }) { DropdownMenuItem({ Text("Без привязки") }, { caseId = ""; caseNo = ""; caseMenu = false }); s.cases.forEach { c -> DropdownMenuItem({ Text("${c.no.ifBlank { "Без номера" }} • ${c.client}") }, { caseId = c.id; caseNo = c.no; caseMenu = false }) } } }; Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.weight(1f)) { Field(dl, { dl = it }, "Срок исполнения") }; IconButton(onClick = { pickDateTime() }) { Icon(Icons.Default.Event, "Выбрать дату и время") } }; Box { OutlinedButton({ priorityMenu = true }, Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Text(pr, Modifier.weight(1f)); Icon(Icons.Default.ArrowDropDown, null) }; DropdownMenu(priorityMenu, { priorityMenu = false }) { listOf("Высокий", "Средний", "Низкий").forEach { v -> DropdownMenuItem({ Text(v) }, { pr = v; priorityMenu = false }) } } }; OutlinedButton({ statusMenu = true }, Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Text(st, Modifier.weight(1f)); Icon(Icons.Default.ArrowDropDown, null) }; DropdownMenu(statusMenu, { statusMenu = false }) { listOf("В работе", "Исполнено").forEach { v -> DropdownMenuItem({ Text(v) }, { st = v; statusMenu = false }) } } } }, confirmButton = { Button(onClick = { val t = old ?: Task(); t.title = capitalizeInput(title); t.description = capitalizeInput(description); t.caseId = caseId; t.caseNo = caseNo; t.deadline = dl; t.priority = pr; t.status = st; val list = s.tasks.toMutableList(); val i = list.indexOfFirst { it.id == t.id }; if (i >= 0) list[i] = t else list.add(t); s.tasks = list; addActivity(s, if (old == null) "Создана задача" else "Изменена задача", t.title, if (old == null) "Создание" else "Изменение"); r(); close() }) { Text("Сохранить") } }, dismissButton = { TextButton(close) { Text("Отмена") } })
}

@Composable
fun TaskViewDialog(t: Task, close: () -> Unit) {
    AlertDialog(
        onDismissRequest = close,
        shape = RoundedCornerShape(28.dp),
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp,
        title = { Text("Задача", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(t.title.ifBlank { "Без названия" }, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
                Text("Дело: ${t.caseNo.ifBlank { "без привязки" }}")
                Text("Срок исполнения: ${t.deadline.ifBlank { "—" }}")
                Text("Приоритет: ${t.priority}")
                Text("Статус: ${t.status}")
                Text("Описание", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
                Text(t.description.ifBlank { "—" })
                Text("Просмотр без редактирования", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(top = 8.dp))
            }
        },
        confirmButton = { TextButton(close) { Text("Закрыть") } }
    )
}

@Composable
fun DocDialog(s: Store, r: () -> Unit, close: () -> Unit, initialFolderId: String = "", old: Doc? = null) {
    var name by remember { mutableStateOf(old?.name ?: "") }; var caseId by remember { mutableStateOf(old?.caseId ?: "") }; var type by remember { mutableStateOf(old?.type ?: "Документ") }; var folderId by remember { mutableStateOf(old?.folderId ?: initialFolderId) }; var caseMenu by remember { mutableStateOf(false) }; var folderMenu by remember { mutableStateOf(false) }; val ctx = androidx.compose.ui.platform.LocalContext.current
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    fun save(uri: Uri?) {
        val sourceUri = uri ?: selectedUri
        val sourceName = sourceUri?.lastPathSegment?.substringAfterLast('/') ?: old?.name ?: "document"
        var path = old?.path ?: ""
        if (sourceUri != null) { val dir=File(ctx.filesDir,"documents"); dir.mkdirs(); val safe=name.ifBlank{sourceName}.replace("/","_"); val out=File(dir,"${System.currentTimeMillis()}_$safe"); ctx.contentResolver.openInputStream(sourceUri)?.use{input->out.outputStream().use{input.copyTo(it)}}; path=out.absolutePath }
        val c=s.cases.firstOrNull{it.id==caseId}; val updated=old?.copy(name=capitalizeInput(name.ifBlank{sourceName}),caseNo=c?.no?:"",caseId=caseId,type=capitalizeInput(type),path=path,folderId=folderId) ?: Doc(name=capitalizeInput(name.ifBlank{sourceName}),caseNo=c?.no?:"",caseId=caseId,type=capitalizeInput(type),path=path,folderId=folderId)
        s.docs=s.docs.filterNot{it.id==updated.id}.toMutableList().apply{add(updated)}; addActivity(s, if (old == null) "Добавлен документ" else "Изменён документ", updated.name, if (old == null) "Создание" else "Изменение"); r(); close()
    }
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){ selectedUri=it }
    AlertDialog(onDismissRequest=close,shape=RoundedCornerShape(28.dp),containerColor=MaterialTheme.colorScheme.surface,tonalElevation=8.dp,title={Text(if(old==null) "Новый документ" else "Редактировать документ",color=MaterialTheme.colorScheme.primary,fontWeight=FontWeight.Bold)},text={Column(Modifier.verticalScroll(rememberScrollState())){
        Field(name,{name=it},"Название"); Box{OutlinedButton({caseMenu=true},Modifier.fillMaxWidth().padding(vertical=4.dp)){Text(if(caseId.isBlank())"Связать с делом" else s.cases.firstOrNull{it.id==caseId}?.no?:"Дело",Modifier.weight(1f));Icon(Icons.Default.ArrowDropDown,null)};DropdownMenu(caseMenu,{caseMenu=false}){DropdownMenuItem({Text("Без привязки")},{caseId="";caseMenu=false});s.cases.forEach{c->DropdownMenuItem({Text("${c.no.ifBlank{"Без номера"}} • ${c.client}")},{caseId=c.id;caseMenu=false})}}};
        Box{OutlinedButton({folderMenu=true},Modifier.fillMaxWidth().padding(vertical=4.dp)){Text(s.docFolders.firstOrNull{it.id==folderId}?.name?:"Без папки",Modifier.weight(1f));Icon(Icons.Default.ArrowDropDown,null)};DropdownMenu(folderMenu,{folderMenu=false}){DropdownMenuItem({Text("Без папки")},{folderId="";folderMenu=false});s.docFolders.forEach{f->DropdownMenuItem({Text(f.name)},{folderId=f.id;folderMenu=false})}}}; Field(type,{type=it},"Тип");
        Button({picker.launch(arrayOf("application/pdf","application/msword","application/vnd.openxmlformats-officedocument.wordprocessingml.document","text/plain","image/*"))},Modifier.fillMaxWidth()){Icon(Icons.Default.UploadFile,null);Spacer(Modifier.width(8.dp));Text(if(old==null)"Выбрать файл" else "Заменить файл")}; if(selectedUri!=null)Text("Новый файл выбран",fontSize=12.sp,color=Gold)
    }},confirmButton={Button(onClick={save(selectedUri)}){Text("Сохранить")}},dismissButton={TextButton(close){Text("Отмена")}})
}

private fun xmlEscape(v: String): String = v.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;")
private fun xlsxCell(value: String): String = "<c t=\"inlineStr\"><is><t>${xmlEscape(value)}</t></is></c>"
private fun xlsxSheet(rows: List<List<String>>): String = buildString {
    append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>")
    rows.forEachIndexed { i, row -> append("<row r=\"${i+1}\">"); row.forEach { append(xlsxCell(it)) }; append("</row>") }
    append("</sheetData></worksheet>")
}
private fun xlsxExport(s: Store, out: OutputStream) {
    val sheets = linkedMapOf(
        "Клиенты" to listOf(listOf("ID","Имя","Телефон","Email","Сумма услуг","Внесено","Остаток","Рассрочка","Дата платежа","Создан") ) + s.clients.map { c ->
            val paid = if(c.payments.isNotEmpty()) c.payments.sumOf { it.amount.toDoubleOrNull() ?: 0.0 } else c.paid.toDoubleOrNull() ?: 0.0
            listOf(c.id,c.name,c.phone,c.email,c.fee,"$paid",((c.fee.toDoubleOrNull()?:0.0)-paid).toString(),c.installmentEnabled.toString(),c.installmentDate, c.created.toString())
        },
        "Платежи" to listOf(listOf("ID клиента","Клиент","ID платежа","Сумма","Дата","Комментарий")) + s.clients.flatMap { c -> c.payments.map { p -> listOf(c.id,c.name,p.id,p.amount,p.date,p.note) } },
        "Дела" to listOf(listOf("ID","Номер","Клиент","Суд","Категория","Стороны","Статус","Дата","Описание")) + s.cases.map { c -> listOf(c.id,c.no,c.client,c.court,c.category,c.parties,c.status,c.date,c.description) },
        "Задачи" to listOf(listOf("ID","Название","ID дела","Номер дела","Срок","Приоритет","Статус","Описание")) + s.tasks.map { t -> listOf(t.id,t.title,t.caseId,t.caseNo,t.deadline,t.priority,t.status,t.description) },
        "Документы" to listOf(listOf("ID","Название","Номер дела","ID дела","Тип","Путь","ID папки","Добавлен")) + s.docs.map { d -> listOf(d.id,d.name,d.caseNo,d.caseId,d.type,d.path,d.folderId,d.added.toString()) },
        "Папки" to listOf(listOf("ID","Название","Родитель")) + s.docFolders.map { f -> listOf(f.id,f.name,f.parentId) },
        "Встречи" to listOf(listOf("ID","ФИО","Дата","Время","Место","Комментарий","Клиент ID","Клиент","Дело ID","Дело №","Статус","Создано")) + s.meetings.map { m -> listOf(m.id,m.name,m.date,m.time,m.place,m.notes,m.clientId,m.clientName,m.caseId,m.caseNo,m.status,m.created.toString()) },
        "Договоры" to listOf(listOf("ID","Название","Клиент ID","Клиент","Дело ID","Дело","Тип","Файл","Добавлено")) + s.contracts.map { c -> listOf(c.id,c.name,c.clientId,c.clientName,c.caseId,c.caseNo,c.type,c.path,c.added.toString()) }
    )
    ZipOutputStream(out).use { z ->
        fun put(path:String, text:String) { z.putNextEntry(ZipEntry(path)); z.write(text.toByteArray(Charsets.UTF_8)); z.closeEntry() }
        put("[Content_Types].xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>${(1..sheets.size).joinToString(""){ "<Override PartName=\"/xl/worksheets/sheet$it.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" }}</Types>")
        put("_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>")
        val names=sheets.keys.toList()
        put("xl/workbook.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets>${names.mapIndexed { i,n -> "<sheet name=\"${xmlEscape(n)}\" sheetId=\"${i+1}\" r:id=\"rId${i+1}\"/>" }.joinToString("")}</sheets></workbook>")
        put("xl/_rels/workbook.xml.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">${names.indices.joinToString(""){ i -> "<Relationship Id=\"rId${i+1}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet${i+1}.xml\"/>" }}</Relationships>")
        sheets.values.forEachIndexed { i, rows -> put("xl/worksheets/sheet${i+1}.xml", xlsxSheet(rows)) }
    }
}
private fun cellText(e: org.w3c.dom.Element): String = e.getElementsByTagName("t").item(0)?.textContent ?: ""
private fun xlsxImport(s: Store, input: InputStream) {
    val files=mutableMapOf<String,ByteArray>(); ZipInputStream(input).use { z -> var e=z.nextEntry; while(e!=null){ if(!e.isDirectory) files[e.name]=z.readBytes(); e=z.nextEntry } }
    val wb=DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(files["xl/workbook.xml"]!!.inputStream())
    val rel=DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(files["xl/_rels/workbook.xml.rels"]!!.inputStream())
    val relMap=(0 until rel.getElementsByTagName("Relationship").length).associate { val n=rel.getElementsByTagName("Relationship").item(it) as org.w3c.dom.Element; n.getAttribute("Id") to n.getAttribute("Target") }
    val sheets=wb.getElementsByTagName("sheet")
    fun rows(target:String):List<List<String>> { val path="xl/"+target.removePrefix("/"); val d=DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(files[path]!!.inputStream()); val rs=d.getElementsByTagName("row"); return (0 until rs.length).map { r -> val cells=(rs.item(r) as org.w3c.dom.Element).getElementsByTagName("c"); (0 until cells.length).map { cellText(cells.item(it) as org.w3c.dom.Element) } } }
    val data=mutableMapOf<String,List<List<String>>>(); for(i in 0 until sheets.length){ val sh=sheets.item(i) as org.w3c.dom.Element; data[sh.getAttribute("name")]=rows(relMap[sh.getAttribute("r:id")]!!) }
    data["Клиенты"]?.drop(1)?.forEach { a -> if(a.size>=10){ val id=a[0]; val old=s.clients.firstOrNull{it.id==id}; val c=old?:Client(id=id); c.name=a[1]; c.phone=a[2]; c.email=a[3]; c.fee=a[4]; c.installmentEnabled=a[7].toBoolean(); c.installmentDate=a[8]; c.created=a[9].toLongOrNull()?:c.created; s.clients=s.clients.filterNot{it.id==id}.toMutableList().apply{add(c)} } }
    data["Платежи"]?.drop(1)?.forEach { a -> if(a.size>=6){ val c=s.clients.firstOrNull{it.id==a[0]}?:return@forEach; if(c.payments.none{it.id==a[2]}) c.payments.add(Payment(a[2],a[3],a[4],a[5])); s.clients=s.clients.filterNot{it.id==c.id}.toMutableList().apply{add(c)} } }
    data["Дела"]?.drop(1)?.forEach { a -> if(a.size>=9){ val c=s.cases.firstOrNull{it.id==a[0]}?:Case(id=a[0]); c.no=a[1];c.client=a[2];c.court=a[3];c.category=a[4];c.parties=a[5];c.status=a[6];c.date=a[7];c.description=a[8];s.cases=s.cases.filterNot{it.id==c.id}.toMutableList().apply{add(c)} } }
    data["Задачи"]?.drop(1)?.forEach { a -> if(a.size>=8){ val t=s.tasks.firstOrNull{it.id==a[0]}?:Task(id=a[0]);t.title=a[1];t.caseId=a[2];t.caseNo=a[3];t.deadline=a[4];t.priority=a[5];t.status=a[6];t.description=a[7];s.tasks=s.tasks.filterNot{it.id==t.id}.toMutableList().apply{add(t)} } }
    data["Документы"]?.drop(1)?.forEach { a -> if(a.size>=8){ val d=s.docs.firstOrNull{it.id==a[0]}?:Doc(id=a[0]);d.name=a[1];d.caseNo=a[2];d.caseId=a[3];d.type=a[4];d.path=a[5];d.folderId=a[6];d.added=a[7].toLongOrNull()?:d.added;s.docs=s.docs.filterNot{it.id==d.id}.toMutableList().apply{add(d)} } }
    data["Папки"]?.drop(1)?.forEach { a -> if(a.size>=3){ val f=s.docFolders.firstOrNull{it.id==a[0]}?:DocFolder(id=a[0]);f.name=a[1];f.parentId=a[2];s.docFolders=s.docFolders.filterNot{it.id==f.id}.toMutableList().apply{add(f)} } }
    data["Встречи"]?.drop(1)?.forEach { a -> if(a.size>=7){ val m=s.meetings.firstOrNull{it.id==a[0]}?:Meeting(id=a[0]);m.name=a[1];m.date=a[2];m.time=a[3];m.place=a[4];m.notes=a[5];m.clientId=a[6];m.clientName=if(a.size>7)a[7] else "";if(a.size>11){m.caseId=a[8];m.caseNo=a[9];m.status=a[10];m.created=a[11].toLongOrNull()?:m.created}else if(a.size>=9)m.created=a[8].toLongOrNull()?:m.created;s.meetings=s.meetings.filterNot{it.id==m.id}.toMutableList().apply{add(m)} } }
    data["Договоры"]?.drop(1)?.forEach { a -> if(a.size>=9){ val c=s.contracts.firstOrNull{it.id==a[0]}?:Contract(id=a[0]);c.name=a[1];c.clientId=a[2];c.clientName=a[3];c.caseId=a[4];c.caseNo=a[5];c.type=a[6];c.path=a[7];c.added=a[8].toLongOrNull()?:c.added;s.contracts=s.contracts.filterNot{it.id==c.id}.toMutableList().apply{add(c)} } }
}

@Composable fun SettingsPage(s: Store, onBack: () -> Unit, onNight: (Boolean) -> Unit) {
    val p = androidx.compose.ui.platform.LocalContext.current.getSharedPreferences("crm_settings", 0)
    var night by remember { mutableStateOf(p.getBoolean("night", false)) }
    var high by remember { mutableIntStateOf(p.getInt("notify_high", 3)) }
    var medium by remember { mutableIntStateOf(p.getInt("notify_medium", 1)) }
    var low by remember { mutableIntStateOf(p.getInt("notify_low", 1)) }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) { uri -> uri?.let { ctx.contentResolver.openOutputStream(it)?.use { out -> xlsxExport(s, out) } } }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { runCatching { ctx.contentResolver.openInputStream(it)?.use { input -> xlsxImport(s, input) }; onBack() }.onSuccess { } } }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Surface(color = Forest, modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Назад", tint = White) }
                Column(Modifier.weight(1f)) { Text("Настройки", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold); Text("Параметры приложения", color = Gold, fontSize = 12.sp) }
                Icon(Icons.Default.Settings, null, tint = Gold, modifier = Modifier.size(30.dp))
            }
        }
        Text("Внешний вид", Modifier.padding(18.dp, 20.dp, 18.dp, 8.dp), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
        Card(Modifier.fillMaxWidth().padding(horizontal = 14.dp), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Surface(Modifier.size(44.dp), RoundedCornerShape(14.dp), color = Gold.copy(alpha = .16f)) { Icon(if (night) Icons.Default.DarkMode else Icons.Default.LightMode, null, tint = Gold, modifier = Modifier.padding(10.dp)) }
                Spacer(Modifier.width(14.dp)); Column(Modifier.weight(1f)) { Text("Ночной режим", fontWeight = FontWeight.Bold); Text(if (night) "Тёмное оформление включено" else "Светлое оформление включено", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary) }; Switch(night, { night = it; p.edit().putBoolean("night", it).apply(); onNight(it) })
            }
        }
        Text("Уведомления", Modifier.padding(18.dp, 22.dp, 18.dp, 8.dp), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
        Card(Modifier.fillMaxWidth().padding(horizontal = 14.dp), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(16.dp)) {
                Text("Напоминания о задачах", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text("За сколько дней напоминать о сроке", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(top = 3.dp, bottom = 10.dp))
                SettingRow("Высокий приоритет", high) { high = it; p.edit().putInt("notify_high", it).apply() }
                HorizontalDivider(color = Gold.copy(alpha = .16f))
                SettingRow("Средний приоритет", medium) { medium = it; p.edit().putInt("notify_medium", it).apply() }
                HorizontalDivider(color = Gold.copy(alpha = .16f))
                SettingRow("Низкий приоритет", low) { low = it; p.edit().putInt("notify_low", it).apply() }
            }
        }
        Text("Резервная копия", Modifier.padding(18.dp, 22.dp, 18.dp, 8.dp), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
        Card(Modifier.fillMaxWidth().padding(horizontal = 14.dp), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(16.dp)) {
                Text("Excel", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text("Сохраните данные CRM в Excel или восстановите их из ранее созданной копии.", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(top = 3.dp, bottom = 12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = { exportLauncher.launch("Advokat_CRM_backup.xlsx") }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.FileDownload, null); Spacer(Modifier.width(6.dp)); Text("Экспорт") }
                    OutlinedButton(onClick = { importLauncher.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/zip", "*/*")) }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.FileUpload, null); Spacer(Modifier.width(6.dp)); Text("Загрузить") }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable fun SettingRow(label: String, value: Int, set: (Int) -> Unit) { Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) { Text(label, Modifier.weight(1f)); Text(if (value == 0) "Выкл." else "$value дн."); IconButton(onClick = { set(maxOf(0, value - 1)) }) { Icon(Icons.Default.Remove, null) }; IconButton(onClick = { set(minOf(7, value + 1)) }) { Icon(Icons.Default.Add, null) } } }
